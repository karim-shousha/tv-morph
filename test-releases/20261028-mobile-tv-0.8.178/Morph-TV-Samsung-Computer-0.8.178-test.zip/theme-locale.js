(function(w) {
  "use strict";
  var names = { "ac-milan-legends": ["\u0623\u0633\u0627\u0637\u064A\u0631 \u0625\u064A\u0647 \u0633\u064A \u0645\u064A\u0644\u0627\u0646", "AC Milan Legends", "L\xE9gendes de l\u2019AC Milan"], "gta6": ["GTA VI \xB7 \u063A\u0631\u0648\u0628 \u0641\u0627\u064A\u0633", "GTA VI \xB7 Vice Sunset", "GTA VI \xB7 Vice Sunset"], "blue-cinema": ["\u0627\u0644\u0633\u064A\u0646\u0645\u0627 \u0627\u0644\u0632\u0631\u0642\u0627\u0621", "Blue Cinema", "Cin\xE9ma bleu"], "blue": ["\u0627\u0644\u0623\u0632\u0631\u0642 \u0627\u0644\u0647\u0627\u062F\u0626", "Twilight blue", "Bleu cr\xE9puscule"], "night": ["\u0645\u0646\u062A\u0635\u0641 \u0627\u0644\u0644\u064A\u0644", "Midnight", "Bleu nuit"], "emerald": ["\u0627\u0644\u0623\u062E\u0636\u0631 \u0627\u0644\u0633\u0627\u062D\u0644\u064A", "Coastal green", "Vert c\xF4tier"], "amber": ["\u0627\u0644\u0633\u0627\u0639\u0629 \u0627\u0644\u0630\u0647\u0628\u064A\u0629", "Golden hour", "Heure dor\xE9e"], "violet": ["\u0623\u0648\u0631\u0648\u0631\u0627 \u0627\u0644\u0628\u0646\u0641\u0633\u062C\u064A", "Aurora violet", "Aurore violette"], "ahly": ["\u0627\u0644\u0646\u0627\u062F\u064A \u0627\u0644\u0623\u0647\u0644\u064A", "Al Ahly SC", "Al Ahly"], "zamalek": ["\u0646\u0627\u062F\u064A \u0627\u0644\u0632\u0645\u0627\u0644\u0643", "Zamalek SC", "Zamalek"], "barcelona": ["\u0628\u0631\u0634\u0644\u0648\u0646\u0629", "FC Barcelona", "FC Barcelone"], "madrid": ["\u0631\u064A\u0627\u0644 \u0645\u062F\u0631\u064A\u062F", "Real Madrid", "Real Madrid"], "egypt": ["\u0645\u0646\u062A\u062E\u0628 \u0645\u0635\u0631", "Egypt National Team", "\xC9quipe d\u2019\xC9gypte"], "basketball": ["\u0643\u0631\u0629 \u0627\u0644\u0633\u0644\u0629", "Basketball", "Basket-ball"], "baseball": ["\u0627\u0644\u0628\u064A\u0633\u0628\u0648\u0644", "Baseball", "Base-ball"], "montreal": ["\u0645\u0648\u0646\u062A\u0631\u064A\u0627\u0644 \u0643\u0646\u062F\u064A\u064A\u0646", "Montreal Canadiens", "Canadiens de Montr\xE9al"], "toronto": ["\u062A\u0648\u0631\u0646\u062A\u0648 \u0645\u0627\u0628\u0644 \u0644\u064A\u0641\u0632", "Toronto Maple Leafs", "Maple Leafs de Toronto"], "argentina": ["\u0645\u0646\u062A\u062E\u0628 \u0627\u0644\u0623\u0631\u062C\u0646\u062A\u064A\u0646", "Argentina", "\xC9quipe d\u2019Argentine"], "portugal": ["\u0645\u0646\u062A\u062E\u0628 \u0627\u0644\u0628\u0631\u062A\u063A\u0627\u0644", "Portugal", "\xC9quipe du Portugal"], "ismaily": ["\u0627\u0644\u0625\u0633\u0645\u0627\u0639\u064A\u0644\u064A \xB7 \u0627\u0644\u062F\u0631\u0627\u0648\u064A\u0634", "Ismaily \xB7 The Dervishes", "Isma\xEFly \xB7 Les Derviches"], "king-salman": ["\u0627\u0644\u0645\u0644\u0643 \u0633\u0644\u0645\u0627\u0646 \u0628\u0646 \u0639\u0628\u062F\u0627\u0644\u0639\u0632\u064A\u0632", "King Salman", "Le roi Salmane"], "crown-prince": ["\u0627\u0644\u0623\u0645\u064A\u0631 \u0645\u062D\u0645\u062F \u0628\u0646 \u0633\u0644\u0645\u0627\u0646", "Prince Mohammed bin Salman", "Le prince Mohammed ben Salmane"], "nassr": ["\u0627\u0644\u0646\u0635\u0631 \u0627\u0644\u0633\u0639\u0648\u062F\u064A", "Al Nassr", "Al Nassr"], "hilal": ["\u0627\u0644\u0647\u0644\u0627\u0644 \u0627\u0644\u0633\u0639\u0648\u062F\u064A", "Al Hilal", "Al Hilal"], "ittihad": ["\u0627\u0644\u0627\u062A\u062D\u0627\u062F \u0627\u0644\u0633\u0639\u0648\u062F\u064A", "Al Ittihad", "Al Ittihad"], "ahli-saudi": ["\u0627\u0644\u0623\u0647\u0644\u064A \u0627\u0644\u0633\u0639\u0648\u062F\u064A", "Al Ahli Saudi", "Al Ahli saoudien"], "inter-miami": ["\u0625\u0646\u062A\u0631 \u0645\u064A\u0627\u0645\u064A", "Inter Miami", "Inter Miami"], "saudi-national": ["\u062F\u0627\u0645 \u0639\u0632\u0643 \u064A\u0627 \u0648\u0637\u0646", "May your glory endure", "Que ta gloire perdure"], "egypt-national": ["\u062A\u062D\u064A\u0627 \u0645\u0635\u0631", "Long live Egypt", "Vive l\u2019\xC9gypte"] }, packs = { "gaming": ["\u0623\u0644\u0639\u0627\u0628 \u0645\u062C\u0627\u0646\u064A\u0629", "Free gaming", "Jeux gratuits"], "cinema": ["\u0633\u064A\u0646\u0645\u0627 \u0645\u062C\u0627\u0646\u064A\u0629", "Free cinema", "Cin\xE9ma gratuit"], "egypt": ["\u0627\u0644\u0623\u0646\u062F\u064A\u0629 \u0627\u0644\u0645\u0635\u0631\u064A\u0629", "Egyptian clubs", "Clubs \xE9gyptiens"], "europe": ["\u0627\u0644\u0623\u0646\u062F\u064A\u0629 \u0627\u0644\u0623\u0648\u0631\u0648\u0628\u064A\u0629", "European clubs", "Clubs europ\xE9ens"], "hockey": ["\u062D\u0632\u0645\u0629 \u0627\u0644\u0647\u0648\u0643\u064A", "Hockey pack", "Pack de hockey"], "sports": ["\u0627\u0644\u0645\u0644\u0627\u0639\u0628", "Court and field", "Sports de terrain"], "national": ["\u0627\u0644\u0645\u0646\u062A\u062E\u0628\u0627\u062A", "National teams", "\xC9quipes nationales"], "egypt-extra": ["\u0627\u0644\u0625\u0633\u0645\u0627\u0639\u064A\u0644\u064A", "Ismaily", "Isma\xEFly"], "saudi": ["\u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629", "Saudi Arabia", "Arabie saoudite"], "patriotic": ["\u062B\u064A\u0645\u0627\u062A \u0648\u0637\u0646\u064A\u0629 \u0645\u062C\u0627\u0646\u064A\u0629", "Free patriotic themes", "Th\xE8mes nationaux gratuits"], "inter-miami": ["\u0625\u0646\u062A\u0631 \u0645\u064A\u0627\u0645\u064A", "Inter Miami", "Inter Miami"] };
  function language() {
    return w.MorphLocale ? MorphLocale.get() : "en";
  }
  function pick(rows) {
    return rows[language() === "ar" ? 0 : language() === "fr" ? 2 : 1];
  }
  function club(id) {
    return (w.MorphClubs || w.ClearTV && ClearTV.ClubThemes || {})[id];
  }
  function name(id) {
    return names[id] ? pick(names[id]) : id;
  }
  function field(id, key) {
    var c = club(id);
    return c ? c[key + (language() === "ar" ? "Ar" : language() === "fr" ? "Fr" : "En")] || c[key + "En"] || "" : "";
  }
  function repaint() {
    document.querySelectorAll("#themes .theme").forEach(function(tile) {
      var label = tile.querySelector("strong");
      label.setAttribute("data-no-translate", "");
      label.textContent = name(tile.dataset.theme);
      var word = tile.querySelector(".theme-swatch>span");
      if (word) {
        word.setAttribute("data-no-translate", "");
        word.textContent = name(tile.dataset.theme);
      }
      var price = tile.querySelector(".theme-price");
      if (price) {
        price.setAttribute("data-no-translate", "");
        price.textContent = window.MorphPlus && MorphPlus.allowed(tile.dataset.theme) ? pick(["\u0645\u062C\u0627\u0646\u064A", "FREE", "GRATUIT"]) : "\u{1F512} " + pick(["\u0628\u0644\u0633", "PLUS", "PLUS"]);
      }
    });
    document.querySelectorAll(".theme-option").forEach(function(tile) {
      Array.prototype.forEach.call(tile.childNodes, function(node) {
        if (node.nodeType === 3) node.nodeValue = name(tile.dataset.theme);
      });
    });
  }
  w.MorphThemeLocale = { name, field, pack: function(id) {
    return packs[id] ? pick(packs[id]) : id;
  }, paint: repaint };
  w.addEventListener("morphLanguage", repaint);
  w.addEventListener("morphPlus", repaint);
  w.addEventListener("load", function() {
    repaint();
    w.addEventListener("morphLanguage", repaint);
  });
})(window);
