(function(C) {
  "use strict";
  var modes = ["quality", "balanced", "performance"];
  var legacy = { light: "performance", full: "quality", auto: "balanced" };
  var legacyOut = { quality: "full", balanced: "light", performance: "light" };
  var rows = {
    en: ["Performance mode", "Quality", "Balanced", "Performance", "Quality: full effects, no compromises.", "Balanced: full effects with efficient background work.", "Performance: reduced effects for the smoothest navigation."],
    ar: ["\u0648\u0636\u0639 \u0627\u0644\u0623\u062F\u0627\u0621", "\u062C\u0648\u062F\u0629", "\u0645\u062A\u0648\u0627\u0632\u0646", "\u0623\u062F\u0627\u0621", "\u062C\u0648\u062F\u0629: \u0645\u0624\u062B\u0631\u0627\u062A \u0643\u0627\u0645\u0644\u0629 \u0628\u062F\u0648\u0646 \u062A\u0646\u0627\u0632\u0644\u0627\u062A.", "\u0645\u062A\u0648\u0627\u0632\u0646: \u0645\u0624\u062B\u0631\u0627\u062A \u0643\u0627\u0645\u0644\u0629 \u0645\u0639 \u0639\u0645\u0644 \u062E\u0644\u0641\u064A\u0629 \u0641\u0639\u0627\u0644.", "\u0623\u062F\u0627\u0621: \u0645\u0624\u062B\u0631\u0627\u062A \u0645\u062E\u0641\u0641\u0629 \u0644\u0623\u0633\u0631\u0639 \u062A\u0646\u0642\u0644."],
    fr: ["Mode de performance", "Qualit\xE9", "\xC9quilibr\xE9", "Performance", "Qualit\xE9 : effets complets.", "\xC9quilibr\xE9 : effets complets, arri\xE8re-plan efficace.", "Performance : effets r\xE9duits pour une navigation fluide."],
    zh: ["\u6027\u80FD\u6A21\u5F0F", "\u753B\u8D28", "\u5747\u8861", "\u6027\u80FD", "\u753B\u8D28\uFF1A\u5B8C\u6574\u6548\u679C\u3002", "\u5747\u8861\uFF1A\u5B8C\u6574\u6548\u679C\uFF0C\u540E\u53F0\u9AD8\u6548\u3002", "\u6027\u80FD\uFF1A\u51CF\u5C11\u6548\u679C\uFF0C\u5BFC\u822A\u6700\u6D41\u7545\u3002"],
    ja: ["\u30D1\u30D5\u30A9\u30FC\u30DE\u30F3\u30B9", "\u54C1\u8CEA", "\u30D0\u30E9\u30F3\u30B9", "\u30D1\u30D5\u30A9\u30FC\u30DE\u30F3\u30B9", "\u54C1\u8CEA\uFF1A\u5B8C\u5168\u306A\u52B9\u679C\u3002", "\u30D0\u30E9\u30F3\u30B9\uFF1A\u5B8C\u5168\u306A\u52B9\u679C\u3067\u52B9\u7387\u7684\u306A\u52D5\u4F5C\u3002", "\u30D1\u30D5\u30A9\u30FC\u30DE\u30F3\u30B9\uFF1A\u8EFD\u91CF\u306A\u52B9\u679C\u3067\u6ED1\u3089\u304B\u306A\u64CD\u4F5C\u3002"]
  };
  function canon(value) {
    if (modes.indexOf(value) >= 0) return value;
    if (Object.prototype.hasOwnProperty.call(legacy, value)) return legacy[value];
    return "performance";
  }
  var stored = C.read("performanceMode", "performance"), device = {}, nativeProvided = false;
  var mode = canon(stored === "auto" ? "balanced" : stored);
  try {
    if (window.TVNative && TVNative.deviceInfo) device = JSON.parse(TVNative.deviceInfo());
  } catch (e) {
  }
  if (window.MorphTVCompatibility && MorphTVCompatibility.legacyLayout) device.lowMemory = true;
  var ua = navigator.userAgent || "", tv = ua.match(/Tizen[ \/]([0-9]+)/i);
  if (tv && Number(tv[1]) <= 6 || navigator.deviceMemory && navigator.deviceMemory <= 2 || navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2) device.lowMemory = true;
  try {
    if (window.TVNative) {
      var saved = TVNative.performanceTier ? TVNative.performanceTier() : "";
      if (modes.indexOf(saved) >= 0) {
        mode = saved;
        nativeProvided = true;
      } else if (modes.indexOf(C.read("performanceMode", "")) < 0 && TVNative.performanceMode) {
        saved = TVNative.performanceMode();
        if (saved) {
          mode = canon(saved);
          nativeProvided = true;
        }
      }
    }
  } catch (e) {
  }
  if (!C.read("performanceDefault140", false) && !nativeProvided) {
    if (modes.indexOf(C.read("performanceMode", "performance")) < 0) {
      var prev = C.read("performanceMode", "performance");
      mode = prev === "full" ? "quality" : prev === "auto" ? device.lowMemory === true ? "performance" : "balanced" : "performance";
    }
    C.write("performanceMode", mode);
    C.write("performanceDefault140", true);
    try {
      if (window.TVNative && TVNative.setPerformanceMode) TVNative.setPerformanceMode(legacyOut[mode]);
    } catch (e) {
    }
  }
  function saveNativeTier() {
    try {
      if (window.TVNative && TVNative.setPerformanceTier) TVNative.setPerformanceTier(mode);
      else if (window.TVNative && TVNative.setPerformanceMode) TVNative.setPerformanceMode(legacyOut[mode]);
      if (typeof effects === "object" && window.TVNative && TVNative.saveSettings) TVNative.saveSettings(JSON.stringify({ visualEffects: effects }));
    } catch (e) {
    }
  }
  saveNativeTier();
  function words() {
    return rows[window.MorphLocale ? MorphLocale.get() : "en"] || rows.en;
  }
  var savedEffects = C.read("visualEffects", {}), effects = { blur: mode === "quality", glow: mode !== "performance", motion: mode !== "performance" && C.settings.motion !== false }, controls = [];
  ["blur", "glow", "motion"].forEach(function(key) {
    if (typeof savedEffects[key] === "boolean") effects[key] = savedEffects[key];
  });
  function isLight() {
    return !effects.blur && !effects.glow && !effects.motion;
  }
  function labels() {
    var ar = window.MorphLocale && MorphLocale.get() === "ar";
    return ar ? ["\u062A\u062E\u0641\u064A\u0641 \u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0628\u0636\u063A\u0637\u0629", "\u064A\u0642\u0641\u0644 \u0645\u0624\u062B\u0631\u0627\u062A \u0627\u0644\u0648\u0627\u062C\u0647\u0629 \u0641\u0642\u0637\u061B \u0644\u0627 \u064A\u063A\u064A\u0651\u0631 \u062C\u0648\u062F\u0629 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u0623\u0648 \u0627\u0644\u0635\u0648\u062A.", "\u0636\u0628\u0627\u0628\u064A\u0629 \u0627\u0644\u062E\u0644\u0641\u064A\u0627\u062A \u0627\u0644\u0632\u062C\u0627\u062C\u064A\u0629", "\u0625\u064A\u0642\u0627\u0641\u0647\u0627 \u064A\u0642\u0644\u0644 \u0627\u0644\u062D\u0645\u0644 \u0639\u0644\u0649 \u0645\u0639\u0627\u0644\u062C \u0627\u0644\u0631\u0633\u0648\u0645\u064A\u0627\u062A.", "\u0627\u0644\u0625\u0636\u0627\u0621\u0629 \u0648\u0627\u0644\u0638\u0644\u0627\u0644", "\u0625\u064A\u0642\u0627\u0641\u0647\u0627 \u064A\u062E\u0641\u0641 \u0631\u0633\u0645 \u0627\u0644\u062F\u0648\u0643 \u0648\u0627\u0644\u0643\u0631\u0648\u062A\u061B \u0627\u0644\u062A\u062D\u062F\u064A\u062F \u064A\u0638\u0644 \u0648\u0627\u0636\u062D\u064B\u0627.", "\u0627\u0644\u062D\u0631\u0643\u0629 \u0648\u062A\u0643\u0628\u064A\u0631 \u0627\u0644\u0623\u064A\u0642\u0648\u0646\u0627\u062A", "\u0625\u064A\u0642\u0627\u0641\u0647\u0627 \u064A\u062C\u0639\u0644 \u0627\u0646\u062A\u0642\u0627\u0644 \u0627\u0644\u062A\u062D\u062F\u064A\u062F \u0645\u0628\u0627\u0634\u0631\u064B\u0627.", "\u062A\u0634\u063A\u064A\u0644", "\u0625\u064A\u0642\u0627\u0641"] : ["Make the app lighter", "Turns off interface effects only; video and audio quality stay the same.", "Glass background blur", "Off reduces graphics work.", "Glow and shadows", "Off draws simpler cards and dock icons; focus stays visible.", "Animations and icon enlargement", "Off makes focus changes immediate.", "On", "Off"];
  }
  function paint() {
    var w = labels();
    controls.forEach(function(row, index) {
      var on = effects[row.key];
      row.button.querySelector("span").textContent = w[2 + index * 2];
      row.button.querySelector("small").textContent = w[3 + index * 2];
      row.button.querySelector("strong").textContent = w[on ? 8 : 9];
      row.button.setAttribute("aria-checked", String(on));
    });
    if (button) {
      button.querySelector(".performance-title").textContent = window.MorphLocale && MorphLocale.get() === "ar" ? "\u0627\u062E\u062A\u0627\u0631 \u0627\u0644\u0645\u0648\u062F \u0628\u0636\u063A\u0637\u0629 \u0648\u0627\u062D\u062F\u0629" : "Choose a mode in one click";
      button.querySelector(".performance-explainer").textContent = w[1];
      var ar = window.MorphLocale && MorphLocale.get() === "ar", names = ar ? ["\u062E\u0641\u064A\u0641", "\u0645\u062A\u0648\u0627\u0632\u0646", "\u0643\u0627\u0645\u0644 \u0627\u0644\u0645\u0624\u062B\u0631\u0627\u062A"] : ["Light", "Balanced", "Full effects"], hints = ar ? ["\u0623\u0633\u0631\u0639 \u062A\u0646\u0642\u0644\u061B \u0628\u062F\u0648\u0646 \u0628\u0644\u0648\u0631 \u0623\u0648 \u0638\u0644\u0627\u0644 \u0623\u0648 \u062D\u0631\u0643\u0629.", "\u062D\u0631\u0643\u0629 \u0648\u0638\u0644\u0627\u0644 \u0645\u0639 \u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0628\u0644\u0648\u0631.", "\u0643\u0644 \u0645\u0624\u062B\u0631\u0627\u062A \u0627\u0644\u0648\u0627\u062C\u0647\u0629\u061B \u0645\u0646\u0627\u0633\u0628 \u0644\u0644\u0623\u062C\u0647\u0632\u0629 \u0627\u0644\u0623\u0642\u0648\u0649."] : ["Fastest navigation; blur, shadows and animation off.", "Animation and shadows on, blur off.", "All interface effects; best for faster devices."];
      Array.prototype.forEach.call(button.querySelectorAll("[data-performance-preset]"), function(b, i) {
        b.querySelector("span").textContent = names[i];
        b.querySelector("small").textContent = hints[i];
        b.setAttribute("aria-pressed", String(b.getAttribute("data-performance-preset") === mode));
      });
    }
  }
  function apply() {
    document.body.classList.toggle("light-mode", isLight());
    ["blur", "glow", "motion"].forEach(function(key) {
      document.body.classList.toggle("effect-" + key + "-off", !effects[key]);
    });
    document.body.classList.toggle("reduce-motion", !effects.motion || C.settings.motion === false);
    paint();
    window.dispatchEvent(new Event("morphPerformance"));
  }
  function persist() {
    mode = isLight() ? "performance" : effects.blur && effects.glow && effects.motion ? "quality" : "balanced";
    C.write("visualEffects", effects);
    C.write("performanceMode", mode);
    saveNativeTier();
    apply();
  }
  C.Performance = { isLight, tier: function() {
    return mode;
  }, get: function() {
    return mode;
  }, effects: function() {
    return { blur: effects.blur, glow: effects.glow, motion: effects.motion };
  }, setEffect: function(key, value) {
    if (["blur", "glow", "motion"].indexOf(key) < 0) return;
    effects[key] = !!value;
    if (key === "motion") {
      C.settings.motion = !!value;
      C.saveSettings();
    }
    persist();
  }, set: function(value) {
    value = canon(value);
    effects = { blur: value === "quality", glow: value !== "performance", motion: value !== "performance" };
    C.settings.motion = effects.motion;
    C.saveSettings();
    persist();
  }, radioIdleMs: function() {
    return mode === "quality" ? 1e3 : mode === "balanced" ? 5e3 : 1e4;
  } };
  var button;
  window.addEventListener("load", function() {
    var panel = document.querySelector("#view-settings .settings-panel:last-child");
    button = document.createElement("section");
    button.id = "setting-performance";
    button.className = "setting performance-presets";
    button.setAttribute("data-no-translate", "");
    button.innerHTML = "<h3 class=performance-title></h3><p class=performance-explainer></p><div class=performance-preset-options></div>";
    ["performance", "balanced", "quality"].forEach(function(value) {
      var b = document.createElement("button");
      b.setAttribute("data-performance-preset", value);
      b.innerHTML = "<span></span><small></small>";
      b.onclick = function() {
        C.Performance.set(value);
      };
      button.querySelector(".performance-preset-options").appendChild(b);
    });
    if (panel) panel.insertBefore(button, panel.firstChild);
    ["blur", "glow", "motion"].forEach(function(key) {
      var b = document.createElement("button");
      b.id = "setting-effect-" + key;
      b.className = "setting effect-switch";
      b.setAttribute("data-no-translate", "");
      b.setAttribute("role", "switch");
      b.innerHTML = "<span></span><strong></strong><small></small>";
      b.onclick = function() {
        C.Performance.setEffect(key, !effects[key]);
      };
      if (panel) panel.appendChild(b);
      controls.push({ key, button: b });
    });
    apply();
    if (C.SettingsNav) C.SettingsNav.refresh();
  });
  window.addEventListener("morphLanguage", paint);
  document.body.classList.toggle("light-mode", isLight());
  function icons(root) {
    if (root.matches && root.matches(".shelf-card img,.app-card img")) {
      root.loading = "lazy";
      root.decoding = "async";
    }
    root.querySelectorAll(".shelf-card img,.app-card img").forEach(function(img) {
      img.loading = "lazy";
      img.decoding = "async";
    });
  }
  new MutationObserver(function(records) {
    records.forEach(function(r) {
      Array.prototype.forEach.call(r.addedNodes, function(n) {
        if (n.nodeType === 1) icons(n);
      });
    });
  }).observe(document.body, { childList: true, subtree: true });
})(window.ClearTV);
