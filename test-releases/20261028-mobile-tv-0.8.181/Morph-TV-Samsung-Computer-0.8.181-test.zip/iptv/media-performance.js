(function() {
  "use strict";
  function apply() {
    var low = false, mode = "light", effects = null;
    try {
      if (parent !== window && parent.ClearTV && parent.ClearTV.Performance) {
        effects = parent.ClearTV.Performance.effects ? parent.ClearTV.Performance.effects() : null;
        mode = parent.ClearTV.Performance.isLight() ? "light" : "full";
      } else {
        var bridge = window.IptvNative || window.RadioNative;
        if (bridge && bridge.deviceInfo) low = JSON.parse(bridge.deviceInfo()).lowMemory === true;
        if (bridge && bridge.performanceMode) mode = bridge.performanceMode() || "light";
        if (bridge && bridge.settingsJson) effects = JSON.parse(bridge.settingsJson()).visualEffects;
      }
    } catch (e) {
    }
    var ua = (navigator.userAgent || "").match(/Tizen[ \/]([0-9]+)/i);
    low = low || !!(ua && Number(ua[1]) <= 6) || !!(navigator.deviceMemory && navigator.deviceMemory <= 2);
    var full = mode === "full" || mode === "quality";
    var value = { blur: full, glow: full, motion: full };
    if (effects && typeof effects === "object") ["blur", "glow", "motion"].forEach(function(key) {
      if (typeof effects[key] === "boolean") value[key] = effects[key];
    });
    document.body.classList.toggle("light-mode", !value.blur && !value.glow && !value.motion);
    ["blur", "glow", "motion"].forEach(function(key) {
      document.body.classList.toggle("media-effect-" + key + "-off", !value[key]);
    });
  }
  var style = document.createElement("style");
  style.textContent = "body.media-effect-blur-off *,body.media-effect-blur-off *:before,body.media-effect-blur-off *:after{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}body.media-effect-motion-off *,body.media-effect-motion-off *:before,body.media-effect-motion-off *:after{animation:none!important;transition:none!important;scroll-behavior:auto!important}body.media-effect-glow-off *,body.media-effect-glow-off *:before,body.media-effect-glow-off *:after{filter:none!important;box-shadow:none!important;text-shadow:none!important}body.media-effect-motion-off .tile,body.media-effect-motion-off .tile:focus,body.media-effect-motion-off .portal-grid button{transform:none!important}body.light-mode .glow{display:none!important}body.media-effect-glow-off button:focus{outline:3px solid var(--media-accent,#91e8ff)!important;outline-offset:3px!important}";
  document.head.appendChild(style);
  apply();
  window.addEventListener("focus", apply);
  window.addEventListener("storage", apply);
  try {
    if (parent !== window) parent.addEventListener("morphPerformance", apply);
  } catch (e) {
  }
})();
