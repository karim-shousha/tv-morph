(function(w) {
  "use strict";
  var C = w.ClearTV = {};
  C.ThemePacks = w.ThemePacks;
  var family = "default";
  try {
    family = localStorage.getItem("cleartv.activeViewer") || "default";
    if (!/^(default|v[0-9a-z]+)$/.test(family)) family = "default";
  } catch (e) {
  }
  function scoped(key) {
    return family !== "default" && ["sportsFavorites", "settings", "pins", "recent", "mediaHomePinnedV2", "builtin-pins-v2", "prayerHomePinnedV1", "kidsHomePinnedV1"].indexOf(key) >= 0 ? "viewer." + family + "." + key : key;
  }
  C.config = { locationURL: "https://api.ipapi.is/", locationFallbackURL: "https://ipwho.is/", geocodingURL: "https://geocoding-api.open-meteo.com/v1/search", weatherURL: "https://api.open-meteo.com/v1/forecast", weatherTTL: 30 * 60 * 1e3, locationTTL: 24 * 60 * 60 * 1e3 };
  C.read = function(key, fallback) {
    try {
      var value = localStorage.getItem("cleartv." + scoped(key));
      return value === null ? fallback : JSON.parse(value);
    } catch (e) {
      return fallback;
    }
  };
  C.write = function(key, value) {
    try {
      localStorage.setItem("cleartv." + scoped(key), JSON.stringify(value));
      return true;
    } catch (e) {
      return false;
    }
  };
  C.Profiles = { active: function() {
    return family;
  }, list: function() {
    var rows = C.read("viewers", [{ id: "default", name: "Family" }]);
    return Array.isArray(rows) ? rows.slice(0, 6) : [{ id: "default", name: "Family" }];
  }, create: function(name) {
    name = String(name || "").trim().slice(0, 24);
    var rows = this.list();
    if (!name || rows.length >= 6) throw Error("Enter a name \xB7 maximum 6 profiles");
    var id = "v" + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
    rows.push({ id, name });
    if (!C.write("viewers", rows)) throw Error("Storage is full");
    return id;
  }, select: function(id) {
    if (!this.list().some(function(p) {
      return p.id === id;
    })) throw Error("Unknown profile");
    localStorage.setItem("cleartv.activeViewer", id);
    family = id;
    C.settings = C.read("settings", {});
    Object.keys(C.defaults).forEach(function(k) {
      if (typeof C.settings[k] === "undefined") C.settings[k] = C.defaults[k];
    });
    window.dispatchEvent(new Event("morphViewer"));
  } };
  C.defaults = { showRecentApps: false, showHomeHdmi: false, showLastHdmi: false, theme: "night", motion: true, clock24: true, units: "celsius", locationMode: "auto", manualLocation: null };
  C.settings = C.read("settings", {});
  if (w.ClearTVInitial && w.ClearTVInitial.revision !== C.read("initialRevision", "")) {
    Object.keys(w.ClearTVInitial.settings || {}).forEach(function(k) {
      C.settings[k] = w.ClearTVInitial.settings[k];
    });
    C.write("settings", C.settings);
    C.write("initialRevision", w.ClearTVInitial.revision);
  }
  Object.keys(C.defaults).forEach(function(key) {
    if (typeof C.settings[key] === "undefined") {
      C.settings[key] = C.defaults[key];
    }
  });
  C.saveSettings = function() {
    C.write("settings", C.settings);
  };
  C.el = function(tag, className, text) {
    var e = document.createElement(tag);
    if (className) {
      e.className = className;
    }
    if (typeof text !== "undefined") {
      e.textContent = text;
    }
    return e;
  };
  C.icon = function(name) {
    var paths = { play: '<path d="M9 5v14l12-7z" fill="currentColor" stroke="none"/>', tv: '<rect x="3" y="4" width="22" height="16" rx="4"/><path d="M9 25h10M14 20v5M11 9v6l6-3z"/>', apps: '<rect x="3" y="3" width="8" height="8" rx="2"/><rect x="17" y="3" width="8" height="8" rx="2"/><rect x="3" y="17" width="8" height="8" rx="2"/><rect x="17" y="17" width="8" height="8" rx="2"/>', plus: '<path d="M14 5v18M5 14h18"/>', pin: '<path d="M8 3h12l-2 8 5 5H5l5-5zM14 16v10"/>', star: '<path d="M14 2l3.8 8 8.7 1.3-6.3 6.1 1.5 8.6-7.7-4-7.7 4 1.5-8.6-6.3-6.1L10.2 10z"/>', settings: '<circle cx="14" cy="14" r="8"/><circle cx="14" cy="14" r="3"/><path d="M14 1v5M14 22v5M1 14h5M22 14h5M5 5l4 4M19 19l4 4M5 23l4-4M19 9l4-4"/>', globe: '<circle cx="14" cy="14" r="11"/><ellipse cx="14" cy="14" rx="5" ry="11"/><path d="M3 14h22M5 8h18M5 20h18"/>', sun: '<circle cx="14" cy="14" r="5"/><path d="M14 1v4M14 23v4M1 14h4M23 14h4M5 5l3 3M20 20l3 3M5 23l3-3M20 8l3-3"/>', cloud: '<path d="M7 23a6 6 0 1 1 1-12 8 8 0 0 1 15 3 5 5 0 0 1-1 9z"/>', rain: '<path d="M7 18a5 5 0 1 1 1-10 7 7 0 0 1 13 2 4 4 0 0 1 1 8M8 22l-1 4M15 22l-1 4M22 22l-1 4"/>', snow: '<path d="M14 2v24M4 8l20 12M4 20L24 8M10 5l4 4 4-4M10 23l4-4 4 4"/>', moon: '<path d="M21 3a11 11 0 1 0 4 18A12 12 0 0 1 21 3z"/>', music: '<path d="M11 21V6l13-3v15M11 10l13-3"/><ellipse cx="7" cy="22" rx="4" ry="3"/><ellipse cx="20" cy="19" rx="4" ry="3"/>', search: '<circle cx="12" cy="12" r="8"/><path d="M18 18l8 8"/>', back: '<path d="M16 5l-9 9 9 9M7 14h18"/>', refresh: '<path d="M24 10a10 10 0 1 0 0 8M24 3v8h-8"/>', clock: '<circle cx="14" cy="14" r="11"/><path d="M14 7v8l5 3"/>', store: '<path d="M4 10h20v15H4zM3 10l3-7h16l3 7M10 25v-9h8v9"/>', check: '<path d="M5 14l6 6L24 6"/>', help: '<circle cx="14" cy="14" r="11"/><path d="M10 10a4 4 0 1 1 5 4v3M14 22h.1"/>', location: '<path d="M14 26s9-10 9-16a9 9 0 0 0-18 0c0 6 9 16 9 16z"/><circle cx="14" cy="10" r="3"/>' };
    return '<svg viewBox="0 0 28 28" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + (paths[name] || paths.apps) + "</svg>";
  };
  C.request = function(url, callback) {
    var xhr = new XMLHttpRequest(), done = false;
    function finish(error, data) {
      if (done) {
        return;
      }
      done = true;
      callback(error, data);
    }
    xhr.open("GET", url, true);
    xhr.timeout = 12e3;
    xhr.onload = function() {
      if (xhr.status < 200 || xhr.status >= 300) {
        finish(new Error("Service unavailable (" + xhr.status + ")"));
        return;
      }
      try {
        finish(null, JSON.parse(xhr.responseText));
      } catch (e) {
        finish(new Error("Invalid service response"));
      }
    };
    xhr.onerror = function() {
      finish(new Error("Network unavailable"));
    };
    xhr.ontimeout = function() {
      finish(new Error("Request timed out"));
    };
    xhr.send();
    return xhr;
  };
  C.toast = function(text) {
    var el = document.getElementById("toast");
    clearTimeout(C.toastTimer);
    el.textContent = text;
    el.hidden = false;
    C.toastTimer = setTimeout(function() {
      el.hidden = true;
    }, 4500);
  };
})(window);
