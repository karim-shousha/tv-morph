(function(C) {
  "use strict";
  function size() {
    document.querySelectorAll("#view-home .favourites,#view-home .home-shelf-rail").forEach(function(rail) {
      if (rail.classList.contains("app-dock")) return;
      var width = rail.clientWidth - 48;
      if (width <= 0) return;
      var count = Math.max(1, Math.floor((width + 22) / 245)), card = (width - 22 * (count - 1)) / count;
      rail.dataset.fitCount = count;
      rail.dataset.stride = (card + 22).toFixed(1);
      rail.style.setProperty("--fit-card", card + "px");
    });
  }
  function reveal(e) {
    var rail = e.target.closest("#view-home .favourites,#view-home .home-shelf-rail");
    if (!rail || rail.classList.contains("app-dock")) return;
    var children = Array.prototype.filter.call(rail.children, function(n) {
      return n.tagName === "BUTTON" && !n.hidden;
    }), index = children.indexOf(e.target.closest("button"));
    if (index < 0) return;
    var count = Number(rail.dataset.fitCount) || 1, stride = Number(rail.dataset.stride) || (parseFloat(getComputedStyle(rail).getPropertyValue("--fit-card")) || 220) + 22;
    if (!Number(rail.dataset.stride)) rail.dataset.stride = stride.toFixed(1);
    var start = Math.round(rail.scrollLeft / stride);
    if (index < start) rail.scrollLeft = index * stride;
    else if (index >= start + count) rail.scrollLeft = (index - count + 1) * stride;
  }
  var pending = false;
  function queueSize() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(function() {
      pending = false;
      size();
    });
  }
  window.addEventListener("resize", queueSize);
  window.addEventListener("load", function() {
    size();
    document.addEventListener("focusin", reveal);
    new MutationObserver(function(records) {
      if (records.some(function(r) {
        return Array.prototype.some.call(r.addedNodes, function(n) {
          return n.nodeType === 1;
        }) || Array.prototype.some.call(r.removedNodes, function(n) {
          return n.nodeType === 1;
        });
      })) queueSize();
    }).observe(document.getElementById("view-home"), { childList: true, subtree: true });
  });
  C.fitRails = size;
})(window.ClearTV);
