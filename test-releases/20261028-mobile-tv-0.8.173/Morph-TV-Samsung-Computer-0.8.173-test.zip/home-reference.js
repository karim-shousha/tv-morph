(function(C) {
  "use strict";
  C.refreshDockReflections = function() {
  };
  function fitArabic() {
    var h = document.querySelector(".club-hero h1");
    if (!h) return;
    h.style.fontSize = "";
    if (document.documentElement.lang !== "ar") return;
    var size = parseFloat(getComputedStyle(h).fontSize) || 64;
    while (h.scrollHeight > h.clientHeight + 2 && size > 36) {
      size -= 2;
      h.style.fontSize = size + "px";
    }
  }
  function title() {
    requestAnimationFrame(fitArabic);
    var root = document.documentElement;
    function scale(key) {
      return Math.max(70, Math.min(120, Number(C.settings[key]) || 100)) / 100;
    }
    root.style.setProperty("--reference-title-size", 64 * scale("heroTitleSize") + "px");
    root.style.setProperty("--reference-subtitle-size", 30 * scale("heroSubtitleSize") + "px");
    var heading = document.querySelector(".club-hero h1");
    if (!heading || heading.querySelector(".home-title-accent") || C.settings.customTitle || C.settings.theme !== "blue") return;
    var value = heading.textContent, part = value.indexOf(".");
    if (part < 0) return;
    heading.textContent = "";
    heading.appendChild(document.createTextNode(value.slice(0, part + 1) + " "));
    var accent = document.createElement("span");
    accent.className = "home-title-accent";
    accent.textContent = value.slice(part + 1).trim();
    heading.appendChild(accent);
  }
  window.addEventListener("morphLanguage", function() {
    requestAnimationFrame(fitArabic);
  });
  window.addEventListener("load", function() {
    title();
    new MutationObserver(title).observe(document.querySelector(".club-hero h1"), { childList: true });
  });
})(window.ClearTV);
