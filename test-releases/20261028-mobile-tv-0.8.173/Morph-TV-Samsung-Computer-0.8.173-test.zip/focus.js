(function(C) {
  "use strict";
  var scope = document, lastKey = 0, enteredInput = false, revealTarget = null, revealFrame = 0;
  var cacheSeq = 0, cacheScope = null, cacheView = "", cacheModal = false, cacheNodes = null, cacheBoxes = null;
  var SELECTOR = 'button:not([disabled]):not([tabindex="-1"]),input:not([disabled]),select:not([disabled])';
  function edit(input) {
    if (!input) return;
    C.keyboardVisible = true;
    focus(input);
    try {
      if (window.TVNative && TVNative.showKeyboard) TVNative.showKeyboard(input.id, input.value);
    } catch (ignore) {
    }
  }
  function activeViewId() {
    var v = document.querySelector("main>.view:not([hidden])");
    return v ? v.id : "";
  }
  function modalOpen() {
    var o = document.getElementById("overlay");
    return !!o && !o.hidden;
  }
  function collectRoots() {
    var roots = [], choices = [];
    if (scope === document) {
      var active = document.querySelector("main>.view:not([hidden])"), header = document.querySelector("main>header");
      if (active) {
        roots = header ? [header] : [];
        if (active.id === "view-home" && document.body.classList.contains("dock-home")) {
          Array.prototype.forEach.call(active.querySelectorAll(".home-tools,#home-hdmi-shortcuts,#home-last-hdmi,#home-usb-rail,#favourites,.recent-apps-section,.section-heading,#home-next-prayer,#home-download-pack"), function(root) {
            roots.push(root);
          });
        } else roots.push(active);
      }
    } else roots = [scope];
    return roots;
  }
  function stateVisible(e) {
    if (e.disabled || e.tabIndex === -1 || e.hidden) return false;
    if (e.closest && e.closest("[hidden]")) return false;
    return true;
  }
  function list() {
    var roots = collectRoots(), choices = [];
    roots.forEach(function(root) {
      if (!root || root.nodeType !== 1) return;
      if (root.nodeType === 1 && root.matches && root.matches(SELECTOR)) {
        if (stateVisible(root)) choices.push(root);
      }
      Array.prototype.forEach.call(root.querySelectorAll(SELECTOR), function(e) {
        if (choices.indexOf(e) < 0 && stateVisible(e)) choices.push(e);
      });
    });
    return choices;
  }
  function rect(e) {
    var r = e.getBoundingClientRect();
    return { x: r.left + r.width / 2, y: r.top + r.height / 2, left: r.left, right: r.right, top: r.top, bottom: r.bottom, w: r.width, h: r.height };
  }
  function drifted() {
    var cur = document.activeElement;
    if (!cur || cur === document.body) return true;
    var old = cacheBoxes && cacheBoxes.get(cur);
    if (!old) return true;
    var now = rect(cur);
    return Math.abs(now.x - old.x) >= 2 || Math.abs(now.y - old.y) >= 2;
  }
  function geometry() {
    var view = scope === document ? activeViewId() : "#", mo = modalOpen();
    if (cacheNodes && cacheSeq === geometry.seq && cacheScope === scope && cacheView === view && cacheModal === mo && !drifted()) {
      var kept = cacheNodes, pruned = false;
      for (var i = kept.length - 1; i >= 0; i--) {
        if (!document.documentElement.contains(kept[i])) {
          kept.splice(i, 1);
          pruned = true;
        }
      }
      if (!pruned) return { nodes: kept, boxes: cacheBoxes };
    }
    var nodes = list(), boxes = /* @__PURE__ */ new WeakMap(), kept = [];
    for (var j = 0; j < nodes.length; j++) {
      var n = nodes[j];
      if (!document.documentElement.contains(n)) continue;
      var b = rect(n);
      if (b.w <= 0 && b.h <= 0) continue;
      boxes.set(n, b);
      kept.push(n);
    }
    cacheNodes = kept;
    cacheBoxes = boxes;
    cacheScope = scope;
    cacheView = view;
    cacheModal = mo;
    geometry.seq = cacheSeq;
    return { nodes: kept, boxes };
  }
  geometry.seq = -1;
  function focus(e) {
    if (!e) return;
    if (document.activeElement !== e) {
      try {
        e.focus({ preventScroll: true });
      } catch (error) {
        e.focus();
      }
    }
    revealTarget = e;
    if (revealFrame) return;
    revealFrame = requestAnimationFrame(function() {
      revealFrame = 0;
      var target = revealTarget;
      if (!target || !document.documentElement.contains(target) || document.activeElement !== target) return;
      var rail = target.closest("[data-scroll]");
      if (rail && !rail.classList.contains("app-dock")) {
        var a = target.getBoundingClientRect(), b = rail.getBoundingClientRect(), scale = window.MorphScreenFit ? window.MorphScreenFit.scale() : 1;
        if (a.left < b.left + 10) rail.scrollLeft -= (b.left + 10 - a.left) / scale;
        if (a.right > b.right - 10) rail.scrollLeft += (a.right - b.right + 10) / scale;
        if (a.top < b.top + 10) rail.scrollTop -= (b.top + 10 - a.top) / scale;
        if (a.bottom > b.bottom - 10) rail.scrollTop += (a.bottom - b.bottom + 10) / scale;
      }
      var homeFeed = document.querySelector("#view-home .home-feed");
      if (homeFeed && target.closest("header") && homeFeed.scrollTop) homeFeed.scrollTop = 0;
      var main = document.querySelector("main");
      if (main) {
        if (main.scrollTop) main.scrollTop = 0;
        if (main.scrollLeft) main.scrollLeft = 0;
      }
      if (document.documentElement.scrollTop) document.documentElement.scrollTop = 0;
      if (document.documentElement.scrollLeft) document.documentElement.scrollLeft = 0;
      if (document.body.scrollTop) document.body.scrollTop = 0;
      if (document.body.scrollLeft) document.body.scrollLeft = 0;
    });
  }
  function invalidate() {
    cacheSeq++;
    cacheNodes = null;
    cacheBoxes = null;
    geometry.seq = -1;
  }
  function handleMutations(records) {
    for (var i = 0; i < records.length; i++) {
      var r = records[i];
      if (r.type === "attributes") {
        invalidate();
        return;
      }
      var added = r.addedNodes, removed = r.removedNodes, j, n;
      for (j = 0; j < added.length; j++) {
        n = added[j];
        if (n.nodeType !== 1) continue;
        if (n.matches && n.matches(SELECTOR) || n.querySelector && n.querySelector(SELECTOR)) {
          invalidate();
          return;
        }
      }
      for (j = 0; j < removed.length; j++) {
        n = removed[j];
        if (n.nodeType !== 1) continue;
        if (n.matches && n.matches(SELECTOR) || n.querySelector && n.querySelector(SELECTOR)) {
          invalidate();
          return;
        }
      }
    }
  }
  new MutationObserver(handleMutations).observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["hidden", "disabled", "tabindex"] });
  ["morphLanguage", "morphViewer", "morphTheme", "morphUIMode", "morphTextSize", "morphAppOrder", "morphPlus", "morphPacks"].forEach(function(name) {
    window.addEventListener(name, invalidate);
  });
  function move(code) {
    var current = document.activeElement;
    if (C.DockArrow && C.DockArrow(code, current)) return;
    if (C.SettingsNav && C.SettingsNav.arrow(code, current)) return;
    var g = geometry(), choices = g.nodes;
    function position(node) {
      return g.boxes.get(node) || rect(node);
    }
    if ((code === 38 || code === 40) && current && current.closest && current.closest("#view-home") && !current.closest(".home-tools")) choices = choices.filter(function(e2) {
      return !e2.closest(".home-tools");
    });
    if (C.catalogArrow && C.catalogArrow(code, current)) {
      return;
    }
    if (choices.indexOf(current) < 0) {
      focus(choices[0]);
      return;
    }
    var a = position(current), best = null, score = Infinity, horizontal = code === 37 || code === 39;
    for (var i = 0; i < choices.length; i++) {
      var e = choices[i];
      if (e === current) continue;
      var b = position(e), dx = b.x - a.x, dy = b.y - a.y;
      if (code === 37 && dx >= -2 || code === 39 && dx <= 2 || code === 38 && dy >= -2 || code === 40 && dy <= 2) continue;
      var primary = horizontal ? Math.abs(dx) : Math.abs(dy), perp = horizontal ? Math.abs(dy) : Math.abs(dx);
      var overlap = horizontal ? Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) : Math.min(a.right, b.right) - Math.max(a.left, b.left);
      var cost = primary + perp * 3 + (overlap > 0 ? 0 : 700);
      if (cost < score) {
        score = cost;
        best = e;
      }
    }
    focus(best);
  }
  document.addEventListener("visibilitychange", function() {
    if (!document.hidden) {
      C.keyboardVisible = false;
    }
  });
  document.addEventListener("input", function(e) {
    if (e.target && e.target.type !== "range") C.keyboardVisible = true;
  });
  C.Focus = { invalidate, edit, setScope: function(root) {
    scope = root || document;
    invalidate();
  }, focus, first: function() {
    focus(list()[0]);
  }, list };
  document.addEventListener("keydown", function(e) {
    var code = e.keyCode;
    if (e.defaultPrevented) return;
    if (enteredInput && e.repeat && code >= 37 && code <= 40) {
      e.preventDefault();
      return;
    }
    if (code === 10009 || code === 27) {
      e.preventDefault();
      C.back();
      return;
    }
    var active = document.activeElement;
    if (active && active.tagName === "INPUT" && active.type === "range" && code >= 37 && code <= 40) {
      e.preventDefault();
      if (code === 38 || code === 40) {
        C.keyboardVisible = false;
        move(code);
      } else {
        var step = Number(active.step) || 1, min = Number(active.min) || 0, max = Number(active.max) || 100;
        active.value = Math.max(min, Math.min(max, Number(active.value) + (code === 39 ? step : -step)));
        active.dispatchEvent(new Event("input", { bubbles: true }));
      }
      return;
    }
    var editing = active && active.tagName === "INPUT";
    if (editing) {
      if (code === 13 && !C.keyboardVisible) {
        e.preventDefault();
        edit(active);
        return;
      }
      if ((code === 38 || code === 40) && !C.keyboardVisible) {
        e.preventDefault();
        move(code);
        return;
      }
      if (code === 65376 || code === 65385) {
        e.preventDefault();
        C.keyboardVisible = false;
        focus(document.getElementById(document.activeElement.id === "app-search" ? "search-installed" : "city-search"));
        return;
      }
      if (code === 13) {
        e.preventDefault();
        if (document.activeElement.id === "app-search") {
          document.getElementById("search-installed").click();
        } else if (document.activeElement.id === "city-input") {
          document.getElementById("city-search").click();
        }
      }
      return;
    }
    if (code >= 37 && code <= 40) {
      e.preventDefault();
      var now = Date.now();
      if (e.repeat && now - lastKey < 90) {
        return;
      }
      lastKey = now;
      move(code);
    }
    if (code === 13 && document.activeElement && document.activeElement.tagName === "BUTTON") {
      e.preventDefault();
      document.activeElement.click();
    }
  });
  document.addEventListener("keyup", function(e) {
    if (e.keyCode >= 37 && e.keyCode <= 40) enteredInput = false;
  });
  document.addEventListener("focusin", function(e) {
    if (e.target && e.target.tagName === "INPUT") enteredInput = true;
    if (e.target && e.target.tagName === "BUTTON") {
      var label = e.target.getAttribute("aria-label");
      if (label) {
        var hint = document.getElementById("focus-hint");
        if (hint.textContent !== label) hint.textContent = label;
      }
    }
  });
})(window.ClearTV);
