(function(C) {
  "use strict";
  var own = "ClearTV001.Home";
  var canonical = { "com.samsung.tv.cobalt-yt": "YouTube", "org.tizen.netflix-app": "Netflix", "com.samsung.tv.aria-video": "Apple TV", "org.tizen.apple.apple-music": "Apple Music", "com.samsung.tv.gallery": "Gallery", "org.tizen.browser": "Internet", "com.samsung.tv.store": "Samsung Apps" };
  var demo = [{ id: "com.samsung.tv.cobalt-yt", name: "YouTube" }, { id: "rKpKZvmSog.IPTVSmartersPro", name: "IPTV Smarters Pro" }, { id: "org.tizen.netflix-app", name: "Netflix" }, { id: "evKhCgZelL.AmazonIgnitionLauncher2", name: "Prime Video" }, { id: "MCmYXNxgcu.DisneyPlus", name: "Disney+" }, { id: "rJeHak5zRg.Spotify", name: "Spotify - Music and Podcasts" }, { id: "com.samsung.tv.aria-video", name: "Apple TV" }, { id: "org.tizen.browser", name: "Internet" }, { id: "com.samsung.tv.store", name: "Samsung Apps" }];
  function normalise(apps) {
    var ownIds = [own, "ClearMob01.Home"];
    try {
      if (typeof tizen !== "undefined") ownIds.push(tizen.application.getCurrentApplication().appInfo.id);
    } catch (ignore) {
    }
    var rows = apps.filter(function(a) {
      return a && ownIds.indexOf(a.id) < 0;
    }).map(function(a) {
      return { id: a.id, name: a.name || canonical[a.id] || a.id, icon: a.iconPath || a.icon || "", show: a.show, launchable: a.launchable !== false };
    });
    rows.push({ id: "local.tvmorph.tv.kids", name: "Kids World" });
    return C.AppCatalog.normalize(rows, "tizen", "getAppsInfo");
  }
  C.Catalog = { apps: [], preview: typeof tizen === "undefined", load: function(callback) {
    var self = this;
    if (this.preview) {
      this.apps = normalise(demo);
      callback(null, this.apps);
      return;
    }
    try {
      tizen.application.getAppsInfo(function(apps) {
        C.AppCatalog.commit(self, normalise(apps), "tizen", "getAppsInfo");
        callback(null, self.apps);
      }, function(error) {
        callback(error);
      });
    } catch (e) {
      callback(e);
    }
  }, get: function(id) {
    return this.apps.filter(function(a) {
      return a.id === id;
    })[0];
  }, launch: function(app) {
    if (!app || app.launchable === false || app.installed === false) {
      C.toast("This app is no longer installed. Refresh your apps.");
      return;
    }
    if (app.id === "local.tvmorph.tv.kids") {
      C.Kids.open();
      return;
    }
    if (this.preview) {
      C.toast("Browser preview: " + app.name);
      return;
    }
    try {
      tizen.application.launch(app.id, function() {
        var recent = C.read("recent", []).filter(function(id) {
          return id !== app.id;
        });
        recent.unshift(app.id);
        C.write("recent", recent.slice(0, 5));
      }, function(error) {
        if (C.AppCatalog.launchFailure(app, error) && C.refreshAppViews) C.refreshAppViews();
        C.toast("Could not open " + app.name + ". Try opening it from Samsung Apps.");
      });
    } catch (e) {
      C.toast("Could not open " + app.name + ".");
    }
  }, icon: function(app) {
    if (["local.tvmorph.tv.kids", "local.tvmorph.tv.play", "local.tvmorph.tv.radio"].indexOf(app.id) >= 0) {
      var owned = C.el("span", "app-icon ui-owned-app");
      owned.setAttribute("data-owned-app", app.id);
      var name = app.id === "local.tvmorph.tv.radio" ? "radio" : app.id === "local.tvmorph.tv.kids" ? "kids" : "iptv";
      owned.innerHTML = window.MorphIcons ? MorphIcons.svg(name) : C.icon(app.id === "local.tvmorph.tv.radio" ? "music" : "tv");
      return owned;
    }
    if (/^youtube$/i.test(app.name)) {
      var youtube = C.el("span", "app-icon youtube official-youtube");
      youtube.innerHTML = '<svg viewBox="0 0 64 48" aria-hidden="true"><rect x="2" y="4" width="60" height="40" rx="12" fill="#ff0033"/><path d="M27 14v20l17-10Z" fill="#fff"/></svg>';
      return youtube;
    }
    if (app.id === "local.tvmorph.tv.prayer") {
      var prayer = C.el("span", "app-icon prayer-icon");
      prayer.innerHTML = C.icon("moon");
      return prayer;
    }
    var type = /youtube/i.test(app.name) ? "youtube" : /netflix/i.test(app.name) ? "netflix" : /prime|amazon.*video/i.test(app.name) ? "prime" : /disney/i.test(app.name) ? "disney" : /apple.*tv/i.test(app.name) ? "apple-tv" : /spotify/i.test(app.name) ? "spotify" : /settings/i.test(app.name) ? "settings" : /iptv|live|tv/i.test(app.name) ? "television" : /spotify|music/i.test(app.name) ? "music" : /internet/i.test(app.name) ? "internet" : /apps/i.test(app.name) ? "store" : "generic";
    var node = C.el("span", "app-icon " + type);
    var brand = { youtube: "#f43b42", netflix: "#17131b", prime: "#153b6c", disney: "#142961", "apple-tv": "#11141c", spotify: "#11281f", internet: "#285cc0" };
    if (brand[type]) node.style.setProperty("--app-brand-color", brand[type]);
    if (type === "youtube") {
      node.innerHTML = C.icon("play");
    } else if (type === "netflix") {
      node.textContent = "N";
    } else if (type === "prime") {
      node.textContent = "prime\nvideo";
    } else if (type === "disney") {
      node.textContent = "Disney+";
    } else if (type === "apple-tv") {
      node.textContent = "tv+";
    } else if (type === "spotify") {
      node.innerHTML = '<svg viewBox="0 0 64 64" aria-hidden="true"><circle cx="32" cy="32" r="29" fill="#20d779"/><g fill="none" stroke="#092c20" stroke-width="4" stroke-linecap="round"><path d="M16 24q18-7 34 3M19 33q15-5 27 3M22 41q11-3 21 3"/></g></svg>';
    } else if (type === "settings") {
      node.innerHTML = C.icon("settings");
    } else if (type === "television") {
      node.innerHTML = C.icon("tv");
    } else if (type === "music") {
      node.innerHTML = C.icon("music");
    } else if (type === "internet") {
      node.innerHTML = C.icon("globe");
    } else if (type === "store") {
      node.innerHTML = C.icon("store");
    } else {
      node.textContent = app.name.slice(0, 2).toUpperCase();
    }
    if (app.icon) {
      var image = document.createElement("img");
      image.alt = "";
      image.onload = function() {
        node.textContent = "";
        node.appendChild(image);
      };
      image.onerror = function() {
      };
      image.decoding = "async";
      image.src = app.icon.charAt(0) === "/" ? "file://" + app.icon : app.icon;
    }
    return node;
  } };
})(window.ClearTV);
