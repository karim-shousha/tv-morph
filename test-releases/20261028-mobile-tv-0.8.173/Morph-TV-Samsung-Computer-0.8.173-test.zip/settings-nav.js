(function(C) {
  "use strict";
  var root, grid, menu, panels = {}, hosts = {}, active = "", queued = false, organiseSeq = 0, entryCache = { key: "", seq: -1, entries: [] };
  var keys = ["appearance", "performance", "home", "livetv", "prayer", "time", "system", "launcher", "iptv"];
  var rows = { ar: ["\u0627\u0644\u0645\u0638\u0647\u0631 \u0648\u0627\u0644\u062A\u062E\u0635\u064A\u0635", "\u0623\u062F\u0627\u0621 \u0627\u0644\u062A\u0637\u0628\u064A\u0642", "\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629 \u0648\u0627\u0644\u062A\u0637\u0628\u064A\u0642\u0627\u062A", "\u0627\u0644\u0628\u062B \u0627\u0644\u0645\u0628\u0627\u0634\u0631 \u0648\u0627\u0644\u0645\u062F\u0627\u062E\u0644", "\u0645\u0648\u0627\u0642\u064A\u062A \u0627\u0644\u0635\u0644\u0627\u0629 \u0648\u0627\u0644\u0623\u0630\u0627\u0646", "\u0627\u0644\u0648\u0642\u062A \u0648\u0627\u0644\u0637\u0642\u0633", "\u0627\u0644\u0646\u0638\u0627\u0645 \u0648\u0627\u0644\u062C\u0647\u0627\u0632", "\u0627\u0644\u0644\u0627\u0646\u0634\u0631 \u0648\u0627\u0644\u062A\u0634\u063A\u064A\u0644", "\u0625\u0639\u062F\u0627\u062F\u0627\u062A IPTV", "\u0631\u062C\u0648\u0639 \u0644\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A", "\u0642\u0644\u0651\u0644 \u0627\u0644\u0645\u0624\u062B\u0631\u0627\u062A \u0648\u0627\u0644\u062D\u0631\u0643\u0629 \u0644\u062A\u062D\u0633\u064A\u0646 \u0633\u0644\u0627\u0633\u0629 \u0627\u0644\u062A\u0637\u0628\u064A\u0642.", "\u062E\u064A\u0627\u0631\u0627\u062A Home \u0648\u0627\u0644\u062A\u0634\u063A\u064A\u0644 \u062A\u062E\u062A\u0644\u0641 \u062D\u0633\u0628 \u0646\u0638\u0627\u0645 \u0627\u0644\u0634\u0627\u0634\u0629\u061B \u0628\u0639\u0636 \u0627\u0644\u0623\u0646\u0638\u0645\u0629 \u0644\u0627 \u062A\u0633\u0645\u062D \u0628\u0627\u0633\u062A\u0628\u062F\u0627\u0644 \u0648\u0627\u062C\u0647\u062A\u0647\u0627.", "\u0627\u0644\u0633\u0627\u0639\u0629", "\u0627\u0644\u0637\u0642\u0633"], en: ["Appearance", "Performance", "Home & apps", "Live TV & inputs", "Prayer & Adhan", "Time & weather", "System", "Launcher & startup", "IPTV settings", "Back to Settings", "Reduce effects and motion for smoother navigation.", "Home and startup options depend on the TV system; some systems do not permit replacing Home.", "Clock", "Weather"], fr: ["Apparence", "Performance", "Accueil et applis", "TV en direct et entr\xE9es", "Pri\xE8res et Adhan", "Heure et m\xE9t\xE9o", "Syst\xE8me", "Accueil et d\xE9marrage", "R\xE9glages IPTV", "Retour aux param\xE8tres", "R\xE9duisez les effets et animations pour une navigation plus fluide.", "Les options d\u2019accueil et de d\xE9marrage d\xE9pendent du syst\xE8me du t\xE9l\xE9viseur.", "Horloge", "M\xE9t\xE9o"], zh: ["\u5916\u89C2", "\u6027\u80FD", "\u4E3B\u9875\u4E0E\u5E94\u7528", "\u76F4\u64AD\u4E0E\u8F93\u5165", "\u793C\u62DC\u4E0E\u5BA3\u793C", "\u65F6\u95F4\u4E0E\u5929\u6C14", "\u7CFB\u7EDF", "\u4E3B\u5C4F\u5E55\u4E0E\u542F\u52A8", "IPTV \u8BBE\u7F6E", "\u8FD4\u56DE\u8BBE\u7F6E", "\u51CF\u5C11\u6548\u679C\u548C\u52A8\u753B\u4EE5\u6539\u5584\u5BFC\u822A\u6D41\u7545\u5EA6\u3002", "\u4E3B\u9875\u4E0E\u542F\u52A8\u9009\u9879\u53D6\u51B3\u4E8E\u7535\u89C6\u7CFB\u7EDF\uFF1B\u90E8\u5206\u7CFB\u7EDF\u4E0D\u5141\u8BB8\u66F4\u6362\u4E3B\u9875\u3002", "\u65F6\u949F", "\u5929\u6C14"], ja: ["\u5916\u89B3", "\u30D1\u30D5\u30A9\u30FC\u30DE\u30F3\u30B9", "\u30DB\u30FC\u30E0\u3068\u30A2\u30D7\u30EA", "\u30E9\u30A4\u30D6TV\u3068\u5165\u529B", "\u793C\u62DD\u3068\u30A2\u30B6\u30FC\u30F3", "\u6642\u523B\u3068\u5929\u6C17", "\u30B7\u30B9\u30C6\u30E0", "\u30DB\u30FC\u30E0\u3068\u8D77\u52D5", "IPTV \u8A2D\u5B9A", "\u8A2D\u5B9A\u306B\u623B\u308B", "\u52B9\u679C\u3068\u30A2\u30CB\u30E1\u30FC\u30B7\u30E7\u30F3\u3092\u6E1B\u3089\u3057\u3066\u64CD\u4F5C\u3092\u8EFD\u304F\u3057\u307E\u3059\u3002", "\u30DB\u30FC\u30E0\u3068\u8D77\u52D5\u306E\u8A2D\u5B9A\u306F\u30C6\u30EC\u30D3\u306E\u30B7\u30B9\u30C6\u30E0\u306B\u3088\u3063\u3066\u7570\u306A\u308A\u307E\u3059\u3002", "\u6642\u8A08", "\u5929\u6C17"] };
  var placements = { appearance: ["#setting-text-size-ar", "#setting-text-size-en", "#setting-theme", "#settings-theme-packs"], performance: ["#setting-performance", "#setting-motion"], home: ["#setting-recent-apps", "#setting-kids-home", "#setting-favourites", "#setting-parental-controls"], livetv: ["#setting-home-hdmi", "#setting-last-hdmi"], iptv: ["#setting-iptv-account"], system: ["#setting-device-settings", "#setting-app-update", "#setting-wifi", ".morph-plus-setting", "#setting-about", "#setting-support"] };
  function words() {
    return rows[window.MorphLocale ? MorphLocale.get() : "en"] || rows.en;
  }
  function paint() {
    var w = words();
    if (menu) menu.dir = window.MorphLocale && MorphLocale.get() === "ar" ? "rtl" : "ltr";
    keys.forEach(function(k, i) {
      var entry = document.getElementById("settings-category-" + k + "-entry");
      if (entry) entry.querySelector("strong").textContent = w[i];
      var back = document.querySelector("#settings-category-" + k + ">button");
      if (back) back.textContent = w[9];
      if (hosts[k]) hosts[k].querySelector("h2").textContent = w[i];
    });
    var note = document.getElementById("settings-performance-note");
    if (note) note.textContent = w[10];
    var hint = document.getElementById("settings-launcher-note");
    if (hint) hint.textContent = w[11];
    subheads(w);
  }
  function organise() {
    queued = false;
    if (!root) return;
    organiseSeq++;
    entryCache.seq = -1;
    Object.keys(placements).forEach(function(key) {
      var target = hosts[key], nodes = placements[key].map(function(selector) {
        return root.querySelector(selector);
      }).filter(Boolean);
      var current = Array.prototype.filter.call(target.children, function(n) {
        return n.classList.contains("setting") && nodes.indexOf(n) >= 0;
      });
      if (nodes.some(function(n, i) {
        return n.parentNode !== target || current[i] !== n;
      })) nodes.forEach(function(n) {
        target.appendChild(n);
      });
    });
    var hint = document.getElementById("settings-launcher-note");
    hint.hidden = !!hosts.launcher.querySelector(".setting");
    document.getElementById("settings-category-iptv-entry").hidden = !hosts.iptv.querySelector(".setting");
    document.getElementById("settings-category-launcher-entry").hidden = !hosts.launcher.querySelector(".setting");
    if (C.Focus.invalidate) C.Focus.invalidate();
  }
  function schedule() {
    if (queued) return;
    queued = true;
    setTimeout(organise, 0);
  }
  function subheads(w) {
    w = w || words();
    [["#setting-clock", 12], ["#setting-units", 13]].forEach(function(pair) {
      var anchor = root && root.querySelector(pair[0]);
      if (!anchor) return;
      var prev = anchor.previousElementSibling;
      if (prev && prev.classList.contains("settings-subhead")) {
        prev.textContent = w[pair[1]];
        return;
      }
      var h = document.createElement("h3");
      h.className = "settings-subhead";
      h.setAttribute("data-no-translate", "");
      h.textContent = w[pair[1]];
      anchor.parentNode.insertBefore(h, anchor);
    });
  }
  function home() {
    if (!root) return;
    active = "";
    root.classList.remove("prayer-settings-mode");
    menu.hidden = false;
    keys.forEach(function(k) {
      panels[k].hidden = true;
    });
    root.scrollTop = 0;
    if (C.Prayer) C.Prayer.settingsEntered();
  }
  function open(key) {
    if (!panels[key]) return;
    organise();
    active = key;
    menu.hidden = true;
    keys.forEach(function(k) {
      panels[k].hidden = k !== key;
    });
    root.scrollTop = 0;
    if (key === "prayer" && C.Prayer && C.Prayer.showSettings) C.Prayer.showSettings();
    else C.Focus.focus(panels[key].querySelector("button"));
  }
  function listEntries(area) {
    if (entryCache.key === active && entryCache.seq === organiseSeq && entryCache.entries.length) return entryCache.entries;
    var entries = Array.prototype.filter.call(area.querySelectorAll("button:not([disabled]),input:not([disabled]),select:not([disabled])"), function(e) {
      return e.tabIndex !== -1 && !e.disabled && !e.hidden && !e.closest("[hidden]");
    });
    entryCache = { key: active, seq: organiseSeq, entries };
    return entries;
  }
  function arrow(code, current) {
    if (code !== 38 && code !== 40 || !active || active === "prayer" || !root || root.hidden) return false;
    var area = panels[active];
    if (!current || !area.contains(current)) return false;
    var entries = listEntries(area);
    var index = entries.indexOf(current);
    if (index < 0) {
      entryCache.seq = -1;
      entries = listEntries(area);
      index = entries.indexOf(current);
    }
    if (index < 0) return false;
    var next = index + (code === 40 ? 1 : -1);
    if (next < 0) C.Focus.focus(document.getElementById("nav-settings"));
    else if (next < entries.length) C.Focus.focus(entries[next]);
    return true;
  }
  C.SettingsNav = { arrow, home, open, refresh: organise, back: function() {
    if (!root || root.hidden || !active) return false;
    var key = active;
    home();
    C.Focus.focus(document.getElementById("settings-category-" + key + "-entry"));
    return true;
  } };
  window.addEventListener("load", function() {
    root = document.getElementById("view-settings");
    grid = root.querySelector(".settings-grid");
    var existing = Array.prototype.slice.call(grid.children);
    menu = C.el("div", "settings-category-menu");
    menu.id = "settings-categories-menu";
    menu.setAttribute("data-no-translate", "");
    var icons = ["sun", "settings", "apps", "tv", "moon", "clock", "settings", "tv", "tv"];
    keys.forEach(function(key, index) {
      var entry = C.el("button", "settings-category-entry");
      entry.id = "settings-category-" + key + "-entry";
      entry.innerHTML = C.icon(icons[index]) + "<strong></strong>";
      entry.onclick = function() {
        open(key);
      };
      menu.appendChild(entry);
      var area = C.el("section", "settings-category-panel");
      area.id = "settings-category-" + key;
      area.hidden = true;
      var back = C.el("button", "secondary");
      back.setAttribute("data-no-translate", "");
      back.onclick = function() {
        C.SettingsNav.back();
      };
      area.appendChild(back);
      if (key !== "time" && key !== "prayer") {
        var host = C.el("section", "settings-panel");
        var title = C.el("h2");
        title.setAttribute("data-no-translate", "");
        host.appendChild(title);
        area.appendChild(host);
        hosts[key] = host;
      }
      grid.appendChild(area);
      panels[key] = area;
    });
    root.insertBefore(menu, grid);
    existing.forEach(function(panel) {
      if (panel.id === "prayer-settings-section") panels.prayer.appendChild(panel);
      else if (panel.querySelector("#setting-clock")) panels.time.appendChild(panel);
      else {
        Array.prototype.slice.call(panel.children).forEach(function(child) {
          if (child.tagName !== "H2") hosts.system.appendChild(child);
        });
        panel.remove();
      }
    });
    var note = C.el("p");
    note.id = "settings-performance-note";
    note.setAttribute("data-no-translate", "");
    hosts.performance.appendChild(note);
    var hint = C.el("p");
    hint.id = "settings-launcher-note";
    hint.setAttribute("data-no-translate", "");
    hosts.launcher.appendChild(hint);
    paint();
    home();
    schedule();
    new MutationObserver(function(records) {
      if (records.some(function(r) {
        return Array.prototype.some.call(r.addedNodes, function(n) {
          return n.nodeType === 1 && (n.classList.contains("setting") || n.querySelector(".setting"));
        });
      })) schedule();
    }).observe(root, { childList: true, subtree: true });
  });
  window.addEventListener("morphLanguage", paint);
})(window.ClearTV);
