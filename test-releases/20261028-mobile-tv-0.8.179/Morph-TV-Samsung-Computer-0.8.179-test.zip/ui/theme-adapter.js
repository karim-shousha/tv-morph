(function(w) {
  "use strict";
  var C = w.ClearTV || {}, base = { blue: ["#63caff", "#14283e"], night: ["#8aaeff", "#101421"], emerald: ["#68e8ba", "#0d302e"], amber: ["#ffc680", "#302017"], violet: ["#cda2ff", "#241632"], ahly: ["#ff5470", "#8c1831"] };
  var keys = ["ac-milan-legends", "blue", "night", "emerald", "amber", "violet", "ahly", "zamalek", "barcelona", "madrid", "egypt", "basketball", "baseball", "montreal", "toronto", "argentina", "portugal", "ismaily", "king-salman", "crown-prince", "nassr", "hilal", "ittihad", "ahli-saudi", "inter-miami", "saudi-national", "egypt-national", "blue-cinema", "gta6"];
  var scenes = { "ac-milan-legends": true, "night": true, "gta6": true, "blue-cinema": true, "saudi-national": true, "egypt-national": true };
  function hex(v, fallback) {
    return /^#[0-9a-f]{6}$/i.test(v || "") ? v : fallback;
  }
  function rgb(s) {
    return [parseInt(s.substr(1, 2), 16), parseInt(s.substr(3, 2), 16), parseInt(s.substr(5, 2), 16)];
  }
  function rgba(s, a) {
    return "rgba(" + rgb(s).join(",") + "," + a + ")";
  }
  function mix(a, b, t) {
    var x = rgb(a), y = rgb(b);
    return "#" + x.map(function(n, i) {
      var v = Math.round(n + (y[i] - n) * t).toString(16);
      return v.length < 2 ? "0" + v : v;
    }).join("");
  }
  function luminance(s) {
    return rgb(s).map(function(v) {
      v /= 255;
      return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
    }).reduce(function(sum, v, i) {
      return sum + v * [0.2126, 0.7152, 0.0722][i];
    }, 0);
  }
  function readable(text, bg, minimum) {
    var value = text;
    for (var i = 0; i < 12; i++) {
      var a = luminance(value), b = luminance(bg);
      if ((Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05) >= minimum) return value;
      value = mix(value, "#ffffff", 0.22);
    }
    return "#ffffff";
  }
  function resolve(settings) {
    var s = settings || {}, id = keys.indexOf(s.theme) >= 0 ? s.theme : "blue", club = (C.ClubThemes || w.MorphThemeIdentities || {})[id] || {}, p = base[id] || ["#63caff", "#14283e"];
    var accent = hex(s.highlightColor, hex(s.accent, hex(club.primary, p[0]))), identity = hex(club.secondary, p[1]), bg = hex(s.backgroundStart, mix(identity, "#030610", id === "ahly" ? 0.45 : 0.7)), raised = mix(hex(s.cardColor, identity), "#050916", 0.45);
    while (luminance(raised) > 0.075) raised = mix(raised, "#050916", 0.12);
    var focus = readable(accent, raised, 4.5), text = readable(hex(s.textColor, "#f7f9ff"), raised, 7), secondary = id === "blue" || id === "blue-cinema" ? "#a88aff" : readable(mix(accent, identity, 0.25), raised, 3);
    var reference = ["blue", "blue-cinema", "gta6"].indexOf(id) >= 0 && !hex(s.highlightColor, hex(s.accent, "")), neonA = reference ? "#36bfff" : focus, neonB = reference ? "#7045ff" : secondary;
    var opacity = Math.max(0.48, Math.min(0.88, 0.42 + (Number(s.glassOpacity) || 18) / 150)), custom = /^data:image\/(png|jpeg|webp);base64,/.test(s.artImage || ""), slides = s.slideshowEnabled && Array.isArray(s.backgroundImages) && s.backgroundImages.length;
    return { theme: id, art: { fit: "contain", position: club.portrait ? "right center" : "right top", width: custom || slides || scenes[id] ? "100%" : club.portrait ? "66%" : "78%", height: "100%", custom, slideshow: !!slides, source: custom ? s.artImage : club.art || (id === "ahly" ? "al-ahly-duel.webp" : "") }, tokens: {
      "--ui-bg": bg,
      "--ui-bg-raised": raised,
      "--ui-glass-color": identity,
      "--ui-glass-opacity": String(opacity),
      "--ui-card-bg": rgba(raised, 0.8),
      "--ui-card-border": rgba(focus, 0.28),
      "--ui-text": text,
      "--ui-text-muted": readable(mix(text, raised, 0.24), raised, 4.5),
      "--ui-accent": accent,
      "--ui-accent-secondary": secondary,
      "--ui-button-gradient": "linear-gradient(120deg," + accent + "," + secondary + ")",
      "--ui-neon-a": neonA,
      "--ui-neon-b": neonB,
      "--ui-neon-halo": rgba(neonA, 0.65),
      "--ui-neon-halo-secondary": rgba(neonB, 0.6),
      "--ui-focus-surface-a": rgba(neonB, 0.38),
      "--ui-focus-surface-b": rgba(neonA, 0.25),
      "--ui-focus-ring": focus,
      "--ui-focus-glow": rgba(focus, 0.38),
      "--ui-dock-bg": rgba(raised, opacity),
      "--ui-dock-border": rgba(focus, 0.3),
      "--ui-art-scrim": id === "ac-milan-legends" ? "linear-gradient(90deg,rgba(15,3,8,.58),rgba(24,4,10,.12) 45%,transparent 80%)" : id === "ahly" ? "linear-gradient(90deg,rgba(105,9,31,.62),rgba(151,17,46,.22) 48%,rgba(151,17,46,.06) 80%)" : id === "night" ? "linear-gradient(90deg,rgba(3,9,22,.5),rgba(3,9,22,.12) 55%,transparent)" : "linear-gradient(90deg," + rgba(mix(bg, "#030610", 0.7), 0.96) + "," + rgba(mix(bg, "#030610", 0.7), 0.68) + " 33%," + rgba(bg, 0.08) + " 73%)",
      "--ui-overlay-bg": rgba(bg, 0.9),
      "--ui-art-width": custom || slides || scenes[id] ? "100%" : club.portrait ? "66%" : "78%",
      "--ui-art-position": club.portrait ? "right center" : "right top",
      "--ui-art-fit": "contain"
    } };
  }
  function apply() {
    var value = resolve(C.settings);
    Object.keys(value.tokens).forEach(function(key) {
      document.body.style.setProperty(key, value.tokens[key]);
    });
    document.body.setAttribute("data-ui-theme", value.theme);
    return value;
  }
  w.MorphThemeAdapter = { keys: keys.slice(), resolve, apply, contrast: function(a, b) {
    var x = luminance(a), y = luminance(b);
    return (Math.max(x, y) + 0.05) / (Math.min(x, y) + 0.05);
  } };
})(window);
