(function(w) {
  "use strict";
  var words = { ar: ["\u0627\u0644\u062D\u0627\u0644\u0629", "\u064A\u0646\u062A\u0647\u064A \u0641\u064A", "\u0627\u0644\u0645\u062A\u0628\u0642\u064A", "\u064A\u0648\u0645", "\u0627\u0646\u062A\u0647\u0649 \u0627\u0644\u0627\u0634\u062A\u0631\u0627\u0643", "\u0627\u0644\u0645\u0632\u0648\u0651\u062F \u0644\u0627 \u064A\u0648\u0641\u0651\u0631 \u0645\u062F\u0629 \u0627\u0644\u0627\u0634\u062A\u0631\u0627\u0643", "\u063A\u064A\u0631 \u0645\u062D\u062F\u0648\u062F", "\u0627\u0644\u0627\u062A\u0635\u0627\u0644\u0627\u062A", "\u0622\u062E\u0631 \u062A\u062D\u0642\u0642", "\u0644\u0645 \u064A\u062A\u0645 \u0627\u0644\u062A\u062D\u0642\u0642 \u0628\u0639\u062F"], en: ["Status", "Expires", "Remaining", "days", "Expired", "The provider does not supply an expiry date", "Unlimited", "Connections", "Last checked", "Not checked yet"], fr: ["Statut", "Expiration", "Restant", "jours", "Expir\xE9", "Le fournisseur ne donne pas de date", "Illimit\xE9", "Connexions", "Derni\xE8re v\xE9rification", "Pas encore v\xE9rifi\xE9"], zh: ["\u72B6\u6001", "\u5230\u671F", "\u5269\u4F59", "\u5929", "\u5DF2\u5230\u671F", "\u4F9B\u5E94\u5546\u672A\u63D0\u4F9B\u5230\u671F\u65E5\u671F", "\u65E0\u9650\u5236", "\u8FDE\u63A5\u6570", "\u4E0A\u6B21\u68C0\u67E5", "\u5C1A\u672A\u68C0\u67E5"], ja: ["\u72B6\u614B", "\u6709\u52B9\u671F\u9650", "\u6B8B\u308A", "\u65E5", "\u671F\u9650\u5207\u308C", "\u63D0\u4F9B\u5143\u304B\u3089\u6709\u52B9\u671F\u9650\u306E\u60C5\u5831\u304C\u3042\u308A\u307E\u305B\u3093", "\u7121\u671F\u9650", "\u63A5\u7D9A\u6570", "\u6700\u7D42\u78BA\u8A8D", "\u672A\u78BA\u8A8D"] };
  function describe(info, language, brief) {
    info = info || {};
    var t = words[language] || words.en, raw = String(info.expires == null ? "" : info.expires).trim(), expiry = /^\d+(\.\d+)?$/.test(raw) ? Number(raw) : 0;
    if (expiry > 1e11) expiry /= 1e3;
    var now = Date.now() / 1e3, lines = [], remaining = expiry > 0 ? expiry - now : null;
    function date(v) {
      try {
        return new Date(v * 1e3).toLocaleDateString(language || "en");
      } catch (e) {
        return new Date(v * 1e3).toISOString().slice(0, 10);
      }
    }
    if (remaining !== null) {
      if (brief) return remaining <= 0 ? t[4] : Math.ceil(remaining / 86400) + " " + t[3];
      lines.push(t[1] + ": " + date(expiry));
      lines.push(remaining <= 0 ? t[4] : t[2] + ": " + Math.ceil(remaining / 86400) + " " + t[3]);
    } else {
      var text = /^(unlimited|infinite)$/i.test(raw) ? t[6] : t[5];
      if (brief) return text;
      lines.push(text);
    }
    if (info.status) lines.unshift(t[0] + ": " + String(info.status).slice(0, 60));
    if (/^\d+$/.test(String(info.maxConnections || "")) && Number(info.maxConnections) > 0) lines.push(t[7] + ": " + (Number(info.activeConnections) || 0) + " / " + info.maxConnections);
    lines.push(Number(info.checkedAt) > 0 ? t[8] + ": " + date(Number(info.checkedAt)) : t[9]);
    return lines.join("\n");
  }
  w.IptvAccountText = { describe };
})(window);
