(function() {
  "use strict";
  var label = "Kidsy \xB7 \u0643\u064A\u062F\u0632\u064A", description = "\u0642\u0646\u0627\u0629 \u0627\u0644\u0623\u0637\u0641\u0627\u0644 \xB7 Kids live TV";
  function open() {
    if (window.TvIptvLayout && TvIptvLayout.stopLivePreview) TvIptvLayout.stopLivePreview();
    if (window.IptvNative && typeof IptvNative.kids === "function") {
      IptvNative.kids();
      return;
    }
    var note = document.getElementById("dashboard-status");
    if (note) note.textContent = "Open Kidsy in the installed Morph TV app.";
  }
  var nav = document.querySelector("header nav"), grid = document.querySelector(".portal-grid");
  if (!nav || !grid) return;
  var tab = document.createElement("button");
  tab.id = "kidsy-open";
  tab.textContent = label;
  tab.setAttribute("data-no-translate", "");
  tab.onclick = open;
  nav.appendChild(tab);
  var card = document.createElement("button");
  card.id = "home-kidsy";
  card.setAttribute("data-no-translate", "");
  card.innerHTML = '<span class="kidsy-glyph" aria-hidden="true">\u25B6</span><strong></strong><small></small>';
  card.querySelector("strong").textContent = label;
  card.querySelector("small").textContent = description;
  card.onclick = open;
  grid.appendChild(card);
  var style = document.createElement("style");
  style.textContent = "#home-kidsy{background:linear-gradient(135deg,#301d60,#12617c)!important;position:relative;overflow:hidden}#home-kidsy .kidsy-glyph{display:block;font-size:42px;color:#86f0e3;margin-bottom:10px}#home-kidsy strong,#home-kidsy small{position:relative;z-index:1}.portal-grid{grid-template-columns:repeat(auto-fit,minmax(210px,1fr))}";
  document.head.appendChild(style);
})();
