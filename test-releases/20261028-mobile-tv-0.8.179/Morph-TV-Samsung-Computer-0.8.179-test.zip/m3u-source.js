(function(w) {
  "use strict";
  var PUBLIC = "https://iptv-org.github.io/iptv/languages/ara.m3u", records = {}, jobs = {};
  var publicSources = [{ id: "arabic", url: PUBLIC, ar: "\u0627\u0644\u0642\u0646\u0648\u0627\u062A \u0627\u0644\u0646\u0627\u0637\u0642\u0629 \u0628\u0627\u0644\u0639\u0631\u0628\u064A\u0629", en: "Arabic-language channels" }, { id: "arab-region", url: "https://iptv-org.github.io/iptv/regions/arab.m3u", ar: "\u0642\u0646\u0648\u0627\u062A \u0627\u0644\u0645\u0646\u0637\u0642\u0629 \u0627\u0644\u0639\u0631\u0628\u064A\u0629", en: "Arab-region channels" }, { id: "news", url: "https://iptv-org.github.io/iptv/categories/news.m3u", ar: "\u0642\u0646\u0648\u0627\u062A \u0627\u0644\u0623\u062E\u0628\u0627\u0631 \u0627\u0644\u0639\u0627\u0644\u0645\u064A\u0629", en: "World news channels" }];
  function publicSource(value) {
    var key = typeof value === "string" ? value : value && value.publicSource, url = value && value.server;
    return publicSources.filter(function(s) {
      return s.id === key;
    })[0] || publicSources.filter(function(s) {
      return s.url === url;
    })[0] || publicSources[0];
  }
  function valid(value, base) {
    var u = new URL(value, base);
    if (/[,،]/.test(u.hostname)) throw Error("Check the server address: use a dot (.) instead of a comma (,).");
    if (!/^https?:$/.test(u.protocol) || u.username || u.password || u.href.length > 4e3) throw Error("Use a full HTTP or HTTPS M3U playlist URL.");
    return u.href;
  }
  function id(value) {
    var h = 2166136261, j = 2166136261;
    for (var i = 0; i < value.length; i++) {
      h = Math.imul(h ^ value.charCodeAt(i), 16777619);
      j = Math.imul(j ^ value.charCodeAt(i), 2246822519);
    }
    return String((h >>> 0) * 4096 + (j >>> 20));
  }
  function attr(line, name) {
    var m = new RegExp("(?:^|\\s)" + name + "\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s,]+))", "i").exec(line);
    return m ? m[1] || m[2] || m[3] || "" : "";
  }
  function comma(line) {
    var quote = "";
    for (var i = 0; i < line.length; i++) {
      var c = line.charAt(i);
      if (quote) {
        if (c === quote) quote = "";
      } else if (c === '"' || c === "'") quote = c;
      else if (c === ",") return i;
    }
    return -1;
  }
  function parse(body, base) {
    if (!body.replace(/\uFEFF/g, "").trim().startsWith("#EXTM3U") || /#EXT-X-(TARGETDURATION|STREAM-INF)/.test(body)) throw Error("Use a channel M3U playlist, not a single HLS video manifest.");
    var rows = [], categories = [], streams = {}, seen = {}, meta = "", group = "";
    body.split(/\r?\n/).some(function(raw) {
      var line = raw.trim();
      if (line.indexOf("#EXTINF:") === 0) {
        meta = line;
        group = attr(meta, "group-title");
      } else if (line.indexOf("#EXTGRP:") === 0) group = line.slice(8).trim();
      else if (line && line.charAt(0) !== "#") {
        var url;
        try {
          url = valid(line, base);
        } catch (e) {
          meta = "";
          group = "";
          return false;
        }
        var key = id(url);
        if (streams[key]) {
          meta = "";
          group = "";
          return false;
        }
        var at = comma(meta), name = (at >= 0 ? meta.slice(at + 1).trim() : attr(meta, "tvg-name")) || "Channel " + (rows.length + 1), icon = attr(meta, "tvg-logo");
        try {
          if (icon) icon = valid(icon, base);
        } catch (e) {
          icon = "";
        }
        group = group || "General";
        var cat = id(group);
        if (!seen[cat]) {
          seen[cat] = true;
          categories.push({ category_id: cat, category_name: group.slice(0, 160) });
        }
        rows.push({ id: key, name: name.slice(0, 250), icon, category: cat, group: group.slice(0, 160), kind: "live", ext: "m3u8" });
        streams[key] = url;
        meta = "";
        group = "";
      }
      return rows.length >= 2e4;
    });
    if (!rows.length) throw Error("No supported HTTP channel links in this playlist.");
    return { rows, categories, stream: function(item) {
      var key = typeof item === "string" ? item : item.id;
      if (typeof item === "object" && item.kind !== "live" || !streams[key]) throw Error("Select a channel from the current playlist.");
      return streams[key];
    }, at: Date.now() };
  }
  function load(url) {
    url = valid(url);
    if (records[url] && Date.now() - records[url].at < 6e5) return Promise.resolve(records[url]);
    if (jobs[url]) return jobs[url];
    var task = new Promise(function(resolve, reject) {
      var x = new XMLHttpRequest();
      x.open("GET", url, true);
      x.timeout = 3e4;
      x.onprogress = function(e) {
        if (e.loaded > 12 * 1024 * 1024) {
          x.abort();
          reject(Error("Playlist too large."));
        }
      };
      x.onload = function() {
        try {
          if (x.status !== 200 || x.responseText.length > 12 * 1024 * 1024) throw Error("Playlist unavailable. Check the URL, connection or CORS support.");
          var value = parse(x.responseText, x.responseURL || url);
          records[url] = value;
          var keys = Object.keys(records);
          while (keys.length > 2) delete records[keys.shift()];
          resolve(value);
        } catch (e) {
          reject(e);
        }
      };
      x.onerror = x.ontimeout = x.onabort = function() {
        reject(Error("Could not load the M3U playlist. Check the URL, connection and CORS support."));
      };
      x.send();
    });
    jobs[url] = task;
    task.then(function() {
      delete jobs[url];
    }, function() {
      delete jobs[url];
    });
    return task;
  }
  w.M3uSource = { publicURL: PUBLIC, publicSources, publicSource, valid, parse, load, id, clear: function() {
    records = {};
  } };
})(window);
