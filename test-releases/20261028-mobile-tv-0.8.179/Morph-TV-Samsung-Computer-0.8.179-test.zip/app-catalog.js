(function(C) {
  "use strict";
  function normalize(rows, platform, source) {
    var result = [], seen = /* @__PURE__ */ Object.create(null);
    (Array.isArray(rows) ? rows : []).forEach(function(a) {
      if (!a || typeof a.id !== "string" || !a.id.trim()) return;
      var id = a.id.trim(), item = {};
      if (id === "local.tvmorph.tv.kids") return;
      Object.keys(a).forEach(function(k) {
        item[k] = a[k];
      });
      item.id = id;
      item.name = String(a.name || a.title || id).trim() || id;
      item.icon = typeof a.iconPath === "string" && a.iconPath || typeof a.icon === "string" && a.icon || "";
      item.platform = a.platform || platform;
      item.discoverySource = a.discoverySource || source;
      item.installed = a.installed === null ? null : a.installed !== false;
      item.launchable = a.launchable !== false && item.installed !== false;
      item.hidden = a.hidden === true || a.visible === false || a.show === false;
      item.visibilityStatus = item.hidden ? "hidden" : item.installed === false ? "unavailable" : item.installed === null ? "unverified" : "visible";
      if (seen[id] !== void 0) {
        var old = result[seen[id]];
        if (!old.icon && item.icon) old.icon = item.icon;
        return;
      }
      seen[id] = result.length;
      result.push(item);
    });
    return result;
  }
  function visible(a) {
    return !!a && !a.hidden && a.show !== false && a.visible !== false && a.installed !== false;
  }
  function signature(rows) {
    return JSON.stringify(rows.map(function(a) {
      return [a.id, a.name, a.icon, a.launchable, a.installed, a.hidden];
    }).sort(function(a, b) {
      return a[0].localeCompare(b[0]);
    }));
  }
  function commit(catalog, rows, platform, source) {
    var next = normalize(rows, platform, source), order = /* @__PURE__ */ Object.create(null), base = (catalog.apps || []).length;
    (catalog.apps || []).forEach(function(a, i) {
      order[a.id] = i;
    });
    next.forEach(function(a, i) {
      if (order[a.id] === void 0) order[a.id] = base + i;
    });
    next.sort(function(a, b) {
      return order[a.id] - order[b.id];
    });
    catalog.changed = signature(catalog.apps || []) !== signature(next);
    catalog.apps = next;
    catalog.refreshedAt = Date.now();
    return next;
  }
  function launchFailure(app, error) {
    var code = Number(error && error.code), name = error && error.name;
    if (code === -101 || name === "NotFoundError") {
      app.installed = false;
      app.launchable = false;
      return true;
    }
    if (code === -104 || code === -106 || name === "SecurityError" || name === "NotSupportedError") {
      app.launchable = false;
      return true;
    }
    return false;
  }
  C.AppCatalog = { launchFailure, normalize, visible, commit, signature };
})(window.ClearTV);
