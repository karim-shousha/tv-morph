(function(C) {
  "use strict";
  var modes = ["quality", "balanced", "performance"];
  var legacy = { light: "performance", full: "quality", auto: "balanced" };
  var legacyOut = { quality: "full", balanced: "light", performance: "light" };
  var rows = {
    en: ["Performance mode", "Quality", "Balanced", "Performance", "Quality: full effects, no compromises.", "Balanced: full effects with efficient background work.", "Performance: reduced effects for the smoothest navigation."],
    ar: ["\u0648\u0636\u0639 \u0627\u0644\u0623\u062F\u0627\u0621", "\u062C\u0648\u062F\u0629", "\u0645\u062A\u0648\u0627\u0632\u0646", "\u0623\u062F\u0627\u0621", "\u062C\u0648\u062F\u0629: \u0645\u0624\u062B\u0631\u0627\u062A \u0643\u0627\u0645\u0644\u0629 \u0628\u062F\u0648\u0646 \u062A\u0646\u0627\u0632\u0644\u0627\u062A.", "\u0645\u062A\u0648\u0627\u0632\u0646: \u0645\u0624\u062B\u0631\u0627\u062A \u0643\u0627\u0645\u0644\u0629 \u0645\u0639 \u0639\u0645\u0644 \u062E\u0644\u0641\u064A\u0629 \u0641\u0639\u0627\u0644.", "\u0623\u062F\u0627\u0621: \u0645\u0624\u062B\u0631\u0627\u062A \u0645\u062E\u0641\u0641\u0629 \u0644\u0623\u0633\u0631\u0639 \u062A\u0646\u0642\u0644."],
    fr: ["Mode de performance", "Qualit\xE9", "\xC9quilibr\xE9", "Performance", "Qualit\xE9 : effets complets.", "\xC9quilibr\xE9 : effets complets, arri\xE8re-plan efficace.", "Performance : effets r\xE9duits pour une navigation fluide."],
    zh: ["\u6027\u80FD\u6A21\u5F0F", "\u753B\u8D28", "\u5747\u8861", "\u6027\u80FD", "\u753B\u8D28\uFF1A\u5B8C\u6574\u6548\u679C\u3002", "\u5747\u8861\uFF1A\u5B8C\u6574\u6548\u679C\uFF0C\u540E\u53F0\u9AD8\u6548\u3002", "\u6027\u80FD\uFF1A\u51CF\u5C11\u6548\u679C\uFF0C\u5BFC\u822A\u6700\u6D41\u7545\u3002"],
    ja: ["\u30D1\u30D5\u30A9\u30FC\u30DE\u30F3\u30B9", "\u54C1\u8CEA", "\u30D0\u30E9\u30F3\u30B9", "\u30D1\u30D5\u30A9\u30FC\u30DE\u30F3\u30B9", "\u54C1\u8CEA\uFF1A\u5B8C\u5168\u306A\u52B9\u679C\u3002", "\u30D0\u30E9\u30F3\u30B9\uFF1A\u5B8C\u5168\u306A\u52B9\u679C\u3067\u52B9\u7387\u7684\u306A\u52D5\u4F5C\u3002", "\u30D1\u30D5\u30A9\u30FC\u30DE\u30F3\u30B9\uFF1A\u8EFD\u91CF\u306A\u52B9\u679C\u3067\u6ED1\u3089\u304B\u306A\u64CD\u4F5C\u3002"]
  };
  function canon(value) {
    if (modes.indexOf(value) >= 0) return value;
    if (Object.prototype.hasOwnProperty.call(legacy, value)) return legacy[value];
    return "performance";
  }
  var stored = C.read("performanceMode", "performance"), device = {}, nativeProvided = false;
  var mode = canon(stored === "auto" ? "balanced" : stored);
  try {
    if (window.TVNative && TVNative.deviceInfo) device = JSON.parse(TVNative.deviceInfo());
  } catch (e) {
  }
  if (window.MorphTVCompatibility && MorphTVCompatibility.legacyLayout) device.lowMemory = true;
  var ua = navigator.userAgent || "", tv = ua.match(/Tizen[ \/]([0-9]+)/i);
  if (tv && Number(tv[1]) <= 6 || navigator.deviceMemory && navigator.deviceMemory <= 2 || navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2) device.lowMemory = true;
  try {
    if (window.TVNative) {
      var saved = TVNative.performanceTier ? TVNative.performanceTier() : "";
      if (modes.indexOf(saved) >= 0) {
        mode = saved;
        nativeProvided = true;
      } else if (modes.indexOf(C.read("performanceMode", "")) < 0 && TVNative.performanceMode) {
        saved = TVNative.performanceMode();
        if (saved) {
          mode = canon(saved);
          nativeProvided = true;
        }
      }
    }
  } catch (e) {
  }
  if (!C.read("performanceDefault140", false) && !nativeProvided) {
    if (modes.indexOf(C.read("performanceMode", "performance")) < 0) {
      var prev = C.read("performanceMode", "performance");
      mode = prev === "full" ? "quality" : prev === "auto" ? device.lowMemory === true ? "performance" : "balanced" : "performance";
    }
    C.write("performanceMode", mode);
    C.write("performanceDefault140", true);
    try {
      if (window.TVNative && TVNative.setPerformanceMode) TVNative.setPerformanceMode(legacyOut[mode]);
    } catch (e) {
    }
  }
  function saveNativeTier() {
    try {
      if (window.TVNative && TVNative.setPerformanceTier) TVNative.setPerformanceTier(mode);
      else if (window.TVNative && TVNative.setPerformanceMode) TVNative.setPerformanceMode(legacyOut[mode]);
    } catch (e) {
    }
  }
  saveNativeTier();
  function words() {
    return rows[window.MorphLocale ? MorphLocale.get() : "en"] || rows.en;
  }
  function isLight() {
    return mode === "performance";
  }
  function labelIndex() {
    return mode === "quality" ? 1 : mode === "balanced" ? 2 : 3;
  }
  function apply() {
    document.body.classList.toggle("light-mode", isLight());
    if (C.refreshDockReflections) {
      try {
        C.refreshDockReflections();
      } catch (e) {
      }
    }
    if (button) {
      var w = words();
      button.textContent = w[0] + " \xB7 " + w[labelIndex()];
      button.title = w[labelIndex() + 3];
    }
    if (C.applyRemoteConfig) C.applyRemoteConfig({});
    window.dispatchEvent(new Event("morphPerformance"));
  }
  C.Performance = {
    isLight,
    tier: function() {
      return mode;
    },
    get: function() {
      return mode;
    },
    set: function(value) {
      value = canon(value);
      if (value === mode) {
        apply();
        return;
      }
      mode = value;
      C.write("performanceMode", mode);
      saveNativeTier();
      apply();
    },
    // Background cadence per tier (ms). Active radio indication always stays at 1s.
    radioIdleMs: function() {
      return mode === "quality" ? 1e3 : mode === "balanced" ? 5e3 : 1e4;
    }
  };
  var button;
  window.addEventListener("load", function() {
    button = document.createElement("button");
    button.id = "setting-performance";
    button.className = "setting";
    button.setAttribute("data-no-translate", "");
    button.onclick = function() {
      var order = ["performance", "balanced", "quality"];
      C.Performance.set(order[(order.indexOf(C.Performance.tier()) + 1) % order.length]);
    };
    var panel = document.querySelector("#view-settings .settings-panel:last-child");
    if (panel) panel.insertBefore(button, panel.firstChild);
    apply();
  });
  window.addEventListener("morphLanguage", function() {
    if (button) {
      var w = words();
      button.textContent = w[0] + " \xB7 " + w[labelIndex()];
      button.title = w[labelIndex() + 3];
    }
  });
  document.body.classList.toggle("light-mode", isLight());
  function icons(root) {
    if (root.matches && root.matches(".shelf-card img,.app-card img")) {
      root.loading = "lazy";
      root.decoding = "async";
    }
    root.querySelectorAll(".shelf-card img,.app-card img").forEach(function(img) {
      img.loading = "lazy";
      img.decoding = "async";
    });
  }
  new MutationObserver(function(records) {
    records.forEach(function(r) {
      Array.prototype.forEach.call(r.addedNodes, function(n) {
        if (n.nodeType === 1) icons(n);
      });
    });
  }).observe(document.body, { childList: true, subtree: true });
})(window.ClearTV);
