(function() {
  "use strict";
  var $ = function(id) {
    return document.getElementById(id);
  }, dialog = document.querySelector("#settings-panel .settings-dialog");
  if (!dialog) return;
  var current = "accounts", panels = {}, buttons = {}, title = document.createElement("h3"), hint = document.createElement("p"), summary = document.createElement("p");
  dialog.classList.add("iptv-settings-pages");
  var shell = document.createElement("div"), nav = document.createElement("nav"), content = document.createElement("div"), foot = document.createElement("div");
  shell.className = "iptv-settings-shell";
  nav.className = "iptv-settings-nav";
  content.className = "iptv-settings-content";
  foot.className = "iptv-settings-footer";
  title.className = "iptv-settings-page-title";
  hint.className = "iptv-settings-page-hint";
  summary.id = "iptv-active-source";
  summary.setAttribute("role", "status");
  summary.setAttribute("data-no-translate", "");
  dialog.querySelector(".settings-heading").appendChild(summary);
  var labels = { ar: [["\u0627\u0644\u062D\u0633\u0627\u0628\u0627\u062A \u0648\u0627\u0644\u0645\u0635\u062F\u0631", "\u0627\u0634\u062A\u0631\u0627\u0643\u0627\u062A\u064A \u0623\u0648 \u0627\u0644\u0642\u0646\u0648\u0627\u062A \u0627\u0644\u0645\u062C\u0627\u0646\u064A\u0629. \u0627\u062E\u062A\u0627\u0631 \u0627\u0644\u0645\u0635\u062F\u0631 \u062B\u0645 \u0627\u0636\u063A\u0637 \u062A\u0634\u063A\u064A\u0644."], ["\u0625\u0636\u0627\u0641\u0629 \u062D\u0633\u0627\u0628", "\u0627\u062E\u062A\u0627\u0631 \u0646\u0648\u0639 \u0627\u0644\u062D\u0633\u0627\u0628 \u0648\u0623\u062F\u062E\u0644 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0632\u0648\u0651\u062F\u060C \u062B\u0645 \u0627\u0636\u063A\u0637 \u062D\u0641\u0638 \u0648\u0631\u0628\u0637."], ["\u0627\u0644\u0645\u0634\u0627\u0647\u062F\u0629 \u0648\u0627\u0644\u0635\u0648\u062A", "\u0644\u063A\u0629 \u0627\u0644\u062A\u0637\u0628\u064A\u0642\u060C \u0645\u0642\u0627\u0633 \u0627\u0644\u0641\u064A\u062F\u064A\u0648 \u0648\u062D\u0641\u0638 \u0645\u0648\u0636\u0639 \u0627\u0644\u0645\u0634\u0627\u0647\u062F\u0629."], ["\u0627\u0644\u0645\u0643\u062A\u0628\u0629 \u0648\u0627\u0644\u062A\u0631\u062A\u064A\u0628", "\u062D\u062C\u0645 \u0627\u0644\u0643\u0631\u0648\u062A\u060C \u062A\u0631\u062A\u064A\u0628 \u0627\u0644\u0639\u0646\u0627\u0648\u064A\u0646 \u0648\u062A\u062D\u062F\u064A\u062B \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0645\u0643\u062A\u0628\u0629."]], en: [["Accounts & source", "Choose a saved subscription or free channels, then press Open."], ["Add an account", "Choose the source type, enter provider details, then Connect & save."], ["Playback", "App language, video size and remembered playback position."], ["Library & sorting", "Card size, title order and library updates."]] };
  var keys = ["accounts", "add", "playback", "library"];
  keys.forEach(function(key) {
    var tab = document.createElement("button");
    tab.type = "button";
    tab.id = "iptv-settings-tab-" + key;
    tab.setAttribute("data-no-translate", "");
    tab.onclick = function() {
      open(key);
    };
    nav.appendChild(tab);
    buttons[key] = tab;
    var area = document.createElement("section");
    area.className = "iptv-settings-page";
    area.id = "iptv-settings-page-" + key;
    area.hidden = true;
    content.appendChild(area);
    panels[key] = area;
  });
  shell.appendChild(nav);
  shell.appendChild(content);
  dialog.appendChild(shell);
  function move(id, target) {
    var node = $(id);
    if (node) target.appendChild(node);
  }
  var cards = document.createElement("div"), mine = document.createElement("article"), free = document.createElement("article"), mineTitle = document.createElement("h4"), freeTitle = document.createElement("h4");
  cards.className = "iptv-source-cards";
  mine.className = free.className = "iptv-source-card";
  mine.appendChild(mineTitle);
  free.appendChild(freeTitle);
  cards.appendChild(mine);
  cards.appendChild(free);
  panels.accounts.appendChild(cards);
  move("iptv-saved-accounts", mine);
  ["account-public-source", "account-public", "account-source-note"].forEach(function(id) {
    var node = $(id);
    if (id === "account-public-source" && node && node.previousElementSibling && node.previousElementSibling.tagName === "LABEL") free.appendChild(node.previousElementSibling);
    move(id, free);
  });
  ["home-account", "home-refresh"].forEach(function(id) {
    var node = $(id);
    if (node) {
      panels[id === "home-account" ? "accounts" : "library"].appendChild(node);
      node.hidden = true;
    }
  });
  var add = $("account-open");
  panels.accounts.appendChild(add);
  add.onclick = function() {
    open("add");
  };
  move("account-panel", panels.add);
  $("account-panel").hidden = false;
  var groups = dialog.querySelectorAll(".settings-grid .setting-group");
  if (groups[0]) panels.playback.appendChild(groups[0]);
  if (groups[1]) panels.library.appendChild(groups[1]);
  move("clear-progress", panels.library);
  var oldGrid = dialog.querySelector(".settings-grid");
  if (oldGrid) oldGrid.remove();
  content.insertBefore(hint, content.firstChild);
  content.insertBefore(title, content.firstChild);
  shell.appendChild(nav);
  shell.appendChild(content);
  dialog.appendChild(shell);
  ["settings-save", "settings-close", "settings-status"].forEach(function(id) {
    move(id, foot);
  });
  dialog.appendChild(foot);
  var sourceSelect = $("account-type"), sourceChoices = document.createElement("div"), sourceButtons = {};
  sourceChoices.className = "iptv-source-methods";
  sourceChoices.setAttribute("role", "group");
  sourceSelect.before(sourceChoices);
  sourceSelect.hidden = true;
  sourceSelect.tabIndex = -1;
  var sourceLabel = document.querySelector('label[for="account-type"]');
  if (sourceLabel) sourceLabel.hidden = true;
  ["xtream", "m3u", "portal"].forEach(function(type) {
    var button = document.createElement("button");
    button.type = "button";
    button.id = "account-method-" + type;
    button.setAttribute("data-no-translate", "");
    button.onclick = function() {
      sourceSelect.value = type;
      sourceSelect.dispatchEvent(new Event("change", { bubbles: true }));
      syncMethods();
    };
    sourceButtons[type] = button;
    sourceChoices.appendChild(button);
  });
  function syncMethods() {
    var names = { xtream: tr("\u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0627\u0634\u062A\u0631\u0627\u0643", "Subscription details"), m3u: tr("\u0631\u0627\u0628\u0637 M3U \u0643\u0627\u0645\u0644", "Full M3U link"), portal: "Portal + MAC" };
    Object.keys(sourceButtons).forEach(function(type) {
      sourceButtons[type].textContent = names[type];
      sourceButtons[type].setAttribute("aria-pressed", String(sourceSelect.value === type));
    });
    Array.prototype.forEach.call(document.querySelectorAll(".account-keyboard-open"), function(button) {
      var field = $(button.getAttribute("data-field"));
      if (field) button.hidden = field.hidden;
    });
  }
  sourceSelect.addEventListener("change", syncMethods);
  function tr(ar, en) {
    return window.MorphLocale ? MorphLocale.t(ar, en) : en;
  }
  function refresh() {
    syncMethods();
    var text = labels[MorphLocale.get()] || labels.en;
    keys.forEach(function(key, index2) {
      buttons[key].textContent = text[index2][0];
      buttons[key].setAttribute("aria-current", current === key ? "page" : "false");
      panels[key].hidden = current !== key;
    });
    var index = keys.indexOf(current);
    title.textContent = text[index][0];
    hint.textContent = text[index][1];
    mineTitle.textContent = tr("\u0627\u0634\u062A\u0631\u0627\u0643\u0627\u062A\u064A \u0627\u0644\u0645\u062D\u0641\u0648\u0638\u0629", "My saved subscriptions");
    freeTitle.textContent = tr("\u0642\u0646\u0648\u0627\u062A \u0645\u062C\u0627\u0646\u064A\u0629", "Free channels");
    var state = window.IptvTvBridge && IptvTvBridge.settingsState(), info = state && state.info || {};
    summary.textContent = info.configured ? tr("\u0627\u0644\u0645\u0635\u062F\u0631 \u0627\u0644\u062D\u0627\u0644\u064A: ", "Current source: ") + (info.publicMode ? tr("\u0645\u062C\u0627\u0646\u064A \u2014 ", "Free \u2014 ") : "") + (info.name || tr("\u0627\u0634\u062A\u0631\u0627\u0643\u064A", "My subscription")) : tr("\u0644\u0645 \u062A\u062E\u062A\u064E\u0631 \u0645\u0635\u062F\u0631\u064B\u0627 \u0628\u0639\u062F. \u0623\u0636\u0641 \u0627\u0634\u062A\u0631\u0627\u0643\u0643 \u0623\u0648 \u0627\u0641\u062A\u062D \u0627\u0644\u0642\u0646\u0648\u0627\u062A \u0627\u0644\u0645\u062C\u0627\u0646\u064A\u0629.", "No source selected yet. Add a subscription or open free channels.");
    mine.classList.toggle("source-current", !!info.configured && !info.publicMode);
    free.classList.toggle("source-current", !!info.publicMode);
    $("settings-save").hidden = current === "accounts" || current === "add";
  }
  function open(key) {
    if (keys.indexOf(key) < 0) return;
    current = key;
    refresh();
    content.scrollTop = 0;
    buttons[key].focus();
  }
  function focusControl(node) {
    if (node) {
      node.focus();
      node.scrollIntoView({ block: "nearest", inline: "nearest" });
    }
    return true;
  }
  function navigate(code) {
    if ($("settings-panel").hidden) return false;
    var active = document.activeElement;
    if (nav.contains(active)) return false;
    if (!content.contains(active)) return false;
    var controls = Array.prototype.filter.call(panels[current].querySelectorAll("button,input,select"), function(node) {
      return !node.disabled && !node.closest("[hidden]") && node.offsetWidth;
    });
    var index = controls.indexOf(active);
    if (index < 0) return focusControl(controls[0] || buttons[current]);
    if (sourceChoices.contains(active)) {
      var methods = Object.keys(sourceButtons).map(function(key) {
        return sourceButtons[key];
      }), at = methods.indexOf(active);
      if (code === 40) return focusControl(controls.filter(function(node) {
        return !sourceChoices.contains(node);
      })[0]);
      if (code === 38) return focusControl(buttons[current]);
      if (code === 37 || code === 39) {
        var delta = (code === 39 ? 1 : -1) * (document.documentElement.dir === "rtl" ? -1 : 1);
        return focusControl(methods[Math.max(0, Math.min(methods.length - 1, at + delta))]);
      }
    }
    if (code === 38 || code === 40) return focusControl(controls[Math.max(0, Math.min(controls.length - 1, index + (code === 40 ? 1 : -1)))]);
    var towardNav = document.documentElement.dir === "rtl" ? 39 : 37;
    if (code === towardNav && active.tagName !== "INPUT") return focusControl(buttons[current]);
    return true;
  }
  window.IptvSettingsPages = { open, move: navigate, refresh, reset: function() {
    current = "accounts";
  }, back: function() {
    if ($("settings-panel").hidden || current === "accounts") return false;
    open("accounts");
    return true;
  } };
  document.addEventListener("keydown", function(event) {
    if ($("settings-panel").hidden) return;
    if (content.contains(document.activeElement) && event.keyCode >= 37 && event.keyCode <= 40) {
      if (document.activeElement.tagName === "INPUT" && (event.keyCode === 37 || event.keyCode === 39)) return;
      if (navigate(event.keyCode)) {
        event.preventDefault();
        event.stopImmediatePropagation();
      }
      return;
    }
    if (!nav.contains(document.activeElement)) return;
    var index = keys.indexOf(current);
    if (event.keyCode === 38 && index > 0 || event.keyCode === 40 && index < keys.length - 1) {
      event.preventDefault();
      event.stopImmediatePropagation();
      open(keys[index + (event.keyCode === 40 ? 1 : -1)]);
    } else if (event.keyCode === 39 && document.documentElement.dir !== "rtl" || event.keyCode === 37 && document.documentElement.dir === "rtl") {
      var first = Array.prototype.filter.call(panels[current].querySelectorAll("button,input,select"), function(node) {
        return !node.disabled && !node.closest("[hidden]") && node.offsetWidth;
      })[0];
      if (first) {
        event.preventDefault();
        event.stopImmediatePropagation();
        first.focus();
      }
    }
  }, true);
  window.addEventListener("morphLanguage", refresh);
  refresh();
})();
