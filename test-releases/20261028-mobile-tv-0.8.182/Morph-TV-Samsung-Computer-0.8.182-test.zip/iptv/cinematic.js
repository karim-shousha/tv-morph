(function() {
  "use strict";
  if (!/width=1920/.test(document.querySelector("meta[name=viewport]").content)) return;
  var $ = function(id) {
    return document.getElementById(id);
  }, api = window.IptvTvBridge, t = api.translate;
  document.documentElement.setAttribute("data-media-cinema", "");
  var tools = document.querySelector(".portal-tools"), dialog = document.querySelector(".settings-dialog");
  $("home-settings").hidden = true;
  dialog.insertBefore($("home-account"), $("account-open"));
  dialog.insertBefore($("home-refresh"), $("account-open"));
  tools.hidden = true;
  $("home-account").onclick = function() {
    api.showAccount();
  };
  $("home-refresh").onclick = function() {
    $("cache-clear").click();
  };
  var pulseTimers = /* @__PURE__ */ new WeakMap();
  document.addEventListener("click", function(event) {
    var button = event.target.closest(".portal-grid button");
    if (!button) return;
    clearTimeout(pulseTimers.get(button));
    button.classList.remove("portal-pressed");
    void button.offsetWidth;
    button.classList.add("portal-pressed");
    pulseTimers.set(button, setTimeout(function() {
      button.classList.remove("portal-pressed");
    }, 240));
  }, true);
  var hero = document.createElement("section");
  hero.id = "cinematic-hero";
  hero.innerHTML = '<img class="cinematic-hero-art" alt=""><div class="cinematic-hero-copy"><span class="cinematic-kicker">MORPH \xB7 IPTV</span><h1></h1><p></p><button id="cinematic-browse"></button></div><div class="hero-dots" aria-hidden="true"><i></i><i></i><i></i></div>';
  $("dashboard").insertBefore(hero, $("dashboard").firstChild);
  var shelf = document.createElement("h2");
  shelf.id = "continue-heading";
  $("watch-hero").before(shelf);
  var portals = document.querySelector(".portal-grid");
  $("dashboard").insertBefore(portals, shelf);
  Array.prototype.forEach.call(portals.children, function(b) {
    var name = b.dataset.open || "music";
    var art = document.createElement("img");
    art.className = "category-art";
    art.alt = "";
    art.src = "card-" + name + "-v1.webp";
    b.insertBefore(art, b.firstChild);
  });
  var heroChoice = null, heroArt = hero.querySelector(".cinematic-hero-art");
  heroArt.setAttribute("data-category-art", "true");
  function previewCategory(button) {
    if (!button || button.hidden) return;
    var art = button.querySelector(".category-art");
    if (!art) return;
    heroChoice = button;
    heroArt.hidden = false;
    if (heroArt.getAttribute("src") !== art.getAttribute("src")) heroArt.src = art.getAttribute("src");
    hero.dataset.category = button.dataset.open || "music";
  }
  portals.addEventListener("focusin", function(event) {
    previewCategory(event.target.closest("button"));
  });
  portals.addEventListener("pointerover", function(event) {
    previewCategory(event.target.closest("button"));
  });
  previewCategory(Array.prototype.filter.call(portals.children, function(b) {
    return !b.hidden;
  })[0]);
  var sourceSwitch = $("home-source-switch");
  if (sourceSwitch) hero.querySelector(".cinematic-hero-copy").appendChild(sourceSwitch);
  $("cinematic-browse").onclick = function() {
    var choice = heroChoice && !heroChoice.hidden ? heroChoice : Array.prototype.filter.call(portals.children, function(b) {
      return !b.hidden;
    })[0];
    if (choice) choice.click();
    else $("home-settings").click();
  };
  var glyphs = { live: '<rect x="3" y="6" width="26" height="21" rx="4"/><path d="m10 1 6 5 6-5M11 31h10"/>', vod: '<circle cx="16" cy="16" r="13"/><circle cx="12" cy="9" r="2"/><circle cx="23" cy="12" r="2"/><circle cx="21" cy="23" r="2"/><circle cx="9" cy="22" r="2"/><circle cx="16" cy="16" r="1"/>', series: '<rect x="3" y="4" width="26" height="24" rx="3"/><path d="M8 4v24M24 4v24M3 10h5m-5 6h5m-5 6h5M24 10h5m-5 6h5m-5 6h5"/>', favorites: '<path d="M16 28S2 19 2 10a7 7 0 0 1 14-1 7 7 0 0 1 14 1c0 9-14 18-14 18Z"/>' };
  Array.prototype.forEach.call(portals.children, function(b) {
    var icon = b.querySelector(".portal-icon");
    if (!icon) return;
    var id = b.dataset.open || "favorites", span = document.createElement("span");
    span.className = "portal-icon";
    span.setAttribute("aria-hidden", "true");
    span.innerHTML = '<svg viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round">' + glyphs[id] + "</svg>";
    icon.parentNode.replaceChild(span, icon);
  });
  function homeState() {
    document.body.classList.toggle("cinema-home", !$("dashboard").hidden);
  }
  homeState();
  new MutationObserver(homeState).observe($("dashboard"), { attributes: true, attributeFilter: ["hidden"] });
  var clock = document.createElement("div");
  clock.className = "media-clock";
  clock.setAttribute("aria-hidden", "true");
  document.querySelector("header").appendChild(clock);
  function time() {
    var now = /* @__PURE__ */ new Date();
    clock.textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) + " \xB7 " + now.toLocaleDateString([], { month: "short", day: "numeric" });
  }
  time();
  setInterval(time, 6e4);
  function labels() {
    hero.querySelector("h1").textContent = t("\u0643\u0644 \u0627\u0644\u0644\u064A \u0628\u062A\u062D\u0628 \u062A\u0634\u0648\u0641\u0647.", "Your TV. Your world.");
    hero.querySelector("p").textContent = t("\u0642\u0646\u0648\u0627\u062A \u0645\u0628\u0627\u0634\u0631\u0629\u060C \u0623\u0641\u0644\u0627\u0645 \u0648\u0645\u0633\u0644\u0633\u0644\u0627\u062A. \u0643\u0644 \u0645\u062D\u062A\u0648\u0627\u0643 \u0641\u064A \u0645\u0643\u0627\u0646 \u0648\u0627\u062D\u062F.", "Live moments. Movie nights. All your entertainment, together.");
    $("cinematic-browse").textContent = t("\u25B6 \u0634\u0627\u0647\u062F \u0627\u0644\u0622\u0646", "\u25B6 Watch now");
    shelf.textContent = t("\u0627\u0633\u062A\u0643\u0645\u0627\u0644 \u0627\u0644\u0645\u0634\u0627\u0647\u062F\u0629", "Continue watching");
  }
  labels();
  window.addEventListener("morphLanguage", labels);
  var view = document.createElement("button");
  view.id = "catalog-view-toggle";
  var sort = document.createElement("button");
  sort.id = "catalog-sort";
  sort.type = "button";
  sort.setAttribute("aria-haspopup", "dialog");
  sort.setAttribute("aria-expanded", "false");
  var sortPanel = document.createElement("div");
  sortPanel.id = "catalog-sort-panel";
  sortPanel.hidden = true;
  sortPanel.innerHTML = '<section role="dialog" aria-modal="true" aria-labelledby="catalog-sort-title"><h2 id="catalog-sort-title"></h2><div id="catalog-sort-options"></div></section>';
  document.body.appendChild(sortPanel);
  function paintSortButton() {
    var value = api.getState().sort, row = api.sortOptions().filter(function(v) {
      return v[0] === value;
    })[0];
    sort.textContent = (row ? row[1] : "A\u2013Z") + " \u25BE";
    sort.setAttribute("aria-label", t("\u062A\u0631\u062A\u064A\u0628 \u0627\u0644\u0639\u0646\u0627\u0648\u064A\u0646: ", "Title order: ") + (row ? row[1] : "A\u2013Z"));
  }
  function closeSort() {
    sortPanel.hidden = true;
    sort.setAttribute("aria-expanded", "false");
    sort.focus();
  }
  sort.onclick = function() {
    var root = $("catalog-sort-options");
    root.textContent = "";
    $("catalog-sort-title").textContent = t("\u062A\u0631\u062A\u064A\u0628 \u0627\u0644\u0639\u0646\u0627\u0648\u064A\u0646", "Title order");
    api.sortOptions().forEach(function(row) {
      var b = document.createElement("button");
      b.type = "button";
      b.dataset.order = row[0];
      b.textContent = row[1];
      b.setAttribute("aria-pressed", String(row[0] === api.getState().sort));
      b.onclick = function() {
        api.setSort(row[0]);
        paintSortButton();
        closeSort();
      };
      root.appendChild(b);
    });
    sortPanel.hidden = false;
    sort.setAttribute("aria-expanded", "true");
    (root.querySelector('[aria-pressed="true"]') || root.firstChild).focus();
  };
  document.addEventListener("keydown", function(e) {
    if (sortPanel.hidden) return;
    var code = e.keyCode;
    if ([13, 27, 10009, 461, 37, 38, 39, 40].indexOf(code) < 0) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    if (code === 27 || code === 10009 || code === 461) {
      closeSort();
      return;
    }
    var rows = Array.prototype.slice.call($("catalog-sort-options").children), index = rows.indexOf(document.activeElement);
    if (code === 13) {
      if (!e.repeat && rows[index]) rows[index].click();
      return;
    }
    if (code === 38 || code === 40) rows[Math.max(0, Math.min(rows.length - 1, index + (code === 40 ? 1 : -1)))].focus();
  }, true);
  sortPanel.onclick = function(e) {
    if (e.target === sortPanel) closeSort();
  };
  paintSortButton();
  window.addEventListener("morphLanguage", paintSortButton);
  window.addEventListener("iptvSortChanged", paintSortButton);
  document.querySelector(".heading").appendChild(sort);
  document.querySelector(".heading").appendChild(view);
  var grid = true;
  try {
    grid = localStorage.getItem("tvmorph.iptv.liveGrid") !== "false";
  } catch (e) {
  }
  function applyGrid() {
    document.body.classList.toggle("channel-grid", grid);
    view.textContent = grid ? t("\u2637 \u0642\u0627\u0626\u0645\u0629", "\u2637 List") : t("\u25A6 \u0634\u0628\u0643\u0629", "\u25A6 Grid");
    view.setAttribute("aria-label", view.textContent);
    view.setAttribute("aria-pressed", String(grid));
    window.dispatchEvent(new Event("resize"));
  }
  view.onclick = function() {
    grid = !grid;
    try {
      localStorage.setItem("tvmorph.iptv.liveGrid", String(grid));
    } catch (e) {
    }
    applyGrid();
  };
  applyGrid();
  var originalMove = window.TvIptvLayout.move;
  window.TvIptvLayout.move = function(code) {
    var current = document.activeElement;
    if ($("dashboard").hidden && $("settings-panel").hidden && $("details-panel").hidden && $("epg-panel").hidden) {
      var tiles = Array.prototype.slice.call(document.querySelectorAll("#items .tile"));
      if (code === 38 && tiles.indexOf(current) >= 0) {
        var top = current.getBoundingClientRect().top;
        if (!tiles.some(function(tile) {
          return tile.getBoundingClientRect().top < top - 2;
        })) {
          sort.focus();
          return true;
        }
      }
      if (current === sort || current === view) {
        if (code === 40) {
          if (tiles[0]) tiles[0].focus();
          return true;
        }
        if (code === 38) {
          $("unified-query").focus();
          return true;
        }
        if (code === 37 || code === 39) {
          var row = Array.prototype.filter.call(document.querySelectorAll(".heading button,.heading input"), function(e) {
            return e.offsetWidth && !e.disabled;
          }).sort(function(a, b) {
            return a.getBoundingClientRect().left - b.getBoundingClientRect().left;
          }), i = row.indexOf(current), next = row[i + (code === 39 ? 1 : -1)];
          if (next) next.focus();
          return true;
        }
      }
    }
    if (grid && api.getState().kind === "live" && $("details-panel").hidden && $("settings-panel").hidden && $("epg-panel").hidden && $("dashboard").hidden && current.closest("#items")) {
      var tiles = Array.prototype.slice.call(document.querySelectorAll("#items .tile")), index = tiles.indexOf(current), target = null, columns = getComputedStyle($("items")).gridTemplateColumns.split(" ").filter(Boolean).length || 4;
      if (code === 38) target = tiles[index - columns] || $("unified-query");
      if (code === 40) target = tiles[index + columns] || current;
      if (code === 37) target = index % columns === 0 ? document.querySelector("#categories button.active") || $("browse-all") : tiles[index - 1];
      if (code === 39) target = index % columns === columns - 1 ? current : tiles[index + 1] || current;
      if (target) {
        target.focus();
        target.scrollIntoView({ block: "nearest", inline: "nearest" });
      }
      return true;
    }
    if (!$("dashboard").hidden && $("settings-panel").hidden && $("details-panel").hidden && $("epg-panel").hidden) {
      var groups = [Array.prototype.filter.call(document.querySelectorAll("header button,header input"), function(e) {
        return e.offsetWidth && !e.closest("[hidden]");
      }), Array.prototype.slice.call(hero.querySelectorAll("button")), Array.prototype.slice.call(portals.children), Array.prototype.slice.call(document.querySelectorAll(".watch-card button"))], row = -1, index = -1;
      groups.forEach(function(g, i2) {
        if (g.indexOf(current) >= 0) {
          row = i2;
          index = g.indexOf(current);
        }
      });
      if (row >= 0) {
        var target;
        if (code === 38 || code === 40) {
          var next = row + (code === 40 ? 1 : -1);
          if (next >= 0 && next < groups.length) target = groups[next][Math.min(index, groups[next].length - 1)];
        } else if (code === 37 || code === 39) {
          var ordered = groups[row].slice().sort(function(a, b) {
            return a.getBoundingClientRect().left - b.getBoundingClientRect().left;
          }), i = ordered.indexOf(current);
          target = ordered[Math.max(0, Math.min(ordered.length - 1, i + (code === 39 ? 1 : -1)))];
        }
        if (target) {
          target.focus();
          target.scrollIntoView({ block: "nearest", inline: "nearest" });
        }
        return true;
      }
    }
    return originalMove(code);
  };
})();
