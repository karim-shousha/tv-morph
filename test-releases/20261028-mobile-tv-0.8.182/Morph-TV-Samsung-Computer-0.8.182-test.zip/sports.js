(function(w, C) {
  "use strict";
  var root = document.getElementById("view-sports"), active = false, requests = [], timer = 0, epoch = 0, date = /* @__PURE__ */ new Date(), tab = "all", page = 0, competitions = [], matches = [], selected = null, screen = "fixtures", returnId = "", league = null, busy = false, detailSection = "events", nextMatches = [], competitionFilter = null, previewTable = [], previewLeague = null, auxBusy = false, overview = true;
  root.setAttribute("data-scroll", "vertical");
  var words = {
    title: ["\u0627\u0644\u0645\u0628\u0627\u0631\u064A\u0627\u062A", "Morph Sports", "Morph Sports", "Morph \u4F53\u80B2", "Morph \u30B9\u30DD\u30FC\u30C4"],
    subtitle: ["\u0643\u0631\u0629 \u0627\u0644\u0642\u062F\u0645\u060C \u0644\u062D\u0638\u0629 \u0628\u0644\u062D\u0638\u0629", "Your football, in focus", "Votre football en direct", "\u805A\u7126\u8DB3\u7403", "\u30B5\u30C3\u30AB\u30FC\u3092\u3001\u3072\u3068\u76EE\u3067"],
    back: ["\u0631\u062C\u0648\u0639", "Back", "Retour", "\u8FD4\u56DE", "\u623B\u308B"],
    yesterday: ["\u0623\u0645\u0633", "Yesterday", "Hier", "\u6628\u5929", "\u6628\u65E5"],
    today: ["\u0627\u0644\u064A\u0648\u0645", "Today", "Aujourd\u2019hui", "\u4ECA\u5929", "\u4ECA\u65E5"],
    tomorrow: ["\u063A\u062F\u064B\u0627", "Tomorrow", "Demain", "\u660E\u5929", "\u660E\u65E5"],
    calendar: ["\u0627\u0644\u062A\u0642\u0648\u064A\u0645", "Calendar", "Calendrier", "\u65E5\u5386", "\u30AB\u30EC\u30F3\u30C0\u30FC"],
    all: ["\u0643\u0644 \u0627\u0644\u0645\u0628\u0627\u0631\u064A\u0627\u062A", "All matches", "Tous les matchs", "\u5168\u90E8\u6BD4\u8D5B", "\u5168\u8A66\u5408"],
    live: ["\u0645\u0628\u0627\u0634\u0631", "Live", "En direct", "\u76F4\u64AD", "\u30E9\u30A4\u30D6"],
    upcoming: ["\u0627\u0644\u0642\u0627\u062F\u0645\u0629", "Upcoming", "\xC0 venir", "\u5373\u5C06\u5F00\u59CB", "\u4ECA\u5F8C\u306E\u8A66\u5408"],
    results: ["\u0627\u0644\u0646\u062A\u0627\u0626\u062C", "Results", "R\xE9sultats", "\u8D5B\u679C", "\u7D50\u679C"],
    favorites: ["\u0627\u0644\u0645\u0641\u0636\u0644\u0629", "Favourites", "Favoris", "\u6536\u85CF", "\u304A\u6C17\u306B\u5165\u308A"],
    competitions: ["\u0627\u0644\u0628\u0637\u0648\u0644\u0627\u062A", "Competitions", "Comp\xE9titions", "\u8D5B\u4E8B", "\u5927\u4F1A"],
    teams: ["\u0627\u0644\u0641\u0631\u0642", "Teams", "\xC9quipes", "\u7403\u961F", "\u30C1\u30FC\u30E0"],
    standings: ["\u0627\u0644\u062A\u0631\u062A\u064A\u0628", "Standings", "Classement", "\u79EF\u5206\u699C", "\u9806\u4F4D\u8868"],
    empty: ["\u0644\u0627 \u062A\u0648\u062C\u062F \u0628\u064A\u0627\u0646\u0627\u062A \u0645\u062A\u0627\u062D\u0629 \u0644\u0647\u0630\u0627 \u0627\u0644\u0627\u062E\u062A\u064A\u0627\u0631", "No data available for this selection", "Aucune donn\xE9e pour cette s\xE9lection", "\u6B64\u9009\u9879\u6682\u65E0\u6570\u636E", "\u3053\u306E\u9078\u629E\u306E\u30C7\u30FC\u30BF\u306F\u3042\u308A\u307E\u305B\u3093"],
    configuration_required: ["\u064A\u0644\u0632\u0645 \u0625\u0639\u062F\u0627\u062F \u062E\u062F\u0645\u0629 \u0627\u0644\u0645\u0628\u0627\u0631\u064A\u0627\u062A \u0639\u0644\u0649 \u0627\u0644\u0633\u064A\u0631\u0641\u0631 \u0628\u0645\u0641\u062A\u0627\u062D API \u0635\u0627\u0644\u062D.", "Sports needs a valid API key configured on the server.", "Configurez une cl\xE9 API valide sur le serveur.", "\u8BF7\u5728\u670D\u52A1\u5668\u914D\u7F6E\u6709\u6548\u7684 API \u5BC6\u94A5\u3002", "\u30B5\u30FC\u30D0\u30FC\u306B\u6709\u52B9\u306A API \u30AD\u30FC\u3092\u8A2D\u5B9A\u3057\u3066\u304F\u3060\u3055\u3044\u3002"],
    provider_unavailable: ["\u062E\u062F\u0645\u0629 \u0627\u0644\u0645\u0628\u0627\u0631\u064A\u0627\u062A \u063A\u064A\u0631 \u0645\u062A\u0627\u062D\u0629 \u0645\u0624\u0642\u062A\u064B\u0627", "Sports service temporarily unavailable", "Service temporairement indisponible", "\u670D\u52A1\u6682\u65F6\u4E0D\u53EF\u7528", "\u30B5\u30FC\u30D3\u30B9\u306F\u4E00\u6642\u7684\u306B\u5229\u7528\u3067\u304D\u307E\u305B\u3093"],
    rate_limited: ["\u062A\u0645 \u0628\u0644\u0648\u063A \u062D\u062F \u0627\u0644\u0637\u0644\u0628\u0627\u062A\u061B \u0633\u0646\u0639\u064A\u062F \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0644\u0627\u062D\u0642\u064B\u0627", "Request limit reached; retrying later", "Limite atteinte ; nouvel essai plus tard", "\u8BF7\u6C42\u5DF2\u8FBE\u4E0A\u9650\uFF0C\u7A0D\u540E\u91CD\u8BD5", "\u30EA\u30AF\u30A8\u30B9\u30C8\u4E0A\u9650\u3067\u3059\u3002\u5F8C\u3067\u518D\u8A66\u884C\u3057\u307E\u3059"],
    offline: ["\u0644\u0627 \u064A\u0648\u062C\u062F \u0627\u062A\u0635\u0627\u0644 \u0628\u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A", "You are offline", "Vous \xEAtes hors ligne", "\u7F51\u7EDC\u5DF2\u65AD\u5F00", "\u30AA\u30D5\u30E9\u30A4\u30F3\u3067\u3059"],
    cached: ["\u0628\u064A\u0627\u0646\u0627\u062A \u0645\u062D\u0641\u0648\u0638\u0629 \u2014 \u0642\u062F \u062A\u0643\u0648\u0646 \u0642\u062F\u064A\u0645\u0629", "Cached data \u2014 may be out of date", "Donn\xE9es en cache \u2014 potentiellement anciennes", "\u7F13\u5B58\u6570\u636E\uFF0C\u53EF\u80FD\u5DF2\u8FC7\u671F", "\u30AD\u30E3\u30C3\u30B7\u30E5\u30C7\u30FC\u30BF\uFF1A\u53E4\u3044\u53EF\u80FD\u6027\u304C\u3042\u308A\u307E\u3059"],
    loading: ["\u062C\u0627\u0631\u064D \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0645\u0628\u0627\u0631\u064A\u0627\u062A\u2026", "Loading football\u2026", "Chargement\u2026", "\u6B63\u5728\u52A0\u8F7D\u2026", "\u8AAD\u307F\u8FBC\u307F\u4E2D\u2026"],
    retry: ["\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629", "Retry", "R\xE9essayer", "\u91CD\u8BD5", "\u518D\u8A66\u884C"],
    local: ["\u0627\u0644\u0623\u0648\u0642\u0627\u062A \u062D\u0633\u0628 \u062A\u0648\u0642\u064A\u062A \u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646", "Times in your TV\u2019s local timezone", "Heures locales du t\xE9l\xE9viseur", "\u65F6\u95F4\u4EE5\u7535\u89C6\u672C\u5730\u65F6\u533A\u663E\u793A", "\u30C6\u30EC\u30D3\u306E\u73FE\u5730\u6642\u9593\u3067\u8868\u793A"],
    next: ["\u0627\u0644\u062A\u0627\u0644\u064A", "Next", "Suivant", "\u4E0B\u4E00\u9875", "\u6B21\u3078"],
    previous: ["\u0627\u0644\u0633\u0627\u0628\u0642", "Previous", "Pr\xE9c\xE9dent", "\u4E0A\u4E00\u9875", "\u524D\u3078"],
    events: ["\u0623\u062D\u062F\u0627\u062B \u0627\u0644\u0645\u0628\u0627\u0631\u0627\u0629", "Match events", "\xC9v\xE9nements", "\u6BD4\u8D5B\u4E8B\u4EF6", "\u8A66\u5408\u30A4\u30D9\u30F3\u30C8"],
    lineups: ["\u0627\u0644\u062A\u0634\u0643\u064A\u0644", "Lineups", "Compositions", "\u9635\u5BB9", "\u30E9\u30A4\u30F3\u30A2\u30C3\u30D7"],
    statistics: ["\u0627\u0644\u0625\u062D\u0635\u0627\u0626\u064A\u0627\u062A", "Statistics", "Statistiques", "\u7EDF\u8BA1", "\u30B9\u30BF\u30C3\u30C4"],
    venue: ["\u0627\u0644\u0645\u0644\u0639\u0628", "Stadium", "Stade", "\u7403\u573A", "\u4F1A\u5834"],
    saved: ["\u062D\u064F\u0641\u0638\u062A \u0627\u0644\u0645\u0641\u0636\u0644\u0629", "Favourites saved", "Favoris enregistr\xE9s", "\u6536\u85CF\u5DF2\u4FDD\u5B58", "\u304A\u6C17\u306B\u5165\u308A\u3092\u4FDD\u5B58\u3057\u307E\u3057\u305F"],
    storage: ["\u062A\u0639\u0630\u0651\u0631 \u062D\u0641\u0638 \u0627\u0644\u0645\u0641\u0636\u0644\u0629", "Unable to save favourites", "Enregistrement impossible", "\u65E0\u6CD5\u4FDD\u5B58\u6536\u85CF", "\u4FDD\u5B58\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F"],
    favouriteHelp: ["\u0627\u062E\u062A\u0631 \u0641\u0631\u0642\u0643 \u0648\u0628\u0637\u0648\u0644\u0627\u062A\u0643 \u0645\u0646 \u062A\u0641\u0627\u0635\u064A\u0644 \u0627\u0644\u0645\u0628\u0627\u0631\u0627\u0629 \u0623\u0648 \u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u0628\u0637\u0648\u0644\u0627\u062A", "Choose teams and competitions from match details or Competitions", "Choisissez vos \xE9quipes et comp\xE9titions dans les d\xE9tails ou Comp\xE9titions", "\u5728\u6BD4\u8D5B\u8BE6\u60C5\u6216\u8D5B\u4E8B\u4E2D\u9009\u62E9\u6536\u85CF", "\u8A66\u5408\u8A73\u7D30\u307E\u305F\u306F\u5927\u4F1A\u304B\u3089\u304A\u6C17\u306B\u5165\u308A\u3092\u9078\u629E"],
    played: ["\u0644\u0639\u0628", "P", "J", "\u8D5B", "\u8A66"],
    won: ["\u0641\u0627\u0632", "W", "V", "\u80DC", "\u52DD"],
    drawn: ["\u062A\u0639\u0627\u062F\u0644", "D", "N", "\u5E73", "\u5206"],
    lost: ["\u062E\u0633\u0631", "L", "D", "\u8D1F", "\u6557"],
    difference: ["\u0627\u0644\u0641\u0627\u0631\u0642", "GD", "Diff", "\u51C0\u80DC", "\u5DEE"],
    points: ["\u0646\u0642\u0627\u0637", "Pts", "Pts", "\u5206", "\u70B9"],
    club: ["\u0627\u0644\u0646\u0627\u062F\u064A", "Club", "Club", "\u7403\u961F", "\u30AF\u30E9\u30D6"],
    NS: ["\u0644\u0645 \u062A\u0628\u062F\u0623", "Scheduled", "Pr\xE9vu", "\u672A\u5F00\u59CB", "\u958B\u59CB\u524D"],
    TBD: ["\u0644\u0645 \u064A\u062D\u062F\u062F \u0627\u0644\u0645\u0648\u0639\u062F", "Time TBD", "Horaire \xE0 d\xE9finir", "\u65F6\u95F4\u5F85\u5B9A", "\u6642\u523B\u672A\u5B9A"],
    HT: ["\u0627\u0633\u062A\u0631\u0627\u062D\u0629", "Half-time", "Mi-temps", "\u4E2D\u573A", "\u30CF\u30FC\u30D5\u30BF\u30A4\u30E0"],
    FT: ["\u0627\u0646\u062A\u0647\u062A", "Full-time", "Termin\xE9", "\u5B8C\u573A", "\u7D42\u4E86"],
    AET: ["\u0628\u0639\u062F \u0648\u0642\u062A \u0625\u0636\u0627\u0641\u064A", "After extra time", "Apr\xE8s prolongation", "\u52A0\u65F6\u7ED3\u675F", "\u5EF6\u9577\u7D42\u4E86"],
    PEN: ["\u0628\u0639\u062F \u0627\u0644\u062A\u0631\u062C\u064A\u062D", "After penalties", "Apr\xE8s tirs au but", "\u70B9\u7403\u7ED3\u675F", "PK\u7D42\u4E86"],
    PST: ["\u0645\u0624\u062C\u0644\u0629", "Postponed", "Report\xE9", "\u63A8\u8FDF", "\u5EF6\u671F"],
    CANC: ["\u0645\u0644\u063A\u0627\u0629", "Cancelled", "Annul\xE9", "\u53D6\u6D88", "\u4E2D\u6B62"],
    SUSP: ["\u0645\u0639\u0644\u0642\u0629", "Suspended", "Suspendu", "\u6682\u505C", "\u4E2D\u65AD"],
    INT: ["\u0645\u062A\u0648\u0642\u0641\u0629", "Interrupted", "Interrompu", "\u4E2D\u65AD", "\u4E2D\u65AD"],
    ABD: ["\u0623\u064F\u0648\u0642\u0641\u062A", "Abandoned", "Abandonn\xE9", "\u8170\u65A9", "\u6253\u3061\u5207\u308A"],
    AWD: ["\u0646\u062A\u064A\u062C\u0629 \u0625\u062F\u0627\u0631\u064A\u0629", "Awarded", "Attribu\xE9", "\u5224\u5B9A", "\u88C1\u5B9A"],
    WO: ["\u0627\u0646\u0633\u062D\u0627\u0628", "Walkover", "Forfait", "\u5F03\u6743", "\u4E0D\u6226\u52DD"],
    ET: ["\u0648\u0642\u062A \u0625\u0636\u0627\u0641\u064A", "Extra time", "Prolongation", "\u52A0\u65F6", "\u5EF6\u9577"],
    BT: ["\u0627\u0633\u062A\u0631\u0627\u062D\u0629 \u0625\u0636\u0627\u0641\u064A\u0629", "Extra-time break", "Pause prolongation", "\u52A0\u65F6\u4E2D\u573A", "\u5EF6\u9577\u4F11\u61A9"],
    P: ["\u0631\u0643\u0644\u0627\u062A \u0627\u0644\u062A\u0631\u062C\u064A\u062D", "Penalties", "Tirs au but", "\u70B9\u7403", "PK"]
  };
  var extra = { hero: ["\u0643\u0644 \u0627\u0644\u0645\u0628\u0627\u0631\u064A\u0627\u062A\n\u0641\u064A \u0645\u0643\u0627\u0646 \u0648\u0627\u062D\u062F", "All your football.\nOne place.", "Tout votre football.\nAu m\xEAme endroit.", "\u6240\u6709\u8DB3\u7403\u8D5B\u4E8B\n\u5C3D\u5728\u6B64\u5904", "\u3059\u3079\u3066\u306E\u30B5\u30C3\u30AB\u30FC\u3092\n\u3072\u3068\u3064\u306E\u5834\u6240\u306B"], heroSub: ["\u0645\u0648\u0627\u0639\u064A\u062F \xB7 \u0646\u062A\u0627\u0626\u062C \xB7 \u062A\u0631\u062A\u064A\u0628 \u0627\u0644\u062F\u0648\u0631\u064A\u0627\u062A", "Fixtures \xB7 Results \xB7 League tables", "Calendrier \xB7 R\xE9sultats \xB7 Classements", "\u8D5B\u7A0B \xB7 \u8D5B\u679C \xB7 \u79EF\u5206\u699C", "\u65E5\u7A0B \xB7 \u7D50\u679C \xB7 \u9806\u4F4D\u8868"], home: ["\u0627\u0644\u0631\u0626\u064A\u0633\u064A\u0629", "Home", "Accueil", "\u9996\u9875", "\u30DB\u30FC\u30E0"], apps: ["\u0627\u0644\u062A\u0637\u0628\u064A\u0642\u0627\u062A", "Apps", "Applications", "\u5E94\u7528", "\u30A2\u30D7\u30EA"], settings: ["\u0627\u0644\u0625\u0639\u062F\u0627\u062F\u0627\u062A", "Settings", "R\xE9glages", "\u8BBE\u7F6E", "\u8A2D\u5B9A"], liveNow: ["\u0627\u0644\u0645\u0628\u0627\u0631\u064A\u0627\u062A \u0627\u0644\u0622\u0646", "Live now", "En ce moment", "\u6B63\u5728\u8FDB\u884C", "\u30E9\u30A4\u30D6\u4E2D"], todayMatches: ["\u0645\u0628\u0627\u0631\u064A\u0627\u062A \u0627\u0644\u064A\u0648\u0645", "Today\u2019s matches", "Matchs du jour", "\u4ECA\u65E5\u6BD4\u8D5B", "\u4ECA\u65E5\u306E\u8A66\u5408"], nextMatches: ["\u0627\u0644\u0645\u0628\u0627\u0631\u064A\u0627\u062A \u0627\u0644\u0642\u0627\u062F\u0645\u0629", "Coming up", "Prochains matchs", "\u5373\u5C06\u5F00\u59CB", "\u4ECA\u5F8C\u306E\u8A66\u5408"], favoriteTeams: ["\u0641\u0631\u0642\u064A \u0627\u0644\u0645\u0641\u0636\u0644\u0629", "Favourite teams", "\xC9quipes favorites", "\u6536\u85CF\u7403\u961F", "\u304A\u6C17\u306B\u5165\u308A\u30C1\u30FC\u30E0"], favoriteLeagues: ["\u0627\u0644\u0628\u0637\u0648\u0644\u0627\u062A \u0627\u0644\u0645\u0641\u0636\u0644\u0629", "Favourite competitions", "Comp\xE9titions favorites", "\u6536\u85CF\u8D5B\u4E8B", "\u304A\u6C17\u306B\u5165\u308A\u5927\u4F1A"], manage: ["\u0625\u062F\u0627\u0631\u0629", "Manage", "G\xE9rer", "\u7BA1\u7406", "\u7BA1\u7406"], viewAll: ["\u0639\u0631\u0636 \u0627\u0644\u0643\u0644", "View all", "Tout voir", "\u67E5\u770B\u5168\u90E8", "\u3059\u3079\u3066\u8868\u793A"], addTeam: ["\u0625\u0636\u0627\u0641\u0629 \u0641\u0631\u064A\u0642", "Add team", "Ajouter une \xE9quipe", "\u6DFB\u52A0\u7403\u961F", "\u30C1\u30FC\u30E0\u3092\u8FFD\u52A0"], addLeague: ["\u0625\u0636\u0627\u0641\u0629 \u0628\u0637\u0648\u0644\u0629", "Add competition", "Ajouter une comp\xE9tition", "\u6DFB\u52A0\u8D5B\u4E8B", "\u5927\u4F1A\u3092\u8FFD\u52A0"], selectLeague: ["\u0627\u062E\u062A\u0631 \u0628\u0637\u0648\u0644\u0629 \u0644\u0639\u0631\u0636 \u0627\u0644\u062A\u0631\u062A\u064A\u0628", "Choose a competition for standings", "Choisissez une comp\xE9tition", "\u9009\u62E9\u8D5B\u4E8B\u67E5\u770B\u79EF\u5206\u699C", "\u9806\u4F4D\u3092\u8868\u793A\u3059\u308B\u5927\u4F1A\u3092\u9078\u629E"], allLeagues: ["\u0643\u0644 \u0627\u0644\u0628\u0637\u0648\u0644\u0627\u062A", "All competitions", "Toutes les comp\xE9titions", "\u5168\u90E8\u8D5B\u4E8B", "\u3059\u3079\u3066\u306E\u5927\u4F1A"] };
  Object.keys(extra).forEach(function(k) {
    words[k] = extra[k];
  });
  function glyph(name) {
    var paths = { ball: '<circle cx="12" cy="12" r="9"/><path d="m12 7 4 3-1.5 5h-5L8 10ZM12 3v4M3.5 9l4.5 1M5.5 19l4-4M18.5 19l-4-4M20.5 9 16 10"/>', calendar: '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M7 3v5M17 3v5M3 11h18M7 15h2M13 15h2M7 18h2"/>', home: '<path d="m3 11 9-8 9 8M5 10v11h5v-7h4v7h5V10"/>', star: '<path d="m12 3 2.8 5.8 6.4.9-4.6 4.5 1.1 6.4-5.7-3-5.7 3 1.1-6.4-4.6-4.5 6.4-.9Z"/>', plus: '<path d="M12 4v16M4 12h16"/>', shield: '<path d="m12 2 8 3v7c0 5-8 10-8 10S4 17 4 12V5Z"/><path d="m8 12 3 3 5-6"/>', apps: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>' };
    return paths[name] ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + paths[name] + "</svg>" : w.MorphIcons ? MorphIcons.svg(name) : "";
  }
  function iconButton(parent, name, label, fn, id) {
    var b = button(parent, "", fn, id), i = C.el("span", "sports-action-icon");
    i.innerHTML = glyph(name);
    b.appendChild(i);
    b.appendChild(C.el("span", "", label));
    return b;
  }
  function emblem(parent, row, kind) {
    var icon = C.el("span", "sports-emblem sports-emblem-" + kind);
    icon.style.setProperty("--emblem-hue", String((Number(row.id) || 1) * 53 % 360));
    if (row.logo && /^https:\/\/media\.api-sports\.io\//.test(row.logo)) {
      var img = C.el("img");
      img.src = row.logo;
      img.alt = "";
      img.loading = "lazy";
      img.onerror = function() {
        this.hidden = true;
        icon.classList.add("sports-logo-failed");
      };
      icon.appendChild(img);
    }
    var fallback = C.el("span", "sports-emblem-fallback");
    fallback.innerHTML = glyph(kind === "team" ? "shield" : "sports");
    if (kind === "team") fallback.appendChild(C.el("b", "", String(row.name || "").slice(0, 2)));
    icon.appendChild(fallback);
    parent.appendChild(icon);
    return icon;
  }
  function sidebar() {
    var side = C.el("aside", "sports-sidebar");
    side.dir = "ltr";
    var mark = C.el("img", "sports-brand");
    mark.src = "assets/tvmorph.webp";
    mark.alt = "Morph TV";
    side.appendChild(mark);
    [["home", "home", function() {
      C.showView("home");
      ensureDock(document.getElementById("favourites"));
      C.Focus.focus(document.getElementById("dock-sports"));
    }], ["ball", "title", function() {
      screen = "fixtures";
      tab = "all";
      page = 0;
      competitionFilter = null;
      load();
    }], ["iptv", "IPTV", function() {
      var app = C.Catalog.get("local.tvmorph.tv.play");
      if (app) {
        C.showView("home");
        C.Catalog.launch(app);
      }
    }], ["apps", "apps", function() {
      C.showView("apps");
    }], ["settings", "settings", function() {
      C.showView("settings");
    }]].forEach(function(item) {
      var b = iconButton(side, item[0], t(item[1]), item[2], "side-" + item[0]);
      b.setAttribute("aria-current", item[0] === "ball" ? "page" : "false");
    });
    root.appendChild(side);
  }
  function lang() {
    return w.MorphLocale ? MorphLocale.get() : "en";
  }
  function t(key) {
    var a = words[key];
    return a ? a[Math.max(0, ["ar", "en", "fr", "zh", "ja"].indexOf(lang()))] : key;
  }
  function day(d) {
    return d.getFullYear() + "-" + ("0" + (d.getMonth() + 1)).slice(-2) + "-" + ("0" + d.getDate()).slice(-2);
  }
  function localTime(value) {
    var d = new Date(value);
    return isNaN(d.getTime()) ? "\u2014" : d.toLocaleString(lang(), { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
  }
  function live(m) {
    return ["1H", "HT", "2H", "ET", "BT", "P", "LIVE", "INT", "SUSP"].indexOf(m.status) >= 0;
  }
  function status(m) {
    return (words[m.status] ? t(m.status) : live(m) ? t("live") : m.status) + (live(m) && typeof m.minute === "number" ? " \xB7 " + m.minute + "\u2032" : "");
  }
  function prefs() {
    var p = C.read("sportsFavorites", { teams: [], competitions: [] });
    return p && Array.isArray(p.teams) && Array.isArray(p.competitions) ? p : { teams: [], competitions: [] };
  }
  function toggle(kind, row) {
    var p = prefs(), i = p[kind].map(function(v) {
      return v.id;
    }).indexOf(row.id);
    if (i < 0) {
      if (p[kind].length >= 50) return;
      p[kind].push({ id: row.id, name: row.name, season: row.season, logo: row.logo });
    } else p[kind].splice(i, 1);
    C.toast(t(C.write("sportsFavorites", p) ? "saved" : "storage"));
    render();
  }
  function starred(kind, id) {
    return prefs()[kind].some(function(v) {
      return v.id === id;
    });
  }
  function button(parent, label, fn, id) {
    var b = C.el("button", "sports-button", label);
    if (id) b.id = "sports-" + id;
    b.onclick = fn;
    parent.appendChild(b);
    return b;
  }
  function note(text) {
    var e = C.el("p", "sports-notice", text);
    e.setAttribute("role", "status");
    root.appendChild(e);
    return e;
  }
  function stop() {
    clearTimeout(timer);
    timer = 0;
    epoch++;
    requests.forEach(function(x) {
      x.abort();
    });
    requests = [];
    busy = false;
    auxBusy = false;
  }
  function leave() {
    if (!active) return;
    stop();
    active = false;
    C.Focus.setScope(document);
  }
  function focus(id) {
    C.Focus.invalidate();
    var b = document.getElementById(id);
    C.Focus.focus(b && root.contains(b) ? b : root.querySelector("button"));
  }
  function api(route, done) {
    var run = epoch, x = new XMLHttpRequest(), base = C.config.sportsURL || "https://morphtv.herroshetta.com/api/sports/", cache = C.read("sportsCache", {}), key = route, finished = false;
    function finish(error2, data) {
      if (finished) return;
      finished = true;
      requests = requests.filter(function(r) {
        return r !== x;
      });
      if (run !== epoch || !active) return;
      if (error2 && cache[key] && Date.now() - cache[key].saved < 7 * 864e5) {
        data = cache[key].data;
        data.stale = true;
      }
      if (!error2 && data && !data.stale) {
        cache[key] = { saved: Date.now(), data };
        var keys = Object.keys(cache).sort(function(a, b) {
          return cache[b].saved - cache[a].saved;
        });
        keys.slice(12).forEach(function(k) {
          delete cache[k];
        });
        C.write("sportsCache", cache);
      }
      done(error2, data);
    }
    if (navigator.onLine === false) {
      finish("offline");
      return;
    }
    x.open("GET", base + route, true);
    x.timeout = 12e3;
    x.onload = function() {
      var data;
      try {
        data = JSON.parse(x.responseText);
      } catch (e) {
        finish("provider_unavailable");
        return;
      }
      finish(x.status === 200 ? null : data.error || "provider_unavailable", data);
    };
    x.onerror = x.ontimeout = function() {
      finish(navigator.onLine === false ? "offline" : "provider_unavailable");
    };
    requests.push(x);
    x.send();
  }
  function header() {
    root.textContent = "";
    root.dir = lang() === "ar" ? "rtl" : "ltr";
    root.setAttribute("data-sports-screen", screen);
    sidebar();
    var h = C.el("div", "sports-heading"), brand = C.el("div", "sports-hero-copy");
    brand.appendChild(C.el("small", "sports-eyebrow", "MORPH SPORTS"));
    brand.appendChild(C.el("h1", "", screen === "fixtures" ? t("hero") : t(screen === "match" ? "title" : screen)));
    brand.appendChild(C.el("p", "", t("heroSub")));
    h.appendChild(brand);
    var tools = C.el("div", "sports-hero-tools");
    tools.appendChild(C.el("time", "", (/* @__PURE__ */ new Date()).toLocaleTimeString(lang(), { hour: "2-digit", minute: "2-digit" })));
    iconButton(tools, "clock", t("back"), back, "back");
    h.appendChild(tools);
    root.appendChild(h);
    var nav = C.el("div", "sports-nav");
    ["all", "live", "upcoming", "results", "favorites", "competitions"].forEach(function(k) {
      var b = iconButton(nav, { all: "ball", live: "ball", upcoming: "clock", results: "check", favorites: "star", competitions: "sports" }[k], t(k), function() {
        screen = k === "competitions" ? "competitions" : "fixtures";
        tab = k;
        overview = true;
        page = 0;
        load();
      }, "tab-" + k);
      b.setAttribute("aria-pressed", String(tab === k));
    });
    root.appendChild(nav);
  }
  function dates() {
    var bar = C.el("div", "sports-dates");
    ["yesterday", "today", "tomorrow"].forEach(function(k, i) {
      var b = button(bar, t(k), function() {
        date = /* @__PURE__ */ new Date();
        date.setDate(date.getDate() + i - 1);
        screen = "fixtures";
        page = 0;
        load();
      }, k);
      var target = /* @__PURE__ */ new Date();
      target.setDate(target.getDate() + i - 1);
      b.setAttribute("aria-pressed", String(day(date) === day(target)));
    });
    button(bar, t("calendar"), function() {
      screen = "calendar";
      render();
    }, "calendar");
    bar.appendChild(C.el("strong", "", date.toLocaleDateString(lang(), { weekday: "long", month: "long", day: "numeric" })));
    root.appendChild(bar);
    root.appendChild(C.el("p", "sports-timezone", t("local")));
  }
  function pages(parent, count, draw) {
    var nav = C.el("div", "sports-pagination");
    if (page > 0) button(nav, t("previous"), function() {
      page--;
      draw();
      focus("sports-page-next");
    }, "page-previous");
    nav.appendChild(C.el("span", "", String(page + 1) + " / " + Math.max(1, Math.ceil(count / 18))));
    if ((page + 1) * 18 < count) button(nav, t("next"), function() {
      page++;
      draw();
      focus("sports-page-previous");
    }, "page-next");
    parent.appendChild(nav);
  }
  function teamNode(parent, team) {
    var box = C.el("span", "sports-team");
    emblem(box, team, "team");
    box.appendChild(C.el("strong", "", team.name));
    parent.appendChild(box);
  }
  function score(m) {
    var g = m.score || {};
    return typeof g.home === "number" && typeof g.away === "number" ? g.home + " : " + g.away : "\u2014";
  }
  function card(parent, m, suffix) {
    var b = button(parent, "", function() {
      returnId = "sports-match-" + m.id + (suffix || "");
      selected = m;
      screen = "match";
      page = 0;
      load();
    }, "match-" + m.id + (suffix || ""));
    b.className += " sports-match";
    b.appendChild(C.el("small", "sports-competition", m.competition.name));
    var teams = C.el("span", "sports-scoreline");
    teamNode(teams, m.home);
    teams.appendChild(C.el("b", "sports-score", score(m)));
    teamNode(teams, m.away);
    b.appendChild(teams);
    b.appendChild(C.el("span", live(m) ? "sports-status is-live" : "sports-status", status(m)));
    b.appendChild(C.el("small", "sports-kickoff", localTime(m.kickoff)));
  }
  function fixtureList() {
    leagueStrip();
    dates();
    if (tab === "all" && overview && page === 0) {
      dashboard();
      return;
    }
    var p = prefs(), rows = matches.filter(function(m) {
      if (competitionFilter && m.competition.id !== competitionFilter.id) return false;
      if (tab === "live") return live(m);
      if (tab === "upcoming") return ["NS", "TBD"].indexOf(m.status) >= 0;
      if (tab === "results") return ["FT", "AET", "PEN", "AWD", "WO"].indexOf(m.status) >= 0;
      if (tab === "favorites") return p.teams.some(function(v) {
        return v.id === m.home.id || v.id === m.away.id;
      }) || p.competitions.some(function(v) {
        return v.id === m.competition.id;
      });
      return true;
    });
    if (tab === "favorites") {
      note(t("favouriteHelp"));
      var saved = C.el("div", "sports-saved");
      p.teams.forEach(function(row) {
        button(saved, "\u2605 " + row.name, function() {
          toggle("teams", row);
        });
      });
      p.competitions.forEach(function(row) {
        button(saved, "\u2605 " + row.name, function() {
          toggle("competitions", row);
        });
      });
      root.appendChild(saved);
    }
    if (!rows.length && !busy) note(t("empty"));
    var grid = C.el("div", "sports-grid");
    rows.slice(page * 18, page * 18 + 18).forEach(function(m) {
      card(grid, m);
    });
    root.appendChild(grid);
    pages(root, rows.length, render);
  }
  function leagueStrip() {
    var strip = C.el("div", "sports-league-strip");
    strip.setAttribute("data-scroll", "horizontal");
    iconButton(strip, "ball", t("allLeagues"), function() {
      competitionFilter = null;
      page = 0;
      render();
    }, "league-all").setAttribute("aria-pressed", String(!competitionFilter));
    competitions.slice(0, 14).forEach(function(row) {
      var b = button(strip, "", function() {
        competitionFilter = row;
        page = 0;
        render();
        if (row.standings) {
          previewLeague = row;
          previewTable = [];
          api("standings?league=" + row.id + "&season=" + row.season, function(err, data) {
            if (data && data.data && data.data[0]) previewTable = data.data[0];
            render();
          });
        }
      }, "league-" + row.id);
      emblem(b, row, "league");
      b.appendChild(C.el("strong", "", row.name));
      b.appendChild(C.el("small", "", row.country || ""));
      b.setAttribute("aria-pressed", String(competitionFilter && competitionFilter.id === row.id));
    });
    if (!competitions.length) iconButton(strip, "sports", t("competitions"), function() {
      screen = "competitions";
      tab = "competitions";
      page = 0;
      load();
    }, "discover-leagues");
    root.appendChild(strip);
  }
  function panel(parent, title, icon, cls, action) {
    var box = C.el("section", "sports-panel " + (cls || "")), head = C.el("div", "sports-panel-head"), name = C.el("h2");
    var i = C.el("span", "sports-panel-icon");
    i.innerHTML = glyph(icon);
    name.appendChild(i);
    name.appendChild(C.el("span", "", t(title)));
    head.appendChild(name);
    if (action) button(head, t("viewAll"), action);
    box.appendChild(head);
    parent.appendChild(box);
    return box;
  }
  function blank(parent) {
    var box = C.el("div", "sports-empty");
    box.innerHTML = glyph("ball");
    box.appendChild(C.el("p", "", t(busy ? "loading" : error === "configuration_required" ? "configuration_required" : "empty")));
    parent.appendChild(box);
  }
  function matchPanel(parent, title, icon, rows, cls, filter) {
    var panelTitle = title === "todayMatches" && day(date) !== day(/* @__PURE__ */ new Date()) ? date.toLocaleDateString(lang(), { weekday: "long", month: "short", day: "numeric" }) : title;
    var box = panel(parent, panelTitle, icon, cls, function() {
      tab = filter;
      overview = false;
      page = 0;
      if (filter === "upcoming") {
        date.setDate(date.getDate() + 1);
        load();
      } else render();
    });
    if (!rows.length) {
      blank(box);
      return;
    }
    var list = C.el("div", "sports-compact-list");
    rows.slice(0, 4).forEach(function(m) {
      card(list, m);
    });
    box.appendChild(list);
  }
  function favouritesPanel(parent, kind, title, add) {
    var box = panel(parent, title, "star", "sports-favorite-panel", function() {
      screen = "competitions";
      tab = "competitions";
      page = 0;
      load();
    });
    var rail = C.el("div", "sports-favorite-rail");
    prefs()[kind].slice(0, 4).forEach(function(row) {
      var b = button(rail, "", function() {
        if (kind === "teams") {
          tab = "favorites";
          screen = "fixtures";
          page = 0;
          load();
        } else {
          competitionFilter = row;
          tab = "all";
          screen = "fixtures";
          page = 0;
          load();
        }
      }, "saved-" + kind + "-" + row.id);
      emblem(b, row, kind === "teams" ? "team" : "league");
      b.appendChild(C.el("span", "", row.name));
    });
    iconButton(rail, "plus", t(add), function() {
      screen = "competitions";
      tab = "competitions";
      page = 0;
      load();
    }, "add-" + kind);
    box.appendChild(rail);
  }
  function dashboard() {
    var visible = matches.filter(function(m) {
      return !competitionFilter || m.competition.id === competitionFilter.id;
    }), grid = C.el("div", "sports-dashboard-grid");
    matchPanel(grid, "liveNow", "ball", visible.filter(live), "sports-panel-live", "live");
    matchPanel(grid, "todayMatches", "calendar", visible.filter(function(m) {
      return !live(m);
    }), "sports-panel-today", "all");
    var upcoming = nextMatches.filter(function(m) {
      return !competitionFilter || m.competition.id === competitionFilter.id;
    });
    matchPanel(grid, "nextMatches", "clock", upcoming, "sports-panel-upcoming", "upcoming");
    root.appendChild(grid);
    var lower = C.el("div", "sports-dashboard-lower"), table = panel(lower, "standings", "sports", "sports-preview-table", function() {
      screen = "competitions";
      tab = "competitions";
      page = 0;
      load();
    });
    if (previewLeague && previewTable.length) {
      button(table, previewLeague.name, function() {
        league = previewLeague;
        screen = "standings";
        page = 0;
        load();
      }, "preview-standings");
      var list = C.el("div", "sports-mini-table");
      previewTable.slice(0, 4).forEach(function(row) {
        var item = C.el("div", "sports-mini-row");
        item.appendChild(C.el("b", "", String(row.rank)));
        emblem(item, row.team, "team");
        item.appendChild(C.el("span", "", row.team.name));
        item.appendChild(C.el("strong", "", String(row.points)));
        list.appendChild(item);
      });
      table.appendChild(list);
    } else {
      var empty = C.el("div", "sports-empty");
      empty.innerHTML = glyph("sports");
      empty.appendChild(C.el("p", "", t("selectLeague")));
      table.appendChild(empty);
    }
    favouritesPanel(lower, "teams", "favoriteTeams", "addTeam");
    favouritesPanel(lower, "competitions", "favoriteLeagues", "addLeague");
    root.appendChild(lower);
  }
  function dashboardAux() {
    if (auxBusy || competitions.length) return;
    auxBusy = true;
    api("competitions", function(err, data) {
      auxBusy = false;
      if (data && Array.isArray(data.data)) {
        competitions = data.data;
        render();
        var chosen = competitions.filter(function(c) {
          return c.standings && starred("competitions", c.id);
        })[0] || competitions.filter(function(c) {
          return c.standings;
        })[0];
        if (chosen) {
          previewLeague = chosen;
          api("standings?league=" + chosen.id + "&season=" + chosen.season, function(err2, data2) {
            if (data2 && data2.data && data2.data[0]) previewTable = data2.data[0];
            render();
          });
        }
      }
    });
  }
  function leagueList() {
    var grid = C.el("div", "sports-grid sports-leagues");
    competitions.slice(page * 18, page * 18 + 18).forEach(function(row) {
      var item = C.el("div", "sports-league");
      emblem(item, row, "league");
      item.appendChild(C.el("small", "", row.country));
      item.appendChild(C.el("h2", "", row.name));
      button(item, (starred("competitions", row.id) ? "\u2605 " : "\u2606 ") + t("favorites"), function() {
        toggle("competitions", row);
      }, "fav-league-" + row.id);
      button(item, t("teams"), function() {
        league = row;
        screen = "teams";
        page = 0;
        load();
      }, "teams-" + row.id);
      if (row.standings) button(item, t("standings"), function() {
        league = row;
        screen = "standings";
        page = 0;
        load();
      }, "standings-" + row.id);
      grid.appendChild(item);
    });
    root.appendChild(grid);
    if (!competitions.length && !busy) note(t("empty"));
    pages(root, competitions.length, render);
  }
  function details() {
    if (!selected) return;
    var m = selected, panel2 = C.el("div", "sports-detail");
    card(panel2, m);
    panel2.querySelector("button").onclick = function() {
    };
    if (m.venue) panel2.appendChild(C.el("p", "", t("venue") + " \xB7 " + m.venue));
    if (m.halftime && typeof m.halftime.home === "number") panel2.appendChild(C.el("p", "", t("HT") + " \xB7 " + m.halftime.home + " : " + m.halftime.away));
    [m.home, m.away].forEach(function(team) {
      button(panel2, (starred("teams", team.id) ? "\u2605 " : "\u2606 ") + team.name, function() {
        toggle("teams", team);
      }, "fav-team-" + team.id);
    });
    button(panel2, (starred("competitions", m.competition.id) ? "\u2605 " : "\u2606 ") + m.competition.name, function() {
      toggle("competitions", m.competition);
    }, "fav-competition");
    var rows = [];
    (m.events || []).forEach(function(e) {
      rows.push((e.time && e.time.elapsed != null ? e.time.elapsed + "\u2032 \xB7 " : "") + (e.team && e.team.name || "") + " \xB7 " + (e.player && e.player.name || "") + " \xB7 " + (e.detail || e.type || ""));
    });
    section(panel2, "events", rows);
    rows = [];
    (m.lineups || []).forEach(function(l) {
      rows.push((l.team && l.team.name || "") + " \xB7 " + (l.formation || ""));
      (l.startXI || []).forEach(function(p) {
        rows.push((p.player.number || "") + " \xB7 " + p.player.name);
      });
    });
    section(panel2, "lineups", rows);
    rows = [];
    (m.statistics || []).forEach(function(s) {
      (s.statistics || []).forEach(function(v) {
        if (v.value !== null) rows.push((s.team && s.team.name || "") + " \xB7 " + v.type + " \xB7 " + v.value);
      });
    });
    section(panel2, "statistics", rows);
    root.appendChild(panel2);
  }
  function section(parent, key, rows) {
    if (!rows.length) return;
    var b = button(parent, t(key), function() {
      detailSection = key;
      page = 0;
      render();
    }, "detail-" + key);
    b.setAttribute("aria-expanded", String(detailSection === key));
    if (detailSection !== key) return;
    rows.slice(page * 8, page * 8 + 8).forEach(function(row) {
      parent.appendChild(C.el("p", "sports-data-row", row));
    });
    if (page > 0) button(parent, t("previous"), function() {
      page--;
      render();
    }, "detail-prev");
    if ((page + 1) * 8 < rows.length) button(parent, t("next"), function() {
      page++;
      render();
    }, "detail-next");
  }
  var payload = [], error = "", stale = false, updated = 0;
  function render() {
    if (!active) return;
    var id = document.activeElement && document.activeElement.id;
    header();
    if (busy) note(t("loading"));
    if (error) {
      note(t(words[error] ? error : "provider_unavailable"));
      button(root, t("retry"), load, "retry");
    }
    if (stale) note(t("cached") + (updated ? " \xB7 " + new Date(updated * 1e3).toLocaleString(lang()) : ""));
    if (screen === "fixtures") fixtureList();
    else if (screen === "competitions") leagueList();
    else if (screen === "calendar") {
      var grid = C.el("div", "sports-calendar");
      for (var i = -30; i <= 30; i++) {
        (function(n) {
          var d = /* @__PURE__ */ new Date();
          d.setDate(d.getDate() + n);
          button(grid, d.toLocaleDateString(lang(), { month: "short", day: "numeric" }), function() {
            date = d;
            screen = "fixtures";
            page = 0;
            load();
          }, "date-" + day(d));
        })(i);
      }
      root.appendChild(grid);
    } else if (screen === "match") details();
    else if (screen === "teams") {
      root.appendChild(C.el("h2", "", league.name));
      var grid = C.el("div", "sports-grid");
      payload.slice(page * 18, page * 18 + 18).forEach(function(team) {
        button(grid, (starred("teams", team.id) ? "\u2605 " : "\u2606 ") + team.name, function() {
          toggle("teams", team);
        }, "team-" + team.id);
      });
      root.appendChild(grid);
      pages(root, payload.length, render);
      if (!payload.length && !busy) note(t("empty"));
    } else if (screen === "standings") {
      root.appendChild(C.el("h2", "", league.name));
      var all = [];
      payload.slice(0, 10).forEach(function(group) {
        group.slice(0, 60).forEach(function(row) {
          all.push(row);
        });
      });
      var nav = C.el("div", "sports-pagination");
      if (page > 0) button(nav, t("previous"), function() {
        page--;
        render();
      }, "table-prev");
      nav.appendChild(C.el("span", "", String(page + 1) + " / " + Math.max(1, Math.ceil(all.length / 6))));
      if ((page + 1) * 6 < all.length) button(nav, t("next"), function() {
        page++;
        render();
      }, "table-next");
      root.appendChild(nav);
      var table = C.el("table", "sports-table"), tr = C.el("tr");
      ["#", "club", "played", "won", "drawn", "lost", "difference", "points"].forEach(function(k) {
        tr.appendChild(C.el("th", "", t(k)));
      });
      table.appendChild(tr);
      all.slice(page * 6, page * 6 + 6).forEach(function(row) {
        var tr2 = C.el("tr");
        [row.rank, row.team.name + (row.group ? " \xB7 " + row.group : ""), row.played, row.won, row.drawn, row.lost, row.difference, row.points].forEach(function(v) {
          tr2.appendChild(C.el("td", "", String(v)));
        });
        table.appendChild(tr2);
      });
      root.appendChild(table);
      if (!all.length && !busy) note(t("empty"));
    }
    focus(id);
  }
  function arm(seconds) {
    clearTimeout(timer);
    if (active && !document.hidden && (screen === "fixtures" || screen === "match")) timer = setTimeout(load, Math.max(90, seconds || 90) * 1e3);
  }
  function load() {
    stop();
    if (!active || document.hidden) return;
    busy = true;
    error = "";
    stale = false;
    render();
    if (screen === "calendar") {
      busy = false;
      return;
    }
    var run = epoch;
    function finish(err, data) {
      if (run !== epoch) return;
      busy = false;
      error = err || "";
      if (data) {
        stale = !!data.stale;
        updated = data.updatedAt;
      }
      render();
      if (err !== "configuration_required") arm(err === "rate_limited" ? 900 : data && data.refreshAfter);
    }
    if (screen === "fixtures") {
      dashboardAux();
      var offsets = date.getTimezoneOffset() > 0 ? [-1, 0, 1, 2] : [-1, 0, 1], count = offsets.length, rows = [], firstError = "", old = false, last = 0, refresh = 3600;
      offsets.forEach(function(n) {
        var d = new Date(date);
        d.setDate(d.getDate() + n);
        api("fixtures?date=" + day(d), function(err, data) {
          if (err) firstError = err;
          if (data) {
            rows = rows.concat(data.data || []);
            old = old || data.stale;
            refresh = Math.min(refresh, data.refreshAfter || 90);
            last = Math.max(last, data.updatedAt || 0);
          }
          if (--count === 0) {
            var tomorrow = new Date(date);
            tomorrow.setDate(tomorrow.getDate() + 1);
            var nextSeen = {};
            nextMatches = rows.filter(function(m) {
              var id = "m" + m.id;
              if (nextSeen[id]) return false;
              nextSeen[id] = true;
              return day(new Date(m.kickoff)) === day(tomorrow) && ["NS", "TBD"].indexOf(m.status) >= 0;
            });
            var seen = {};
            matches = rows.filter(function(m) {
              var id = "m" + m.id;
              if (seen[id]) return false;
              seen[id] = true;
              return day(new Date(m.kickoff)) === day(date);
            }).sort(function(a, b) {
              return (live(b) ? 1 : 0) - (live(a) ? 1 : 0) || new Date(a.kickoff) - new Date(b.kickoff);
            });
            finish(firstError, { stale: old, updatedAt: last, refreshAfter: refresh });
          }
        });
      });
    } else {
      var route = screen === "match" ? "match?id=" + selected.id : screen === "competitions" ? "competitions" : screen + "?league=" + league.id + "&season=" + league.season;
      api(route, function(err, data) {
        if (data) {
          if (screen === "competitions") competitions = data.data;
          else if (screen === "match") {
            if (data.data[0]) selected = data.data[0];
          } else payload = data.data;
        } else if (screen !== "match") payload = [];
        finish(err, data);
      });
    }
  }
  function back() {
    if (screen === "match") {
      screen = "fixtures";
      load();
      focus(returnId);
      return;
    }
    if (screen === "standings" || screen === "teams") {
      screen = "competitions";
      page = 0;
      load();
      return;
    }
    if (screen === "calendar") {
      screen = "fixtures";
      render();
      return;
    }
    C.showView("home");
    ensureDock(document.getElementById("favourites"));
    if (C.DockLayout) C.DockLayout();
    C.Focus.focus(document.getElementById("dock-sports"));
  }
  function enter() {
    active = true;
    root.hidden = false;
    C.Focus.setScope(root);
    load();
    focus("sports-tab-all");
  }
  function ensureDock(dock) {
    var b = document.getElementById("dock-sports");
    if (!b) {
      b = C.el("button", "app-card dock-sports");
      b.id = "dock-sports";
      b.setAttribute("data-no-translate", "");
      var icon = C.el("span", "app-icon ui-dock-icon");
      icon.innerHTML = w.MorphIcons ? MorphIcons.svg("sports") : "";
      b.appendChild(icon);
      b.appendChild(C.el("span", "app-name"));
      b.onclick = function() {
        C.showView("sports");
      };
      dock.insertBefore(b, dock.firstChild);
    }
    if (dock.firstChild !== b) {
      var restore = document.activeElement === b;
      dock.insertBefore(b, dock.firstChild);
      if (restore) C.Focus.focus(b);
    }
    b.querySelector(".app-name").textContent = t("title");
    b.setAttribute("aria-label", t("title"));
  }
  C.Sports = { enter, leave, back, ensureDock };
  w.addEventListener("load", function() {
    ensureDock(document.getElementById("favourites"));
    var old = C.back;
    C.back = function() {
      if (active) {
        back();
        return;
      }
      return old();
    };
    if (C.Remote) {
      var key = C.Remote.key;
      C.Remote.key = function(name) {
        if (active && (name === "HOME" || name === "RETURN")) {
          if (name === "HOME") {
            C.showView("home");
            ensureDock(document.getElementById("favourites"));
            if (C.DockLayout) C.DockLayout();
            C.Focus.focus(document.getElementById("dock-sports"));
          } else back();
          return { sent: true };
        }
        return key.apply(C.Remote, arguments);
      };
    }
    if (C.DockLayout) C.DockLayout();
  });
  w.addEventListener("morphLanguage", function() {
    ensureDock(document.getElementById("favourites"));
    if (active) render();
  });
  w.addEventListener("morphViewer", function() {
    if (active) render();
  });
  document.addEventListener("visibilitychange", function() {
    if (!active) return;
    if (document.hidden) stop();
    else load();
  });
  w.addEventListener("online", function() {
    if (active) load();
  });
  document.addEventListener("keydown", function(e) {
    if (active && e.keyCode === 461) {
      e.preventDefault();
      e.stopImmediatePropagation();
      back();
    }
  }, true);
})(window, window.ClearTV);
