(function(C) {
  "use strict";
  var section, rail, last, inputs, inputRow, toggles = [];
  function t(ar, en) {
    return window.MorphLocale ? MorphLocale.t(ar, en) : en;
  }
  function focusBeforeHide(node) {
    if (node && node.contains(document.activeElement)) C.Focus.focus(document.getElementById("nav-home"));
  }
  var recentStamp = "", inputStamp = "", lastStamp = "", pending = false;
  function put(node, value) {
    if (node.textContent !== value) node.textContent = value;
  }
  function schedule() {
    if (pending) return;
    pending = true;
    requestAnimationFrame(function() {
      pending = false;
      render();
    });
  }
  function render() {
    if (!section) return;
    var fit = document.getElementById("home-fitness");
    if (fit) {
      fit.hidden = C.settings.showFitnessApp !== true;
      if (fit.hidden) focusBeforeHide(fit);
    }
    var language = window.MorphLocale ? MorphLocale.get() : "en", enabled = C.settings.showRecentApps === true;
    if (!enabled) focusBeforeHide(section);
    section.hidden = !enabled;
    var recent = enabled ? C.read("recent", []).slice(0, 5).map(function(id) {
      return C.Catalog.get(id);
    }).filter(function(app) {
      return app && (!C.AppCatalog || C.AppCatalog.visible(app));
    }) : [], stamp = JSON.stringify([language, enabled, recent.map(function(a) {
      return [a.id, a.name, a.icon];
    })]);
    if (stamp !== recentStamp) {
      recentStamp = stamp;
      rail.textContent = "";
      recent.forEach(function(app) {
        var b = C.el("button", "recent-app-card");
        b.appendChild(C.Catalog.icon(app));
        var copy = C.el("span", "recent-app-copy");
        copy.appendChild(C.el("strong", "", app.name));
        b.appendChild(copy);
        b.onclick = function() {
          C.Catalog.launch(app);
        };
        rail.appendChild(b);
      });
      put(section.querySelector("h2"), t("\u0627\u0644\u062A\u0637\u0628\u064A\u0642\u0627\u062A \u0627\u0644\u0645\u0633\u062A\u062E\u062F\u0645\u0629 \u0645\u0624\u062E\u0631\u064B\u0627", "Recently used apps"));
      var empty = section.querySelector("p");
      empty.hidden = !!rail.children.length;
      put(empty, t("\u0633\u062A\u0638\u0647\u0631 \u0627\u0644\u062A\u0637\u0628\u064A\u0642\u0627\u062A \u0627\u0644\u062A\u064A \u062A\u0641\u062A\u062D\u0647\u0627 \u0647\u0646\u0627.", "Apps you open will appear here."));
    }
    var source = C.read("lastHdmi", null);
    last.hidden = C.settings.showLastHdmi !== true;
    if (last.hidden) focusBeforeHide(last);
    stamp = JSON.stringify([language, source, last.hidden]);
    if (stamp !== lastStamp) {
      lastStamp = stamp;
      put(last.querySelector("small"), t("\u0622\u062E\u0631 \u0645\u062F\u062E\u0644 HDMI", "Last HDMI input"));
      put(last.querySelector("strong"), source ? source.title || "HDMI " + source.number : t("\u0627\u062E\u062A\u0627\u0631 \u0645\u062F\u062E\u0644 \u0623\u0648\u0644\u064B\u0627", "Choose an input first"));
      last.onclick = function() {
        if (source) C.Inputs.watch(source);
        else C.showView("inputs");
      };
    }
    var rows = (C.Inputs.state.sources || []).filter(function(s) {
      return s.type === "HDMI";
    }), show = C.settings.showHomeHdmi === true;
    stamp = JSON.stringify([language, show, rows]);
    if (stamp !== inputStamp) {
      inputStamp = stamp;
      if (!show) focusBeforeHide(inputs);
      var selected = document.activeElement && document.activeElement.getAttribute("data-home-input");
      inputs.textContent = "";
      inputs.hidden = !show;
      if (show) rows.forEach(function(s) {
        var b = C.el("button", "home-hdmi-shortcut");
        b.setAttribute("data-home-input", s.id || s.type + ":" + s.number);
        var icon = C.el("span", "home-input-icon");
        icon.innerHTML = window.MorphIcons ? MorphIcons.svg("inputs") : C.icon("tv");
        icon.setAttribute("aria-hidden", "true");
        b.appendChild(icon);
        var copy = C.el("span", "home-input-copy");
        copy.appendChild(C.el("strong", "", C.Inputs.label(s)));
        copy.appendChild(C.el("small", "", s.connected ? t("\u0645\u062A\u0635\u0644", "Connected") : t("\u0645\u062F\u062E\u0644 \u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646", "TV input")));
        b.appendChild(copy);
        b.onclick = function() {
          C.Inputs.watch(s);
        };
        inputs.appendChild(b);
        if (selected === b.getAttribute("data-home-input")) C.Focus.focus(b);
      });
    }
    if (inputRow) inputRow.hidden = inputs.hidden && last.hidden;
    toggles.forEach(function(row) {
      put(row.button.querySelector("span"), t(row.ar, row.en));
      var on = C.settings[row.key] === true;
      put(row.button.querySelector("strong"), on ? t("\u0638\u0627\u0647\u0631", "Shown") : t("\u0645\u062E\u0641\u064A", "Hidden"));
      row.button.setAttribute("aria-pressed", String(on));
    });
  }
  window.addEventListener("load", function() {
    var home = document.getElementById("view-home"), all = document.getElementById("manage-apps");
    if (all) all.hidden = true;
    section = C.el("section", "recent-apps-section");
    section.id = "home-recent-apps";
    section.setAttribute("data-no-translate", "");
    section.innerHTML = "<h2></h2><p></p>";
    rail = C.el("div", "recent-apps-rail");
    rail.setAttribute("data-scroll", "horizontal");
    section.appendChild(rail);
    home.appendChild(section);
    last = C.el("button", "last-hdmi-card");
    last.id = "home-last-hdmi";
    last.setAttribute("data-no-translate", "");
    last.innerHTML = C.icon("tv") + "<span><small></small><strong></strong></span>";
    home.appendChild(last);
    inputs = C.el("div", "home-hdmi-shortcuts");
    inputs.id = "home-hdmi-shortcuts";
    inputs.setAttribute("data-scroll", "horizontal");
    home.appendChild(inputs);
    inputRow = C.el("div", "home-input-row");
    inputRow.id = "home-input-row";
    inputRow.appendChild(inputs);
    inputRow.appendChild(last);
    home.appendChild(inputRow);
    var host = document.getElementById("setting-favourites").parentNode;
    [["showFitnessApp", "setting-home-fitness", "\u0625\u0638\u0647\u0627\u0631 \u0627\u0644\u062A\u0645\u0627\u0631\u064A\u0646 \u0641\u064A \u0627\u0644\u0642\u0627\u0626\u0645\u0629 \u0627\u0644\u062C\u0627\u0646\u0628\u064A\u0629", "Show Fitness in the sidebar"], ["showRecentApps", "setting-recent-apps", "\u0627\u0644\u062A\u0637\u0628\u064A\u0642\u0627\u062A \u0627\u0644\u0623\u062E\u064A\u0631\u0629 \u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0645", "Recently used apps on Home"], ["showHomeHdmi", "setting-home-hdmi", "\u0627\u062E\u062A\u0635\u0627\u0631\u0627\u062A HDMI \u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0645", "HDMI shortcuts on Home"], ["showLastHdmi", "setting-last-hdmi", "\u0622\u062E\u0631 \u0645\u062F\u062E\u0644 HDMI \u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0645", "Last HDMI input on Home"]].forEach(function(row) {
      var b = C.el("button", "setting");
      b.id = row[1];
      b.setAttribute("data-no-translate", "");
      b.innerHTML = "<span></span><strong></strong>";
      b.onclick = function() {
        C.settings[row[0]] = C.settings[row[0]] !== true;
        C.saveSettings();
        render();
      };
      host.appendChild(b);
      toggles.push({ key: row[0], button: b, ar: row[2], en: row[3] });
    });
    var write = C.write;
    C.write = function(key, value) {
      var result = write.apply(C, arguments);
      if (key === "recent" || key === "lastHdmi") schedule();
      return result;
    };
    var changed = C.inputsChanged;
    C.inputsChanged = function(state) {
      if (changed) changed(state);
      schedule();
    };
    C.refreshRecentSection = schedule;
    render();
  });
  ["morphViewer", "morphLanguage", "morphAppsChanged"].forEach(function(name) {
    window.addEventListener(name, render);
  });
})(window.ClearTV);
