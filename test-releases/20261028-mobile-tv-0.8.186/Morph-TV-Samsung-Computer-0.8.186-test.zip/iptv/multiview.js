(function() {
  "use strict";
  if (!window.IptvNative || typeof IptvNative.supportsMultiView !== "function" || !IptvNative.supportsMultiView()) return;
  var nav = document.querySelector("header nav"), cards = document.querySelector(".portal-grid");
  if (!nav || !cards) return;
  function tr(a, b) {
    return window.MorphLocale ? MorphLocale.t(a, b) : b;
  }
  var open = document.createElement("button"), card = document.createElement("button");
  open.id = "multiview-open";
  card.id = "home-multiview";
  open.dataset.noTranslate = card.dataset.noTranslate = "";
  card.innerHTML = '<img class="portal-icon" src="icon-live.svg" alt=""><strong></strong><small></small>';
  function launch() {
    IptvNative.multiView();
  }
  open.onclick = card.onclick = launch;
  nav.appendChild(open);
  cards.appendChild(card);
  function labels() {
    open.textContent = tr("\u0664 \u0634\u0627\u0634\u0627\u062A", "Multi-view");
    card.querySelector("strong").textContent = tr("\u0634\u0627\u0634\u0627\u062A \u0645\u062A\u0639\u062F\u062F\u0629", "Multi-view");
    card.querySelector("small").textContent = tr("\u062D\u062A\u0649 \u0664 \u0642\u0646\u0648\u0627\u062A \xB7 \u0627\u062E\u062A\u0631 \u0627\u0644\u0635\u0648\u062A \u0648\u0627\u0644\u062A\u0642\u0633\u064A\u0645\u0629", "Up to 4 channels \xB7 choose audio and layout");
  }
  window.addEventListener("morphLanguage", labels);
  labels();
})();
