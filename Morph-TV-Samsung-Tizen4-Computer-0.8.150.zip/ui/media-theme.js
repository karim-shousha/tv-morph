(function(w) {
  "use strict";
  var wasModern = false, previousMedia = {}, meta = document.querySelector("meta[name=tvm-media-root]"), base = meta ? meta.content : "../tv/", queued = false;
  var css = document.createElement("link");
  css.rel = "stylesheet";
  css.href = base + "ui/internal-pages.css";
  document.head.appendChild(css);
  var defaults = document.createElement("link");
  defaults.rel = "stylesheet";
  defaults.href = base + "ui/tokens.css";
  document.head.appendChild(defaults);
  function config() {
    var stored = {}, native = {};
    try {
      if (parent !== w && parent.ClearTV) return parent.ClearTV.settings;
      var bridge = w.IptvNative || w.RadioNative;
      if (bridge && bridge.settingsJson) native = JSON.parse(bridge.settingsJson());
      var viewer = localStorage.getItem("cleartv.activeViewer") || "default";
      if (!/^(default|v[0-9a-z]+)$/.test(viewer)) viewer = "default";
      stored = JSON.parse(localStorage.getItem("cleartv." + (viewer === "default" ? "" : "viewer." + viewer + ".") + "settings")) || {};
    } catch (e) {
    }
    var value = {};
    Object.keys(native).forEach(function(k) {
      value[k] = native[k];
    });
    Object.keys(stored).forEach(function(k) {
      value[k] = stored[k];
    });
    return value;
  }
  function apply() {
    queued = false;
    var cfg = config(), adapter = w.MorphThemeAdapter;
    try {
      if (parent !== w && parent.MorphThemeAdapter) adapter = parent.MorphThemeAdapter;
    } catch (ignore) {
    }
    var modern = cfg.uiMode === "modern";
    if (modern && !adapter) return;
    document.body.setAttribute("data-ui-mode", modern ? "modern" : "classic");
    document.body.setAttribute("data-media-ui", "true");
    if (!modern) {
      if (wasModern) {
        wasModern = false;
        Object.keys(previousMedia).forEach(function(k) {
          document.documentElement.style.setProperty(k, previousMedia[k]);
        });
        w.dispatchEvent(new Event("focus"));
      }
      return;
    }
    if (!wasModern) {
      ["--media-bg", "--media-card", "--media-accent", "--media-secondary", "--media-art"].forEach(function(k) {
        previousMedia[k] = document.documentElement.style.getPropertyValue(k);
      });
      wasModern = true;
    }
    var value = adapter.resolve(cfg), root = document.documentElement;
    Object.keys(value.tokens).forEach(function(k) {
      root.style.setProperty(k, value.tokens[k]);
      document.body.style.setProperty(k, value.tokens[k]);
    });
    root.setAttribute("data-ui-theme", value.theme);
    root.style.setProperty("--media-bg", value.tokens["--ui-bg"]);
    root.style.setProperty("--media-card", value.tokens["--ui-bg-raised"]);
    root.style.setProperty("--media-accent", value.tokens["--ui-accent"]);
    root.style.setProperty("--media-secondary", value.tokens["--ui-accent-secondary"]);
    var art = value.art.source, packs = w.ThemePacks;
    try {
      if (parent !== w && parent.ThemePacks) packs = parent.ThemePacks;
    } catch (ignore) {
    }
    if (art) {
      var source = value.art.custom ? art : base + "assets/" + art;
      if (packs && !value.art.custom) source = packs.src(source);
      root.style.setProperty("--media-art", "url(" + JSON.stringify(source) + ")");
    } else root.style.setProperty("--media-art", "none");
  }
  function schedule() {
    if (!queued) {
      queued = true;
      (w.requestAnimationFrame || function(fn) {
        setTimeout(fn, 16);
      })(apply);
    }
  }
  function load(file, next) {
    var s = document.createElement("script");
    s.src = base + file;
    s.onload = next;
    s.onerror = function() {
      document.body.setAttribute("data-ui-mode", "classic");
    };
    document.head.appendChild(s);
  }
  function ready() {
    schedule();
    ["load", "focus", "storage", "morphPacks"].forEach(function(n) {
      w.addEventListener(n, schedule);
    });
    try {
      if (parent !== w) ["morphTheme", "morphUIMode", "morphViewer", "morphPerformance", "morphPacks", "morphTextSize"].forEach(function(n) {
        parent.addEventListener(n, schedule);
      });
    } catch (ignore) {
    }
    w.addEventListener("unload", function() {
      try {
        if (parent !== w) ["morphTheme", "morphUIMode", "morphViewer", "morphPerformance", "morphPacks", "morphTextSize"].forEach(function(n) {
          parent.removeEventListener(n, schedule);
        });
      } catch (ignore) {
      }
    });
    w.MorphMediaUI = { apply };
  }
  try {
    if (parent !== w && parent.MorphThemeAdapter) {
      ready();
      return;
    }
  } catch (ignore) {
  }
  load("club-themes.js", function() {
    load("ui/theme-adapter.js", ready);
  });
})(window);
