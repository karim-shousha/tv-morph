const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict'),{execFileSync}=require('node:child_process');
let playwright;try{playwright=require('playwright');}catch{playwright=require('C:/Users/Admin/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');}
const HERE=path.resolve(__dirname,'..'),OUT=path.join(HERE,'test-output');fs.mkdirSync(OUT,{recursive:true});
const sample=path.join(OUT,'fixture.mp4');
if(!fs.existsSync(sample))execFileSync('ffmpeg',['-hide_banner','-loglevel','error','-f','lavfi','-i','testsrc2=size=320x180:rate=24','-f','lavfi','-i','sine=frequency=440:sample_rate=44100','-t','40','-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p','-c:a','aac','-movflags','+faststart','-y',sample],{windowsHide:true});
if(!fs.existsSync(path.join(OUT,'fixture.m3u8')))execFileSync('ffmpeg',['-hide_banner','-loglevel','error','-i',sample,'-c','copy','-f','hls','-hls_time','4','-hls_playlist_type','vod','-hls_segment_filename',path.join(OUT,'fixture%d.ts'),'-y',path.join(OUT,'fixture.m3u8')],{windowsHide:true});
let base;const requests=[];
const server=http.createServer((req,res)=>{const url=new URL(req.url,base);requests.push(url.pathname+url.search);
 function json(value){res.setHeader('Content-Type','application/json');res.end(JSON.stringify(value));}
 if(url.pathname==='/playlist.m3u'){res.setHeader('Content-Type','audio/x-mpegurl');res.end('#EXTM3U\n#EXTINF:-1 tvg-id="test" group-title="Test",Desktop test channel\n'+base+'/fixture.mp4\n');return;}
 if(url.pathname==='/player_api.php'){const a=url.searchParams.get('action');if(!a)return json({user_info:{auth:1,status:'Active',username:'fixture',exp_date:'2000000000'},server_info:{}});
  if(a.endsWith('_categories'))return json([{category_id:'1',category_name:'Desktop test'}]);
  if(a==='get_live_streams')return json([{stream_id:1,name:'PC live fixture',category_id:'1',direct_source:base+'/fixture.mp4'}]);
  if(a==='get_vod_streams')return json([{stream_id:2,name:'PC movie fixture',category_id:'1',container_extension:'mp4'}]);
  if(a==='get_series')return json([{series_id:3,name:'PC series fixture',category_id:'1'}]);
  if(a==='get_series_info')return json({info:{name:'PC series fixture'},episodes:{1:[{id:'4',title:'Episode 1',season:1,episode_num:1,container_extension:'mp4',info:{}}]}});
  if(a==='get_vod_info')return json({info:{name:'PC movie fixture',plot:'Local playback verification'},movie_data:{stream_id:2,container_extension:'mp4'}});
  if(a==='get_short_epg')return json({epg_listings:[]});return json([]);
 }
 if(url.pathname.endsWith('.m3u8')){res.setHeader('Content-Type','application/vnd.apple.mpegurl');res.end(fs.readFileSync(path.join(OUT,'fixture.m3u8')));return;}
 if(url.pathname.endsWith('.ts')){const filename=path.basename(url.pathname);const target=path.join(OUT,/^fixture\d+\.ts$/.test(filename)?filename:'fixture0.ts');res.setHeader('Content-Type','video/mp2t');fs.createReadStream(target).pipe(res);return;}
 if(url.pathname.endsWith('.mp4')){const size=fs.statSync(sample).size;const match=/bytes=(\d+)-(\d*)/.exec(req.headers.range||'');const start=match?Number(match[1]):0,end=match&&match[2]?Math.min(size-1,Number(match[2])):size-1;res.writeHead(match?206:200,{'Content-Type':'video/mp4','Content-Length':end-start+1,'Accept-Ranges':'bytes',...(match?{'Content-Range':`bytes ${start}-${end}/${size}`}:{})});if(req.method==='HEAD')res.end();else fs.createReadStream(sample,{start,end}).pipe(res);return;}
 res.writeHead(404);res.end('missing');});
let application;const errors=[],missing=[],checks=[],USER_DIR=path.join(OUT,'user-'+Date.now());
fs.mkdirSync(USER_DIR,{recursive:true});fs.writeFileSync(path.join(USER_DIR,'matches-cache.json'),JSON.stringify({updatedAt:Date.now()/1000,matches:[{id:'9001',kickoff:new Date(Date.now()+3600000).toISOString(),timeKnown:true,status:'scheduled',competition:'Desktop test fixture',home:{id:'133738',name:'Fixture Home',badge:''},away:{id:'133739',name:'Fixture Away',badge:''},score:{home:null,away:null}}]}));
async function launch(){const env={...process.env,MORPH_PC_TEST_DATA:USER_DIR};delete env.ELECTRON_RUN_AS_NODE;const packaged=process.env.MORPH_PC_TEST_EXECUTABLE;application=await playwright._electron.launch({executablePath:packaged||require('electron'),args:packaged?[]:[HERE],cwd:HERE,env,timeout:60000});const page=await application.firstWindow();page.on('pageerror',e=>errors.push(e.message));page.on('response',r=>{if(r.status()===404&&r.url().startsWith('morph://app/'))missing.push(r.url());});await application.evaluate(({BrowserWindow})=>{const w=BrowserWindow.getAllWindows()[0];w.webContents.setAudioMuted(true);});return page;}
(async()=>{await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));base='http://127.0.0.1:'+server.address().port;
try{const page=await launch();await page.waitForSelector('#pc-home');await page.waitForFunction(()=>ClearTV.Catalog.apps.length>3,{timeout:30000});
assert.equal(await page.evaluate(()=>typeof require),'undefined');checks.push('Sandboxed UI; installed Windows app inventory loads');
console.log('Desktop started');
await page.locator('#nav-settings').click();await page.locator('#settings-category-performance-entry').click();
const beforeScroll=await page.locator('#view-settings').evaluate(e=>{if(e.scrollHeight<=e.clientHeight){const fixture=document.createElement('div');fixture.style.cssText='height:900px;flex-shrink:0';fixture.dataset.scrollFixture='true';e.appendChild(fixture);}e.scrollTop=0;return {top:e.scrollTop,height:e.clientHeight,total:e.scrollHeight};});const settingsBox=await page.locator('#view-settings').boundingBox();await page.mouse.move(settingsBox.x+settingsBox.width*.75,settingsBox.y+settingsBox.height*.55);await page.mouse.wheel(0,900);await page.waitForFunction(()=>document.getElementById('view-settings').scrollTop>0,null,{timeout:4000});const afterScroll=await page.locator('#view-settings').evaluate(e=>{const value=e.scrollTop;e.querySelector('[data-scroll-fixture]')?.remove();return value;});assert(afterScroll>beforeScroll.top,'Settings must scroll with the mouse wheel');checks.push('Compact settings scroll with a real mouse-wheel event');await page.locator('#pc-home').click();
await page.locator('#home-matches').click();await page.locator('#view-matches .match-row').waitFor();assert((await page.locator('#view-matches').innerText()).includes('Desktop test fixture'));await page.locator('#matches-tab-results').click();await page.locator('#matches-back').click();checks.push('Mouse opens shared match schedule, real transport contract renders a fixture and Results/Back work');
await page.locator('#home-continue').click();const frame=page.frameLocator('#morph-media-frame');await frame.locator('#stream-sources').waitFor();
console.log('IPTV frame loaded');
await frame.locator('#iptv-first-source [data-choice="add"]').click();await frame.locator('#account-method-xtream').click();
console.log('Account form opened');
await frame.locator('#account-server').fill(base);await frame.locator('#account-user').fill('fixture');await frame.locator('#account-password').fill('fixture-secret');await frame.locator('#account-name').fill('Desktop fixture');
assert.equal(await frame.locator('#account-server').evaluate(e=>e.readOnly),false);await frame.locator('#account-save').click();
await page.waitForFunction(()=>JSON.parse(localStorage.getItem('morph.pc.iptv')||'{}').username==='fixture',{timeout:30000});checks.push('Mouse opens embedded IPTV; physical typing and Xtream account connect via local fixture');
await page.waitForTimeout(1500);console.log('Connected',await frame.locator('body').innerText().then(x=>x.slice(-1200)));
await page.screenshot({path:path.join(OUT,'iptv.png')});
await page.locator('#pc-home').click();assert.equal(await page.locator('#morph-media-frame').count(),0);checks.push('Mouse Home exits IPTV');
// Exercise shared provider list and real HTML5 decoding independently of provider availability.
await page.evaluate(()=>SamsungMedia.open('iptv'));await frame.locator('#stream-sources').waitFor();
await page.evaluate(()=>SamsungMedia.action('play',{kind:'vod',id:'2',name:'PC movie fixture',ext:'mp4'}));
await page.locator('#morph-player video').waitFor();await page.waitForFunction(()=>{const v=document.querySelector('#morph-player video');return v&&v.videoWidth>0&&v.currentTime>.2;},{timeout:30000});
checks.push('Real H.264/AAC video decodes and plays through embedded player');
await page.locator('#morph-player video').evaluate(v=>v.pause());await page.locator('#morph-player').hover();await page.screenshot({path:path.join(OUT,'player-fade.png')});
assert(await page.locator('.morph3-shades').evaluate(e=>{const video=e.parentElement.querySelector('video');return Number(getComputedStyle(e).zIndex)>Number(getComputedStyle(video).zIndex)&&getComputedStyle(e).backgroundImage.includes('gradient');}));checks.push('Shared translucent fade renders above video, with compact desktop controls');await page.locator('#morph-player video').evaluate(v=>v.play());
await page.locator('#morph-player').hover();const volume=page.locator('.pc-player-volume input');const vb=await volume.boundingBox();await page.mouse.click(vb.x+vb.width*.35,vb.y+vb.height/2);assert((await page.locator('#morph-player video').evaluate(v=>v.volume))<.6);checks.push('Mouse changes player volume');
const timeline=page.locator('#morph-player input.morph2-range');const box=await timeline.boundingBox();await page.mouse.move(box.x+box.width*.15,box.y+box.height/2);await page.mouse.down();await page.mouse.move(box.x+box.width*.6,box.y+box.height/2,{steps:8});await page.mouse.up();await page.waitForFunction(()=>document.querySelector('#morph-player video').currentTime>15);checks.push('Mouse drags timeline and seeks decoded media');
await page.screenshot({path:path.join(OUT,'player.png')});
await page.locator('#pc-back').click();await page.waitForFunction(()=>!document.getElementById('morph-player'));checks.push('Visible mouse Back closes player');
await page.evaluate(()=>SamsungMedia.action('play',{kind:'live',id:'1',name:'HLS fixture'}));await page.waitForFunction(()=>{const v=document.querySelector('#morph-player video');return v&&v.videoWidth>0&&v.currentTime>.2;},{timeout:30000});assert(requests.some(url=>url.endsWith('.m3u8')));checks.push('Live HLS manifest and TS segments play through the desktop transport');await page.locator('#pc-back').click();
await page.locator('#pc-home').click();
await application.evaluate(({dialog},folder)=>{dialog.showOpenDialog=async()=>({canceled:false,filePaths:[folder]});},OUT);
await page.locator('#dock-hdmi').click();await page.locator('#pc-media-browser .usb-button').filter({hasText:'fixture.mp4'}).click();await page.waitForFunction(()=>{const v=document.querySelector('#pc-media-browser video');return v&&v.videoWidth>0;},{timeout:15000});checks.push('Mouse opens native media-folder picker, browses files and plays a local MP4');await page.locator('#pc-back').click();
await page.evaluate(async()=>{let rejected=false;try{await MorphPC.launch('windows:not-an-installed-app');}catch{rejected=true;}if(!rejected)throw Error('Unregistered app launch was accepted');});checks.push('Native bridge rejects unregistered application launches');
await page.locator('#pc-home').click();await page.locator('#nav-apps').click();await page.locator('#app-search').fill('Notepad');await page.locator('#search-installed').click();checks.push('Mouse opens Windows apps and types into search');
await page.locator('#pc-home').click();await page.locator('#pc-fullscreen').click();for(let i=0;i<30&&!(await application.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].isFullScreen()));i++)await page.waitForTimeout(100);assert.equal(await application.evaluate(({BrowserWindow})=>BrowserWindow.getAllWindows()[0].isFullScreen()),true);await page.locator('#pc-fullscreen').click();checks.push('Mouse enters and leaves fullscreen');
await page.screenshot({path:path.join(OUT,'home.png')});
await application.close();application=null;const reopened=await launch();await reopened.waitForSelector('#pc-home');assert.equal(await reopened.evaluate(()=>JSON.parse(localStorage.getItem('morph.pc.iptv')).username),'fixture');checks.push('IPTV account persists across application restart');
assert.deepEqual(errors,[]);const missingAssets=[...new Set(missing)].filter(url=>!url.includes('/__remote?'));assert.deepEqual(missingAssets,[]);const result={passed:true,checks,errors,missingAssets,external404:[...new Set(missing)].filter(url=>url.includes('/__remote?')),fixtureRequests:requests.length};fs.writeFileSync(path.join(OUT,'results.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
}catch(e){if(application){const p=await application.firstWindow();await p.screenshot({path:path.join(OUT,'failure.png')}).catch(()=>{});console.error('Page errors:',errors,'Missing:',missing);console.error(await p.evaluate(()=>document.body.innerText.slice(-1500)).catch(()=>''));}throw e;}finally{if(application)await application.close();server.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
