const {contextBridge,ipcRenderer}=require('electron');
const call=(name,...args)=>ipcRenderer.invoke('pc:'+name,...args);
contextBridge.exposeInMainWorld('MorphPC',{
 plusIdentity:()=>call('plusIdentity'),savePlusIdentity:value=>call('savePlusIdentity',value),apps:()=>call('apps'),launch:id=>call('launch',id),external:url=>call('external',url),
 settings:kind=>call('settings',kind),fullscreen:()=>call('fullscreen'),startup:on=>call('startup',on),
 info:()=>call('info'),exit:()=>call('exit'),pickFolder:()=>call('pickFolder'),
 directory:(id,relative)=>call('directory',id,relative),pickSubtitle:()=>call('pickSubtitle'),pickPlaylist:()=>call('pickPlaylist'),network:(action,payload)=>call('network',action,payload)
});
