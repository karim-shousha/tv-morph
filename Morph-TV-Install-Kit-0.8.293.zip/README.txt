Morph Launcher 0.8.293 / Morph IPTV 0.1.3
Android TV / Android-based Fire TV: install APK over existing app.
Samsung: select the exact Tizen WGT, then use Apps2Samsung or a device-signed Developer Mode installation.
LG: install IPK using Developer Mode; keep Developer Mode enabled and extend its session before expiry.
VIDAA is excluded. Keep accounts by installing updates over the same product.
Physical compatibility varies by model. Latest links: https://morphtv.herroshetta.com/
