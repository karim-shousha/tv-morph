Morph Launcher 1.1.308 / Morph IPTV 1.1.308
This computer install kit contains Samsung WGT and LG IPK packages. Android TV / Android-based Fire TV APKs are separate at /download/android and /download/iptv/android.
Samsung: select the exact Tizen WGT, then use Apps2Samsung or a device-signed Developer Mode installation.
LG: install IPK using Developer Mode; keep Developer Mode enabled and extend its session before expiry.
VIDAA is excluded. Keep accounts by installing updates over the same product.
Physical compatibility varies by model. Latest links: https://morph-tv.com/
