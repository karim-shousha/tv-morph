(function(C) {
  "use strict";
  var dock, queued = false, startFocused = false, userNavigated = false, pointerActive = false, lastDockKey = "", centerFrame = 0, centerTarget = null, lastSidebar = null, lastDockNode = null;
  function dockLayout() {
    if (!dock) return;
    var buttons = Array.prototype.filter.call(dock.children, function(b) {
      return b.tagName === "BUTTON" && !b.hidden;
    }), style = getComputedStyle(dock), room = dock.clientWidth - parseFloat(style.paddingLeft || 0) - parseFloat(style.paddingRight || 0), total = 0;
    buttons.forEach(function(b) {
      var s = getComputedStyle(b);
      total += b.offsetWidth + (parseFloat(s.marginLeft) || 0) + (parseFloat(s.marginRight) || 0);
    });
    var overflow = total > room + 1;
    dock.setAttribute("data-overflow", String(overflow));
    dock.style.justifyContent = overflow ? "flex-start" : "center";
    if (!overflow) dock.scrollLeft = 0;
  }
  function centerDock(button) {
    dockLayout();
    if (dock && dock.getAttribute("data-overflow") === "false") return;
    if (pointerActive || !dock || !button || !dock.contains(button)) return;
    centerTarget = button;
    if (centerFrame) return;
    centerFrame = requestAnimationFrame(function() {
      centerFrame = 0;
      var target = centerTarget;
      if (pointerActive || !target || !dock.contains(target)) return;
      var left = target.offsetLeft, right = left + target.offsetWidth, margin = 40, visibleLeft = dock.scrollLeft, visibleRight = visibleLeft + dock.clientWidth;
      if (left - margin < visibleLeft) dock.scrollLeft = Math.max(0, left - margin);
      else if (right + margin > visibleRight) dock.scrollLeft = right + margin - dock.clientWidth;
    });
  }
  document.addEventListener("pointerdown", function(e) {
    if (dock && e.target.closest("#favourites>button")) {
      pointerActive = true;
      userNavigated = true;
    }
  }, true);
  ["pointerup", "pointercancel"].forEach(function(name) {
    document.addEventListener(name, function() {
      if (!pointerActive) return;
      pointerActive = false;
      setTimeout(function() {
        centerDock(document.activeElement);
      }, 0);
    }, true);
  });
  C.DockArrow = function(code, current) {
    if (code !== 37 && code !== 39 || !dock || !current) return false;
    var buttons = Array.prototype.filter.call(dock.children, function(e) {
      return e.tagName === "BUTTON" && !e.hidden && !e.disabled && e.offsetWidth;
    });
    if (code === 39 && current.closest(".home-tools")) {
      C.Focus.focus(lastDockNode && document.documentElement.contains(lastDockNode) ? lastDockNode : buttons[0]);
      return true;
    }
    if (current.parentNode !== dock) return false;
    var index = buttons.indexOf(current);
    if (index < 0) return false;
    var next = index + (code === 39 ? 1 : -1);
    if (next >= 0 && next < buttons.length) C.Focus.focus(buttons[next]);
    else if (code === 37) {
      var side = Array.prototype.filter.call(document.querySelectorAll("#view-home .home-tools>button"), function(b) {
        return !b.hidden && !b.disabled && b.offsetWidth;
      });
      var target = lastSidebar && side.indexOf(lastSidebar) >= 0 ? lastSidebar : side[side.length - 1];
      if (target) C.Focus.focus(target);
    }
    return true;
  };
  document.addEventListener("focusin", function(e) {
    if (e.target.closest("#view-home .home-tools")) lastSidebar = e.target;
    if (dock && e.target.parentNode === dock) lastDockNode = e.target;
  });
  function initialDock() {
    dockLayout();
    if (startFocused || userNavigated || !dock || document.documentElement.classList.contains("theme-starting") || document.getElementById("view-home").hidden) return;
    var overlay = document.getElementById("overlay");
    if (overlay && !overlay.hidden) return;
    var choices = Array.prototype.slice.call(dock.querySelectorAll(".favourite:not(.add-favourite)"));
    var first = choices.filter(function(b) {
      var app = C.Catalog.get(b.getAttribute("data-favourite-id"));
      return app && (/local\.tvmorph\.tv\.play/.test(app.id) || /^TVM[- ]IPTV$/i.test(app.name));
    })[0] || choices[0];
    if (!first) return;
    startFocused = true;
    C.Focus.focus(first);
    centerDock(first);
  }
  document.addEventListener("keydown", function(e) {
    if ([13, 27, 37, 38, 39, 40, 10009].indexOf(e.keyCode) >= 0) userNavigated = true;
  }, true);
  document.addEventListener("focusin", function(e) {
    var button = dock && e.target.closest("#favourites>button");
    if (button) {
      lastDockKey = button.getAttribute("data-favourite-id") || button.id;
      centerDock(button);
    }
  });
  C.restoreHomeDock = function() {
    if (!dock) return;
    refresh();
    var buttons = Array.prototype.slice.call(dock.querySelectorAll("button"));
    var target = buttons.filter(function(b) {
      return (b.getAttribute("data-favourite-id") || b.id) === lastDockKey && !b.hidden;
    })[0] || buttons.filter(function(b) {
      return !b.hidden;
    })[0];
    if (target) C.Focus.focus(target);
  };
  window.addEventListener("resize", function() {
    dockLayout();
    centerDock(document.activeElement);
  });
  new MutationObserver(function() {
    if (!document.documentElement.classList.contains("theme-starting")) setTimeout(initialDock, 0);
  }).observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
  C.rememberHdmi = function(source) {
    if (!source || source.type !== "HDMI" || !(Number(source.number) > 0)) return;
    C.write("lastHdmi", { type: "HDMI", number: Number(source.number), id: typeof source.id === "string" ? source.id.slice(0, 400) : "", title: typeof source.title === "string" ? source.title.slice(0, 80) : "" });
  };
  var inputsChanged = C.inputsChanged;
  C.inputsChanged = function(state) {
    if (inputsChanged) inputsChanged(state);
    if (state && state.current && state.current.type === "HDMI") C.rememberHdmi(state.current);
  };
  function refresh() {
    queued = false;
    if (!dock) return;
    if (!document.getElementById("dock-hdmi")) {
      var input = C.el("button", "app-card dock-hdmi");
      input.id = "dock-hdmi";
      input.setAttribute("aria-label", "HDMI / Live TV");
      input.innerHTML = '<img class="app-icon" src="assets/tvm-hdmi.svg" alt=""><span class="app-name">HDMI / Live TV</span>';
      input.onclick = function() {
        C.showView("inputs");
      };
      dock.insertBefore(input, dock.firstChild);
    }
  }
  C.DockLayout = dockLayout;
  ["morphPerformance", "morphTextSize", "morphUIMode"].forEach(function(name) {
    window.addEventListener(name, function() {
      setTimeout(dockLayout, 0);
    });
  });
  function schedule() {
    if (queued) return;
    queued = true;
    setTimeout(function() {
      refresh();
      initialDock();
      if (dock && dock.contains(document.activeElement)) centerDock(document.activeElement);
    }, 0);
  }
  function magnify(button) {
    if (!dock || document.body.classList.contains("light-mode")) return;
    var buttons = Array.prototype.filter.call(dock.children, function(n) {
      return n.tagName === "BUTTON" && !n.hidden;
    }), i = buttons.indexOf(button);
    buttons.forEach(function(b, index) {
      b.classList.toggle("dock-neighbor", i >= 0 && Math.abs(index - i) === 1);
    });
  }
  window.addEventListener("load", function() {
    var home = document.getElementById("view-home");
    dock = document.getElementById("favourites");
    dock.classList.add("app-dock");
    home.appendChild(dock);
    document.body.classList.add("dock-home");
    var oldInputs = document.getElementById("home-inputs");
    if (oldInputs) oldInputs.hidden = true;
    dock.addEventListener("focusin", function(e) {
      magnify(e.target.closest("button"));
    });
    dock.addEventListener("focusout", function() {
      setTimeout(function() {
        magnify(document.activeElement.closest("#favourites>button"));
      }, 0);
    });
    dock.addEventListener("mouseover", function(e) {
      magnify(e.target.closest("button"));
    });
    dock.addEventListener("mouseleave", function() {
      magnify(document.activeElement.closest("#favourites>button"));
    });
    new MutationObserver(schedule).observe(dock, { childList: true });
    refresh();
  });
  window.addEventListener("morphLanguage", schedule);
  window.addEventListener("morphViewer", schedule);
  window.addEventListener("morphAppOrder", schedule);
  window.addEventListener("focus", schedule);
  document.addEventListener("visibilitychange", function() {
    if (!document.hidden) schedule();
  });
  C.refreshRecentApps = schedule;
})(window.ClearTV);
