# TV Morph for VIDAA — 0.1.0 development preview

This is a dedicated hosted web application, not an Android APK. The archive is a deployment/source artifact, not a file to install from USB.

## Real TV test

1. Open the built-in VIDAA browser.
2. Enter `hisense://debug` in its address bar. Availability varies by firmware.
3. If the official development page appears, enter App Name `TV Morph`, App Url `https://tvmorph.zainbot.com/vidaa.html`, Thumbnail `https://tvmorph.zainbot.com/tvmorph.png`, Resolution `1080`.
4. Select Install. Exit to the TV Apps page and launch TV Morph if the tile appears.
5. Check remote arrows, OK, Back, themes, Arabic/English, persistence after relaunch, media playback and playback resume.

If the debug page is unavailable, opening the application URL in the browser tests the web runtime only. It does not install a TV app. A production VIDAA Store release needs the platform's approved distribution process. Do not change DNS, firmware, certificates or another app to bypass this.

## Included

Twilight Blue and club themes; local theme/language persistence; remote navigation and Back handling; direct HTTPS video/audio URLs; local saved media, favorites and resume; in-player Fit/Fill/Stretch, pause/resume and seeking for finite videos; local capability diagnostics and explicit media errors.

## Not included

Phone pairing, system app launching, HDMI control, Xtream account/category imports, DRM playback, purchases or official store certification. These require additional platform work. The direct-media screen is not represented as a complete IPTV replacement.

No secrets or account URLs are sent to our server. A media request goes to the provider entered by the user. Media links are kept in localStorage on the television and can be removed in the media library. Do not use diagnostic export to share account links (diagnostics contain no saved media URLs).

## Build and verify

`python vidaa-app/build.py`

`node vidaa-app/ui-check.cjs`

Browser automation is not physical VIDAA certification. The current build requires an actual device installation/playback test.
