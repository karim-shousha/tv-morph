(function() {
  "use strict";
  var ids = ["account-server", "account-user", "account-password", "account-name"], target = null, origin = null, shift = false, alphabet = "en";
  function tr(a, b) {
    var l = window.MorphLocale ? MorphLocale.get() : "en";
    var words = { "Enter subscription details with your remote": ["Saisir avec la t\xE9l\xE9commande", "\u4F7F\u7528\u9065\u63A7\u5668\u8F93\u5165\u8BA2\u9605\u4FE1\u606F", "\u30EA\u30E2\u30B3\u30F3\u3067\u5951\u7D04\u60C5\u5831\u3092\u5165\u529B"], "Space": ["Espace", "\u7A7A\u683C", "\u7A7A\u767D"], "Clear": ["Effacer", "\u6E05\u7A7A", "\u30AF\u30EA\u30A2"], "Done": ["Termin\xE9", "\u5B8C\u6210", "\u5B8C\u4E86"], "Cancel": ["Annuler", "\u53D6\u6D88", "\u30AD\u30E3\u30F3\u30BB\u30EB"], "\u2328 Type with remote": ["\u2328 Saisir avec la t\xE9l\xE9commande", "\u2328 \u4F7F\u7528\u9065\u63A7\u5668\u8F93\u5165", "\u2328 \u30EA\u30E2\u30B3\u30F3\u3067\u5165\u529B"] };
    return l === "ar" ? a : words[b] && ["fr", "zh", "ja"].indexOf(l) >= 0 ? words[b][["fr", "zh", "ja"].indexOf(l)] : b;
  }
  var panel = document.createElement("div");
  panel.id = "account-keyboard";
  panel.hidden = true;
  panel.setAttribute("role", "dialog");
  panel.setAttribute("aria-modal", "true");
  panel.setAttribute("aria-label", "IPTV keyboard");
  panel.innerHTML = '<section><h2></h2><input id="account-keyboard-value" dir="ltr" autocomplete="off" spellcheck="false"><div class="account-keyboard-keys"></div><div class="account-keyboard-actions"></div></section>';
  document.body.appendChild(panel);
  var input = panel.querySelector("input"), grid = panel.querySelector(".account-keyboard-keys"), actions = panel.querySelector(".account-keyboard-actions");
  function button(text, fn, parent) {
    var b = document.createElement("button");
    b.type = "button";
    b.textContent = text;
    b.onclick = fn;
    parent.appendChild(b);
    return b;
  }
  function insert(value) {
    var a = input.selectionStart == null ? input.value.length : input.selectionStart, b = input.selectionEnd == null ? a : input.selectionEnd;
    input.value = input.value.slice(0, a) + value + input.value.slice(b);
    var next = a + value.length;
    input.setSelectionRange(next, next);
  }
  function close(save) {
    if (panel.hidden) return false;
    if (save && target) {
      target.value = input.value;
      target.dispatchEvent(new Event("input", { bubbles: true }));
      target.dispatchEvent(new Event("change", { bubbles: true }));
    }
    input.value = "";
    target = null;
    panel.hidden = true;
    var focus = origin;
    origin = null;
    if (focus && focus.isConnected) focus.focus();
    return true;
  }
  function paint() {
    grid.textContent = "";
    actions.textContent = "";
    var chars = alphabet === "ar" ? "\u0627\u0628\u062A\u062B\u062C\u062D\u062E\u062F\u0630\u0631\u0632\u0633\u0634\u0635\u0636\u0637\u0638\u0639\u063A\u0641\u0642\u0643\u0644\u0645\u0646\u0647\u0648\u064A\u0621\u0623\u0625\u0622\u0629\u0649\u0624\u0626" : "abcdefghijklmnopqrstuvwxyz";
    if (shift) chars = chars.toUpperCase();
    ("1234567890" + chars + Array.from({ length: 94 }, function(_, i) {
      return String.fromCharCode(i + 33);
    }).filter(function(c) {
      return !/[a-z0-9]/i.test(c);
    }).join("")).split("").forEach(function(char) {
      button(char, function() {
        insert(char);
      }, grid);
    });
    button(tr("\u0645\u0633\u0627\u0641\u0629", "Space"), function() {
      insert(" ");
    }, actions);
    button("\u232B", function() {
      var a = input.selectionStart == null ? input.value.length : input.selectionStart, b = input.selectionEnd == null ? a : input.selectionEnd;
      if (a === b && a > 0) a--;
      input.value = input.value.slice(0, a) + input.value.slice(b);
      input.setSelectionRange(a, a);
    }, actions);
    button("ABC / \u0627\u0644\u0639\u0631\u0628\u064A\u0629", function() {
      alphabet = alphabet === "ar" ? "en" : "ar";
      paint();
      actions.querySelector("button").focus();
    }, actions);
    button("\u21E7", function() {
      shift = !shift;
      paint();
      actions.querySelector("button").focus();
    }, actions);
    button(tr("\u0645\u0633\u062D \u0627\u0644\u0643\u0644", "Clear"), function() {
      input.value = "";
    }, actions);
    button(tr("\u062A\u0645", "Done"), function() {
      close(true);
    }, actions);
    button(tr("\u0625\u0644\u063A\u0627\u0621", "Cancel"), function() {
      close(false);
    }, actions);
  }
  function open(field, from) {
    target = field;
    origin = from || field;
    input.type = field.type === "password" ? "password" : "text";
    input.value = field.value;
    panel.querySelector("h2").textContent = tr("\u0627\u0643\u062A\u0628 \u0628\u064A\u0627\u0646\u0627\u062A \u0627\u0644\u0627\u0634\u062A\u0631\u0627\u0643 \u0628\u0627\u0644\u0631\u064A\u0645\u0648\u062A", "Enter subscription details with your remote");
    panel.setAttribute("aria-label", panel.querySelector("h2").textContent);
    input.setAttribute("aria-label", panel.querySelector("h2").textContent);
    paint();
    panel.hidden = false;
    grid.querySelector("button").focus();
  }
  ids.forEach(function(id) {
    var field = document.getElementById(id);
    if (!field) return;
    field.setAttribute("autocapitalize", "none");
    field.setAttribute("autocorrect", "off");
    field.setAttribute("spellcheck", "false");
    var b = document.createElement("button");
    b.type = "button";
    b.className = "account-keyboard-open";
    b.dataset.noTranslate = "";
    function label() {
      b.textContent = tr("\u2328 \u0643\u062A\u0627\u0628\u0629 \u0628\u0627\u0644\u0631\u064A\u0645\u0648\u062A", "\u2328 Type with remote");
    }
    label();
    window.addEventListener("morphLanguage", label);
    b.onclick = function() {
      open(field, b);
    };
    field.after(b);
    field.addEventListener("click", function() {
      if (window.IptvNative && typeof IptvNative.showKeyboard === "function") IptvNative.showKeyboard(id, "");
    });
    field.addEventListener("keydown", function(e) {
      if (e.keyCode !== 13) return;
      if (window.IptvNative && typeof IptvNative.showKeyboard === "function") {
        e.preventDefault();
        if (!e.repeat) IptvNative.showKeyboard(id, "");
      }
    });
  });
  document.addEventListener("keydown", function(e) {
    if (panel.hidden) return;
    var code = e.keyCode;
    if ([27, 10009, 461].indexOf(code) >= 0) {
      e.preventDefault();
      e.stopImmediatePropagation();
      close(false);
      return;
    }
    if (code === 13 && document.activeElement.tagName === "BUTTON") {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (!e.repeat) document.activeElement.click();
      return;
    }
    if (code < 37 || code > 40) return;
    if (document.activeElement === input) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    var current = document.activeElement, rect = current.getBoundingClientRect(), cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2, best = null, score = Infinity;
    Array.prototype.forEach.call(panel.querySelectorAll("button"), function(b) {
      if (b === current) return;
      var r = b.getBoundingClientRect(), dx = r.left + r.width / 2 - cx, dy = r.top + r.height / 2 - cy;
      if (code === 37 && dx >= -1 || code === 39 && dx <= 1 || code === 38 && dy >= -1 || code === 40 && dy <= 1) return;
      var cost = Math.abs(code === 37 || code === 39 ? dx : dy) + Math.abs(code === 37 || code === 39 ? dy : dx) * 3;
      if (cost < score) {
        score = cost;
        best = b;
      }
    });
    if (best) {
      best.focus();
      best.scrollIntoView({ block: "nearest" });
    }
  }, true);
  window.IptvAccountKeyboard = { back: function() {
    return close(false);
  }, isOpen: function() {
    return !panel.hidden;
  } };
})();
