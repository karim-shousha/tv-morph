(function(C) {
  "use strict";
  var P = window.MorphPlus;
  if (!P) return;
  function refresh() {
    document.querySelectorAll(".theme-option").forEach(function(b2) {
      var theme = Array.prototype.filter.call(b2.classList, function(c) {
        return c !== "theme-option" && c !== "plus-locked";
      })[0];
      b2.classList.toggle("plus-locked", !!theme && !P.allowed(theme));
    });
  }
  function fallback() {
    if (!P.allowed(C.settings.theme)) {
      C.write("plusSuspendedSettings", JSON.parse(JSON.stringify(C.settings)));
      C.applyRemoteConfig({ theme: "blue" });
    }
  }
  P.ready.then(function() {
    fallback();
    refresh();
  });
  window.addEventListener("morphViewer", function() {
    fallback();
    refresh();
  });
  window.addEventListener("morphPlus", function() {
    if (P.isActive()) {
      var saved = C.read("plusSuspendedSettings", null);
      if (saved) {
        C.applyRemoteConfig(saved);
        C.write("plusSuspendedSettings", null);
      }
    } else fallback();
    refresh();
  });
  var panel = document.getElementById("setting-theme").closest(".settings-panel"), b = C.el("button", "setting morph-plus-setting", "\u{1F513} Morph TV Plus \xB7 \u0634\u0631\u0627\u0621 \u0627\u0644\u062B\u064A\u0645\u0627\u062A / Buy themes \u2192");
  b.setAttribute("data-no-translate", "");
  function label() {
    b.textContent = "\u{1F513} " + MorphLocale.t("\u0645\u0648\u0631\u0641 \u062A\u064A \u0641\u064A \u0628\u0644\u0633 \xB7 \u0634\u0631\u0627\u0621 \u0627\u0644\u062B\u064A\u0645\u0627\u062A \u2192", "Morph TV Plus \xB7 Buy themes \u2192");
  }
  label();
  window.addEventListener("morphLanguage", label);
  b.onclick = P.open;
  if (panel) panel.insertBefore(b, panel.firstChild);
  document.addEventListener("click", function(e) {
    var target = e.target.closest && e.target.closest(".theme-option");
    if (target) refresh();
  }, true);
})(window.ClearTV);
