(function(w) {
  "use strict";
  var C = w.ClearTV = w.ClearTV || {};
  var S = null, UI = { screen: "home", params: {}, returnFocus: null, engine: null, activeProg: null, builderSel: [], builderFilter: { cat: "all", lvl: "all" }, progressRange: "week", lastSession: null };
  function t(k) {
    return C.FitnessI18n.t(k);
  }
  function L(o) {
    return C.FitnessI18n.lname(o);
  }
  function el(tag, cls, txt) {
    return C.el(tag, cls, txt);
  }
  function btn(txt, cls, fn, label) {
    var b = el("button", cls, txt);
    b.onclick = function() {
      try {
        C.FitnessAudio.beep.click();
      } catch (e) {
      }
      fn();
    };
    if (label) b.setAttribute("aria-label", label);
    return b;
  }
  function root() {
    return document.getElementById("view-fitness");
  }
  function setS(v) {
    S = v;
  }
  function fmt(s) {
    s = Math.max(0, Math.round(s));
    var m = Math.floor(s / 60), r = s % 60;
    return (m < 10 ? "0" : "") + m + ":" + (r < 10 ? "0" : "") + r;
  }
  function exIcon(e) {
    var m = { cardio: "\u2764\uFE0F", hiit: "\u{1F525}", core: "\u{1F9F1}", upper_body: "\u{1F4AA}", lower_body: "\u{1F9B5}", strength: "\u{1F3CB}\uFE0F", stretching: "\u{1F9D8}", mobility: "\u{1F30A}", low_impact: "\u{1FAB6}", warmup: "\u2600\uFE0F", recovery: "\u{1F319}", full_body: "\u26A1" };
    return m[e.cat] || "\u{1F3C3}";
  }
  function thumb(e) {
    var d = el("div", "fit-thumb");
    d.textContent = exIcon(e);
    var s = el("span", "lbl", "\u25C8 " + e.image);
    d.appendChild(s);
    d.setAttribute("aria-hidden", "true");
    return d;
  }
  function lvlName(n) {
    return C.FitnessI18n.lvl(n);
  }
  function show(screen, params) {
    if (UI.screen === "music" && screen !== "music") C.FitnessAudio.music.stopPreview();
    if (UI.screen === "active" && screen === "music") UI.activeWrap = root().firstChild;
    if (screen === "active" && UI.activeWrap) {
      root().textContent = "";
      root().appendChild(UI.activeWrap);
      UI.activeWrap = null;
      UI.screen = "active";
      UI.params = params || {};
      var pause = root().querySelector("[data-pause]");
      if (pause) C.Focus.focus(pause);
      return;
    }
    UI.screen = screen;
    UI.params = params || {};
    var r = root();
    r.textContent = "";
    var wrap = el("div", "fit-wrap");
    r.appendChild(wrap);
    ({ home: renderHome, programs: renderPrograms, builder: renderBuilder, active: renderActive, music: renderMusic, complete: renderComplete, progress: renderProgress, settings: renderSettings })[screen](wrap, UI.params);
    var f = wrap.querySelector("[data-autofocus]") || wrap.querySelector("button");
    if (f) C.Focus.focus(f);
    try {
      var v = document.getElementById("view-fitness");
      if (v) v.scrollTop = 0;
    } catch (e) {
    }
  }
  UI.show = show;
  function crumb(wrap, title, sub) {
    var row = el("div", "fit-chiprow");
    var items = [["home", t("sportsHome")], ["programs", t("programs")], ["builder", t("custom")], ["progress", t("progress")], ["settings", t("settings")]];
    items.forEach(function(it) {
      var b = btn(it[1], "fit-chip" + (UI.screen === it[0] ? " on" : ""), function() {
        show(it[0]);
      });
      row.appendChild(b);
    });
    wrap.appendChild(row);
    if (title) {
      var h = el("h1", "", "");
      h.textContent = title;
      h.style.cssText = "font-size:40px;margin:6px 0 2px";
      wrap.appendChild(h);
    }
    if (sub) {
      var p = el("p", "", sub);
      p.style.cssText = "font-size:19px;opacity:.75;margin:0 0 14px";
      wrap.appendChild(p);
    }
  }
  function renderHome(wrap) {
    crumb(wrap);
    var hero = el("div", "fit-hero");
    var main = el("div", "fit-hero-main");
    main.appendChild(el("div", "fit-eyebrow", t("sportsHome")));
    var h = el("h1", "");
    h.innerHTML = "";
    h.appendChild(document.createTextNode(t("workOut") + " "));
    var g = el("span", "grad", t("atHome"));
    h.appendChild(g);
    main.appendChild(h);
    main.appendChild(el("p", "", t("tagline")));
    var cta = el("div", "fit-hero-cta");
    cta.appendChild(btn("\u25B6 " + t("startTraining"), "fit-btn-primary", function() {
      quickStart();
    }, t("startTraining")));
    var b = btn(t("browse"), "fit-ctl", function() {
      show("programs");
    });
    b.setAttribute("data-autofocus", "1");
    main.appendChild(cta);
    cta.appendChild(b);
    hero.appendChild(main);
    var side = el("div", "fit-hero-side");
    var q = btn("", "fit-side-card", function() {
      quickStart();
    });
    q.appendChild(el("span", "ico", "\u26A1"));
    var qd = el("div", "");
    qd.appendChild(el("strong", "", t("quick")));
    qd.appendChild(el("small", "", "5\u201315 min"));
    q.appendChild(qd);
    var gd = btn("", "fit-side-card", function() {
      show("programs");
    });
    gd.appendChild(el("span", "ico", "\u{1F3AF}"));
    var g2 = el("div", "");
    g2.appendChild(el("strong", "", t("guided")));
    g2.appendChild(el("small", "", t("programs")));
    gd.appendChild(g2);
    var cu = btn("", "fit-side-card", function() {
      show("builder");
    });
    cu.appendChild(el("span", "ico", "\u{1F6E0}\uFE0F"));
    var c3 = el("div", "");
    c3.appendChild(el("strong", "", t("custom")));
    c3.appendChild(el("small", "", t("selectAll")));
    cu.appendChild(c3);
    side.appendChild(q);
    side.appendChild(gd);
    side.appendChild(cu);
    hero.appendChild(side);
    wrap.appendChild(hero);
    wrap.appendChild(el("h2", "fit-row-title", t("categories")));
    var rail = el("div", "fit-rail");
    rail.setAttribute("data-scroll", "horizontal");
    C.FitnessData.CATEGORIES.forEach(function(c) {
      var card = btn("", "fit-card", function() {
        show("programs", { cat: c.id });
      }, L(c.name));
      var th = el("div", "fit-thumb", c.icon === "bolt" ? "\u26A1" : c.icon === "heart" ? "\u2764\uFE0F" : c.icon === "flame" ? "\u{1F525}" : c.icon === "leaf" ? "\u{1F9D8}" : c.icon === "moon" ? "\u{1F319}" : c.icon === "sun" ? "\u2600\uFE0F" : "\u{1F3C3}");
      var lb = el("span", "lbl", "\u25C8 fitness/categories/" + c.id);
      th.appendChild(lb);
      card.appendChild(th);
      card.appendChild(el("h3", "", L(c.name)));
      var n = C.FitnessData.PROGRAMS.filter(function(p) {
        return p.cat === c.id;
      }).length;
      card.appendChild(el("p", "", n ? n + " " + t("programs") : t("all")));
      rail.appendChild(card);
    });
    wrap.appendChild(rail);
    wrap.appendChild(el("h2", "fit-row-title", t("guided")));
    var rail2 = el("div", "fit-rail");
    rail2.setAttribute("data-scroll", "horizontal");
    featured().forEach(function(p) {
      rail2.appendChild(progCard(p));
    });
    wrap.appendChild(rail2);
  }
  function featured() {
    var ids = ["full_body_starter", "quick_energy", "fat_burn", "deep_stretch"];
    return ids.map(function(id) {
      return C.FitnessData.programById(id);
    }).filter(Boolean);
  }
  function progCard(p) {
    var card = btn("", "fit-card", function() {
      show("programs", { cat: p.cat, sel: p.id });
    }, L(p.name));
    var th = el("div", "fit-thumb", "\u{1F3CB}\uFE0F");
    var lb = el("span", "lbl", "\u25C8 " + p.image);
    th.appendChild(lb);
    card.appendChild(th);
    card.appendChild(el("h3", "", L(p.name)));
    card.appendChild(el("p", "", "~" + p.targetMins + " min \xB7 " + lvlName(p.level)));
    return card;
  }
  function quickStart() {
    var p = C.FitnessData.programById("quick_energy");
    startProgram(p);
  }
  function renderPrograms(wrap, params) {
    crumb(wrap, t("programs"));
    var cats = [{ id: "all", name: { en: "All", ar: "\u0627\u0644\u0643\u0644", fr: "Tout", zh: "\u5168\u90E8", ja: "\u5168\u90E8" } }].concat(C.FitnessData.CATEGORIES);
    var row = el("div", "fit-chiprow");
    var cur = params.cat || "all";
    cats.forEach(function(c) {
      row.appendChild(btn(L(c.name), "fit-chip" + (cur === c.id ? " on" : ""), function() {
        show("programs", { cat: c.id });
      }));
    });
    wrap.appendChild(row);
    var list = C.FitnessData.PROGRAMS.filter(function(p) {
      if (cur !== "all" && p.cat !== cur) return false;
      if (S.difficulty !== "all") {
        var want = S.difficulty === "beginner" ? 1 : S.difficulty === "intermediate" ? 2 : 3;
        if (p.level !== want) return false;
      }
      return true;
    });
    var cols = el("div", "fit-grid");
    cols.setAttribute("data-scroll", "vertical");
    list.forEach(function(p) {
      cols.appendChild(progCard(p));
    });
    wrap.appendChild(cols);
    var sel = params.sel ? C.FitnessData.programById(params.sel) : list[0];
    if (sel) detailPanel(wrap, sel);
  }
  function detailPanel(wrap, p) {
    var ex = p.exercises.map(function(id) {
      return C.FitnessData.byId(id);
    }).filter(Boolean);
    var panel = el("div", "fit-panel");
    panel.appendChild(el("h2", "", L(p.name)));
    var sub = el("p", "", (C.FitnessData.desc ? "" : "") + L(p.desc) + " \xB7 ~" + p.targetMins + " min \xB7 " + ex.length + " " + t("exercises") + " \xB7 " + p.rounds + " " + t("rounds") + " \xB7 " + lvlName(p.level));
    sub.style.opacity = ".8";
    panel.appendChild(sub);
    var seq = el("p", "fit-toast-note", ex.map(function(e) {
      return L(e.name);
    }).join("  \u2192  "));
    panel.appendChild(seq);
    var row = el("div", "fit-ctls");
    row.style.justifyContent = "flex-start";
    var st = btn("\u25B6 " + t("start"), "fit-ctl main", function() {
      startProgram(p);
    });
    st.setAttribute("data-autofocus", "1");
    row.appendChild(st);
    row.appendChild(btn(t("music"), "fit-ctl", function() {
      UI.returnTo = { s: "programs", p: { cat: p.cat, sel: p.id } };
      show("music");
    }));
    panel.appendChild(row);
    wrap.appendChild(panel);
  }
  function renderBuilder(wrap) {
    crumb(wrap, t("create"), t("selectAll"));
    var s = C.FitnessStore;
    var customs = s.custom();
    if (customs.length) {
      var r = el("div", "fit-chiprow");
      customs.forEach(function(c4) {
        var bb = btn("\u{1F4C1} " + c4.name, "fit-chip", function() {
          startCustom(c4);
        });
        r.appendChild(bb);
        var del = btn("\u2715", "fit-chip", function() {
          if (!confirm(t("confirmClear") + " (" + c4.name + ")")) return;
          s.saveCustom(s.custom().filter(function(x) {
            return x.id !== c4.id;
          }));
          show("builder");
        }, t("deleteIt"));
        r.appendChild(del);
      });
      wrap.appendChild(r);
    }
    var cats = [{ id: "all", name: { en: "All", ar: "\u0627\u0644\u0643\u0644", fr: "Tout", zh: "\u5168\u90E8", ja: "\u5168\u90E8" } }].concat(C.FitnessData.CATEGORIES);
    var row = el("div", "fit-chiprow");
    cats.forEach(function(c) {
      row.appendChild(btn(L(c.name), "fit-chip" + (UI.builderFilter.cat === c.id ? " on" : ""), function() {
        UI.builderFilter.cat = c.id;
        show("builder");
      }));
    });
    wrap.appendChild(row);
    var grid = el("div", "fit-grid");
    grid.setAttribute("data-scroll", "vertical");
    C.FitnessData.EXERCISES.filter(function(e) {
      if (UI.builderFilter.cat !== "all" && e.cat !== UI.builderFilter.cat) return false;
      if (UI.builderFilter.lvl !== "all" && String(e.level) !== String(UI.builderFilter.lvl)) return false;
      return true;
    }).forEach(function(e) {
      var on = UI.builderSel.indexOf(e.id) >= 0;
      var card = btn("", "fit-ex" + (on ? " sel" : ""), function() {
        var i = UI.builderSel.indexOf(e.id);
        if (i >= 0) UI.builderSel.splice(i, 1);
        else UI.builderSel.push(e.id);
        show("builder");
      }, L(e.name));
      if (on) {
        var ck = el("span", "fit-check", "\u2713");
        card.appendChild(ck);
      }
      card.appendChild(thumb(e));
      card.appendChild(el("h3", "", L(e.name)));
      card.appendChild(el("p", "", e.secs + "s \xB7 " + lvlName(e.level)));
      grid.appendChild(card);
    });
    wrap.appendChild(grid);
    var secs = UI.builderSel.reduce(function(a, id) {
      var e = C.FitnessData.byId(id);
      return a + (e ? e.secs + e.rest : 0);
    }, 0);
    var bar = el("div", "fit-panel");
    bar.appendChild(el("strong", "", UI.builderSel.length + " " + t("exercises") + " \xB7 ~" + Math.round(secs / 60) + " min"));
    var ctl = el("div", "fit-ctls");
    ctl.style.justifyContent = "flex-start";
    ctl.appendChild(btn("\u25B6 " + t("start"), "fit-ctl main", function() {
      if (!UI.builderSel.length) {
        C.toast(t("empty"));
        return;
      }
      startCustom({ id: "tmp", name: t("custom"), exercises: UI.builderSel.slice(), rounds: 1, rest: S.restSecs });
    }));
    ctl.appendChild(btn("\u{1F4BE} " + t("saveWorkout"), "fit-ctl", function() {
      if (!UI.builderSel.length) return;
      var name = prompt(t("workoutName"), t("custom") + " " + (s.custom().length + 1)) || t("custom") + " " + (s.custom().length + 1);
      var list = s.custom();
      list.push({ id: "c" + Date.now(), name: String(name).slice(0, 40), exercises: UI.builderSel.slice(), rounds: 1, rest: S.restSecs });
      s.saveCustom(list);
      C.toast(t("saved"));
    }));
    bar.appendChild(ctl);
    wrap.appendChild(bar);
  }
  function startCustom(c4) {
    startProgram({ id: c4.id || "custom", level: 2, targetMins: Math.round(c4.exercises.length * 1), cat: "full_body", rounds: c4.rounds || 1, exercises: c4.exercises, rest: c4.rest || S.restSecs, name: { en: c4.name, ar: c4.name, fr: c4.name, zh: c4.name, ja: c4.name }, desc: { en: "", ar: "", fr: "", zh: "", ja: "" }, image: "fitness/programs/custom", custom: true });
  }
  function startProgram(p) {
    if (running()) {
      if (!confirm(t("confirmExit"))) return;
      UI.engine.abort();
      if (UI.activeProg) saveIncomplete(UI.activeProg, UI.engine);
      UI.activeWrap = null;
    }
    UI.activeProg = p;
    var prep = S.countdown === false ? 0 : 5e3;
    show("active", {});
    bootActive(p, prep);
    C.FitnessAudio.music.start("workout");
  }
  function bootActive(p, prepMs) {
    var wrap = root().querySelector(".fit-wrap");
    if (!wrap) return;
    var eng = new C.FitnessEngine();
    eng.configure({ prepMs, restMs: (p.rest || S.restSecs) * 1e3 });
    UI.engine = eng;
    var phaseEl = wrap.querySelector("[data-phase]"), numEl = wrap.querySelector("[data-num]"), subEl = wrap.querySelector("[data-sub]"), ring = wrap.querySelector("[data-ring]"), exEl = wrap.querySelector("[data-ex]"), nextEl = wrap.querySelector("[data-next]"), progEl = wrap.querySelector("[data-prog]"), roundEl = wrap.querySelector("[data-round]"), pauseB = wrap.querySelector("[data-pause]");
    function lang2() {
      var l = C.FitnessI18n.lang();
      return l === "ar" ? "ar-EG" : l === "fr" ? "fr-FR" : l === "zh" ? "zh-CN" : l === "ja" ? "ja-JP" : "en-US";
    }
    function say(msg) {
      C.FitnessAudio.speak(msg, lang2());
    }
    function draw(rem, tot) {
      var f = tot > 0 ? Math.max(0, rem / tot) : 0;
      if (ring) ring.style.strokeDashoffset = String(628 * (1 - f));
      if (numEl) numEl.textContent = fmt(Math.ceil(rem / 1e3));
    }
    eng.on("prepare", function() {
      if (phaseEl) phaseEl.textContent = t("getReady");
      say(t("getReady"));
    });
    eng.on("prepareTick", function(d) {
      var s = Math.ceil(d.remainingMs / 1e3);
      if (exEl) exEl.innerHTML = '<div class="fit-count">' + (s > 0 ? s : t("go")) + "</div>";
      draw(d.remainingMs, eng.totalMs);
      var last = eng._lastCount || 99;
      if (s !== last && s <= 5 && s > 0) {
        eng._lastCount = s;
        C.FitnessAudio.beep.count(s);
        say(String(s));
      }
    });
    eng.on("go", function() {
      C.FitnessAudio.beep.go();
      say(t("go"));
    });
    eng.on("exercise", function(d) {
      if (phaseEl) phaseEl.textContent = L(d.ex.name);
      if (subEl) subEl.textContent = d.ex.cueEn ? C.FitnessI18n.lang() === "ar" ? d.ex.cueAr : d.ex.cueEn : "";
      if (exEl) {
        exEl.textContent = "";
        exEl.appendChild(thumb(d.ex));
        var h = el("h2", "", L(d.ex.name));
        exEl.appendChild(h);
        exEl.appendChild(el("p", "", (d.ex.muscles || []).join(" \xB7 ")));
      }
      if (nextEl) {
        var nx = eng.queue[d.index + 1];
        nextEl.textContent = t("nextUp") + ": " + (nx ? L(nx.ex.name) : "\u2014");
      }
      if (progEl) progEl.textContent = d.index + 1 + "/" + d.total;
      if (roundEl) roundEl.textContent = t("round") + " " + d.round + " " + t("of") + " " + d.rounds;
      say(L(d.ex.name));
      if (pauseB) pauseB.textContent = "\u23F8 " + t("pause");
      draw(d.secs * 1e3, d.secs * 1e3);
    });
    eng.on("tick", function(d) {
      draw(d.remainingMs, eng.totalMs);
      if (subEl && progEl) {
        var done = eng.queue.slice(0, d.index).length;
        progEl.textContent = d.index + 1 + "/" + eng.queue.length;
      }
    });
    eng.on("tickLow", function(d) {
      C.FitnessAudio.beep.count(d.s);
    });
    eng.on("rest", function(d) {
      if (phaseEl) phaseEl.textContent = "\u2615 " + t("rest");
      C.FitnessAudio.beep.rest();
      say(t("rest"));
      if (exEl) exEl.innerHTML = '<div class="fit-count">\u2615</div>';
      if (nextEl && d.next) nextEl.textContent = t("nextUp") + ": " + L(d.next.name);
    });
    eng.on("restTick", function(d) {
      draw(d.remainingMs, eng.totalMs);
    });
    eng.on("pause", function() {
      C.FitnessAudio.music.pause();
      if (pauseB) pauseB.textContent = "\u25B6 " + t("resume");
    });
    eng.on("resume", function() {
      C.FitnessAudio.music.start("workout");
      if (pauseB) pauseB.textContent = "\u23F8 " + t("pause");
    });
    eng.on("complete", function(d) {
      finishSession(p, eng, d);
    });
    eng.on("abort", function() {
      C.FitnessAudio.music.stop();
    });
    eng.start(p, { countdown: S.countdown !== false });
    wrap.querySelectorAll("[data-act]").forEach(function(b) {
      b.onclick = function() {
        var a = b.getAttribute("data-act");
        if (a === "pause") eng.toggle();
        if (a === "next") eng.next();
        if (a === "prev") eng.prev();
        if (a === "music") {
          UI.returnTo = { s: "active" };
          pauseKeep(eng);
          show("music");
        }
        if (a === "mute") {
          var st = C.FitnessStore.settings();
          st.musicEnabled = !st.musicEnabled;
          C.FitnessStore.saveSettings(st);
          C.FitnessAudio.music.sync(!eng.paused);
          b.textContent = st.musicEnabled ? "\u{1F50A}" : "\u{1F507}";
          C.toast(st.musicEnabled ? t("unmuted") : t("muted"));
        }
        if (a === "exit") {
          if (confirm(t("confirmExit"))) {
            eng.abort();
            saveIncomplete(p, eng);
            show("home");
          }
        }
      };
    });
  }
  function pauseKeep(eng) {
    try {
      if (eng && !eng.paused && eng.phase !== "done") eng.pause();
    } catch (e) {
    }
  }
  function renderActive(wrap) {
    var p = UI.activeProg;
    wrap.appendChild(el("h1", "", L(p.name) + "  \xB7  " + t("sportsHome")));
    var cols = el("div", "fit-cols");
    var left = el("div", "fit-panel");
    left.appendChild(el("div", "", ""));
    left.firstChild.setAttribute("data-phase", "1");
    left.firstChild.style.cssText = "font-size:22px;color:var(--cinema-glow)";
    var exd = el("div", "");
    exd.setAttribute("data-ex", "1");
    left.appendChild(exd);
    left.appendChild(el("p", "", ""));
    left.lastChild.setAttribute("data-sub", "1");
    left.lastChild.style.opacity = ".8";
    var nx = el("p", "fit-toast-note", "");
    nx.setAttribute("data-next", "1");
    left.appendChild(nx);
    var right = el("div", "fit-panel");
    var ringW = el("div", "fit-timer-ring");
    ringW.innerHTML = '<svg viewBox="0 0 220 220"><circle cx="110" cy="110" r="100" fill="none" stroke="#ffffff22" stroke-width="12"/><circle data-ring="1" cx="110" cy="110" r="100" fill="none" stroke="url(#x)" stroke-width="12" stroke-linecap="round" stroke-dasharray="628" stroke-dashoffset="0"/></svg>';
    var num = el("div", "fit-timer-num");
    num.innerHTML = '<strong data-num="1">00:00</strong><span data-prog="1"></span><span data-round="1"></span>';
    ringW.appendChild(num);
    right.appendChild(ringW);
    var ctl = el("div", "fit-ctls");
    [["prev", "\u23EE " + t("prev")], ["pause", "\u23F8 " + t("pause")], ["next", t("next") + " \u23ED"], ["music", "\u{1F3B5}"], ["mute", "\u{1F50A}"], ["exit", "\u2715 " + t("exit")]].forEach(function(x, i) {
      var b = el("button", "fit-ctl" + (i === 1 ? " main" : ""), x[1]);
      b.setAttribute("data-act", x[0]);
      if (i === 1) b.setAttribute("data-pause", "1");
      ctl.appendChild(b);
    });
    right.appendChild(ctl);
    cols.appendChild(left);
    cols.appendChild(right);
    wrap.appendChild(cols);
  }
  function finishSession(p, eng, d) {
    C.FitnessAudio.music.stop();
    C.FitnessAudio.beep.done();
    var activeSecs = Math.round(eng.stats.activeMs / 1e3) || p.exercises.length * 30;
    var wgt = 0;
    try {
      wgt = Number(C.FitnessStore.settings().weightKg) || 0;
    } catch (e) {
    }
    var cal = C.FitnessCalories(d.avgMet || 6, activeSecs, wgt);
    var sess = {
      id: "s" + Date.now(),
      programId: p.id,
      programName: L(p.name),
      completedAt: Date.now(),
      activeSecs,
      exercisesDone: eng.stats.completedCount,
      exercisesTotal: eng.queue.length,
      rounds: eng.rounds || p.rounds || 1,
      kcal: Math.round(cal.kcal),
      assumedKg: cal.assumed ? 70 : 0,
      skipped: eng.stats.skipped || 0
    };
    C.FitnessStore.addSession(sess);
    try {
      C.FitnessAudio.speak(t("greatJob"), C.FitnessI18n.lang());
    } catch (e) {
    }
    UI.lastSession = sess;
    show("complete", {});
  }
  function saveIncomplete(p, eng) {
    try {
      C.FitnessStore.addSession({ id: "s" + Date.now(), programId: p.id, programName: L(p.name), completedAt: Date.now(), activeSecs: Math.round(eng.stats.activeMs / 1e3), exercisesDone: eng.stats.completedCount, exercisesTotal: eng.queue.length, rounds: eng.round || 1, kcal: 0, incomplete: true, skipped: eng.stats.skipped || 0 });
    } catch (e) {
    }
  }
  function renderComplete(wrap) {
    var s = UI.lastSession || { programName: "", activeSecs: 0, exercisesDone: 0, exercisesTotal: 0, rounds: 1, kcal: 0 };
    wrap.appendChild(el("div", "fit-count", "\u{1F3C6}"));
    var h = el("h1", "", t("greatJob"));
    h.style.textAlign = "center";
    wrap.appendChild(h);
    var p = el("p", "", t("completedMsg") + ": " + (s.programName || ""));
    p.style.textAlign = "center";
    wrap.appendChild(p);
    var k = el("div", "fit-kpi");
    [[fmt(s.activeSecs), t("totalTime")], [s.exercisesDone + "/" + s.exercisesTotal, t("exercises")], [s.kcal + "", t("calories") + " " + t("est")], [s.rounds + "", t("rounds")]].forEach(function(x) {
      var d = el("div", "");
      d.appendChild(el("strong", "", String(x[0])));
      d.appendChild(el("span", "", x[1]));
      k.appendChild(d);
    });
    wrap.appendChild(k);
    if (s.assumedKg) {
      var n = el("p", "fit-toast-note", "\u26A0\uFE0F " + t("assumed"));
      n.style.textAlign = "center";
      wrap.appendChild(n);
    }
    var ctl = el("div", "fit-ctls");
    ctl.appendChild(btn(t("playAgain"), "fit-ctl main", function() {
      if (UI.activeProg) startProgram(UI.activeProg);
      else show("home");
    }));
    ctl.appendChild(btn(t("chooseAnother"), "fit-ctl", function() {
      show("programs");
    }));
    ctl.appendChild(btn(t("viewProgress"), "fit-ctl", function() {
      show("progress");
    }));
    ctl.appendChild(btn(t("home"), "fit-ctl", function() {
      C.showView("home");
    }));
    wrap.appendChild(ctl);
  }
  function renderMusic(wrap) {
    crumb(wrap, t("music"));
    var st = C.FitnessStore.settings();
    var panel = el("div", "fit-panel");
    C.FitnessAudio.PACKS.forEach(function(pk) {
      var row = el("div", "fit-setrow");
      var nm = C.FitnessAudio.packTitle(pk.id, C.FitnessI18n.lang()) + (pk.status === "unavailable" ? " \xB7 \u26A0\uFE0F" : pk.status === "built-in" ? " \xB7 \u2713" : "");
      var b = btn((st.musicPack === pk.id ? "\u25C9 " : "\u25CB ") + nm, "fit-ctl", function() {
        if (pk.status === "unavailable") {
          C.toast(t("unavailable"));
          return;
        }
        C.FitnessAudio.music.select(pk.id);
        show("music");
        var selected = root().querySelector('[data-music-pack="' + pk.id + '"]');
        if (selected) C.Focus.focus(selected);
      });
      b.setAttribute("data-music-pack", pk.id);
      b.style.minWidth = "320px";
      b.style.textAlign = "start";
      row.appendChild(b);
      if (pk.status !== "off") {
        var listen = btn(t("listen"), "fit-ctl", function() {
          C.FitnessAudio.music.preview(pk.id);
        });
        listen.setAttribute("data-music-preview", pk.id);
        row.appendChild(listen);
      }
      panel.appendChild(row);
    });
    panel.appendChild(el("p", "fit-toast-note", t("musicOnline")));
    var status = el("p", "fit-toast-note", C.FitnessAudio.music.statusText());
    status.setAttribute("data-fit-music-status", "");
    status.setAttribute("role", "status");
    panel.appendChild(status);
    var ctl = el("div", "fit-ctls");
    ctl.style.justifyContent = "flex-start";
    ctl.appendChild(btn(t("back"), "fit-ctl main", function() {
      if (UI.returnTo && UI.returnTo.s === "active" && UI.engine && UI.activeProg) {
        show("active", {});
        bootActiveResume();
      } else if (UI.returnTo && UI.returnTo.s) show(UI.returnTo.s, UI.returnTo.p || {});
      else show("home");
    }));
    panel.appendChild(ctl);
    wrap.appendChild(panel);
  }
  function bootActiveResume() {
    var eng = UI.engine;
    if (!eng) {
      show("home");
      return;
    }
    if (eng.paused) {
    }
    var wrap = root().querySelector(".fit-wrap");
    if (!wrap) return;
    wrap.querySelectorAll("[data-act]").forEach(function(b) {
      b.onclick = function() {
        var a = b.getAttribute("data-act");
        if (a === "pause") eng.toggle();
        if (a === "next") eng.next();
        if (a === "prev") eng.prev();
        if (a === "music") {
          UI.returnTo = { s: "active" };
          try {
            eng.pause();
          } catch (e) {
          }
          show("music");
        }
        if (a === "mute") {
          var s2 = C.FitnessStore.settings();
          s2.musicEnabled = !s2.musicEnabled;
          C.FitnessStore.saveSettings(s2);
          C.FitnessAudio.music.sync(!eng.paused);
        }
        if (a === "exit") {
          if (confirm(t("confirmExit"))) {
            eng.abort();
            show("home");
          }
        }
      };
    });
    try {
      var snap = eng.snapshot();
      var numEl = wrap.querySelector("[data-num]");
      if (numEl) numEl.textContent = fmt(Math.ceil(snap.remainingMs / 1e3));
      var idx = eng.queue[eng.index];
      var exEl = wrap.querySelector("[data-ex]");
      if (exEl && idx) {
        exEl.textContent = "";
        exEl.appendChild(thumb(idx.ex));
        exEl.appendChild(el("h2", "", L(idx.ex.name)));
      }
      eng.on("tick", function(d) {
        var n = wrap.querySelector("[data-num]");
        if (n) n.textContent = fmt(Math.ceil(d.remainingMs / 1e3));
        var r = wrap.querySelector("[data-ring]");
        if (r && eng.totalMs) r.style.strokeDashoffset = String(628 * (1 - Math.max(0, d.remainingMs) / eng.totalMs));
      });
      eng.on("restTick", function(d) {
        var n = wrap.querySelector("[data-num]");
        if (n) n.textContent = fmt(Math.ceil(d.remainingMs / 1e3));
      });
      eng.on("prepareTick", function(d) {
        var n = wrap.querySelector("[data-num]");
        if (n) n.textContent = fmt(Math.ceil(d.remainingMs / 1e3));
      });
    } catch (e) {
    }
  }
  function renderProgress(wrap) {
    crumb(wrap, t("myProgress"), t("progressSub"));
    var row = el("div", "fit-chiprow");
    [["week", t("thisWeek")], ["month", t("thisMonth")], ["all", t("allTime")]].forEach(function(x) {
      row.appendChild(btn(x[1], "fit-chip" + (UI.progressRange === x[0] ? " on" : ""), function() {
        UI.progressRange = x[0];
        show("progress");
      }));
    });
    wrap.appendChild(row);
    var st = C.FitnessStore.stats(UI.progressRange === "all" ? null : UI.progressRange);
    var k = el("div", "fit-kpi");
    [[st.workouts, t("workouts")], [st.minutes, t("minutes")], [st.kcal, t("calories")], [C.FitnessStore.streak(), t("streak")]].forEach(function(x) {
      var d = el("div", "");
      d.appendChild(el("strong", "", String(x[0])));
      d.appendChild(el("span", "", x[1]));
      k.appendChild(d);
    });
    wrap.appendChild(k);
    var panel = el("div", "fit-panel");
    panel.appendChild(el("h2", "", t("weekly")));
    var bars = el("div", "fit-bars");
    var names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
    var max = 1;
    for (var i = 0; i < 7; i++) max = Math.max(max, st.days[(i + 1) % 7] || 0);
    for (var j = 0; j < 7; j++) {
      var v = st.days[(j + 1) % 7] || 0;
      var bcol = el("div", "");
      bcol.style.height = Math.round(v / max * 130 + 8) + "px";
      bcol.title = names[j] + ": " + v;
      bars.appendChild(bcol);
    }
    panel.appendChild(bars);
    wrap.appendChild(panel);
    var hist = C.FitnessStore.history().slice(0, 8);
    if (!hist.length) {
      var emp = el("div", "fit-panel");
      emp.appendChild(el("p", "", t("empty")));
      emp.appendChild(btn(t("startFirst"), "fit-ctl main", function() {
        quickStart();
      }));
      wrap.appendChild(emp);
    } else {
      wrap.appendChild(el("h2", "fit-row-title", t("recent")));
      hist.forEach(function(h) {
        var r2 = el("div", "fit-setrow");
        r2.appendChild(el("span", "", (h.incomplete ? "\u25CB " : "\u2713 ") + (h.programName || "") + " \xB7 " + fmt(h.activeSecs || 0) + " \xB7 " + new Date(h.completedAt).toLocaleDateString()));
        wrap.appendChild(r2);
      });
      wrap.appendChild(btn(t("clearHistory"), "fit-ctl", function() {
        if (!confirm(t("confirmClear"))) return;
        C.FitnessStore.clearHistory();
        show("progress");
      }));
    }
  }
  function renderSettings(wrap) {
    crumb(wrap, t("settings"));
    setS(C.FitnessStore.settings());
    var panel = el("div", "fit-panel");
    function togRow(label, key) {
      var r = el("div", "fit-setrow");
      r.appendChild(el("span", "lab", label));
      var b = btn(S[key] ? "\u25CF " + t("on") : "\u25CB " + t("off"), "fit-ctl", function() {
        S[key] = !S[key];
        C.FitnessStore.saveSettings(S);
        C.FitnessAudio.music.sync(false);
        show("settings");
      });
      r.appendChild(b);
      panel.appendChild(r);
    }
    togRow(t("musicEnabled"), "musicEnabled");
    togRow(t("voice"), "voice");
    togRow(t("beeps"), "beeps");
    togRow(t("starting"), "countdown");
    togRow(t("autoNext"), "autoNext");
    var rr = el("div", "fit-setrow");
    rr.appendChild(el("span", "lab", t("restSecs") + ": " + S.restSecs + "s"));
    [[-5, "\u22125"], [5, "+5"]].forEach(function(x) {
      rr.appendChild(btn(x[1], "fit-ctl", function() {
        S.restSecs = Math.max(5, Math.min(120, S.restSecs + x[0]));
        C.FitnessStore.saveSettings(S);
        C.FitnessAudio.music.sync(false);
        show("settings");
      }));
    });
    panel.appendChild(rr);
    var vr = el("div", "fit-setrow");
    vr.appendChild(el("span", "lab", t("musicVolume") + ": " + S.musicVolume));
    [[-10, "\u2212"], [10, "+"]].forEach(function(x) {
      vr.appendChild(btn(x[1], "fit-ctl", function() {
        S.musicVolume = Math.max(0, Math.min(100, S.musicVolume + x[0]));
        C.FitnessStore.saveSettings(S);
        C.FitnessAudio.music.sync(false);
        show("settings");
      }));
    });
    panel.appendChild(vr);
    var dr = el("div", "fit-setrow");
    dr.appendChild(el("span", "lab", t("difficulty")));
    [["all", t("all")], ["beginner", t("beginner")], ["intermediate", t("intermediate")], ["advanced", t("advanced")]].forEach(function(x) {
      dr.appendChild(btn(x[1], "fit-chip" + (S.difficulty === x[0] ? " on" : ""), function() {
        S.difficulty = x[0];
        C.FitnessStore.saveSettings(S);
        C.FitnessAudio.music.sync(false);
        show("settings");
      }));
    });
    panel.appendChild(dr);
    var wr = el("div", "fit-setrow");
    wr.appendChild(el("span", "lab", t("weight") + ": " + (S.weightKg || "\u2014")));
    [[-5, "\u22125"], [5, "+5"]].forEach(function(x) {
      wr.appendChild(btn(x[1], "fit-ctl", function() {
        S.weightKg = Math.max(0, Math.min(250, (Number(S.weightKg) || 0) + x[0]));
        C.FitnessStore.saveSettings(S);
        C.FitnessAudio.music.sync(false);
        show("settings");
      }));
    });
    panel.appendChild(wr);
    panel.appendChild(el("p", "fit-toast-note", t("safety")));
    var cp = el("div", "fit-setrow");
    var mail = el("a", "", "support@herroshetta.com");
    mail.href = "mailto:support@herroshetta.com";
    mail.dir = "ltr";
    mail.style.cssText = "font-size:20px;font-weight:bold";
    cp.appendChild(el("span", "lab", t("contactUs") + ": "));
    cp.appendChild(mail);
    panel.appendChild(cp);
    panel.appendChild(el("p", "fit-toast-note", t("contactMsg")));
    wrap.appendChild(panel);
  }
  function running() {
    return UI.engine && UI.engine.phase !== "done" && UI.engine.state !== "IDLE";
  }
  UI.leave = function() {
    if (running()) {
      if (!confirm(t("confirmExit"))) return false;
      UI.engine.abort();
      if (UI.activeProg) saveIncomplete(UI.activeProg, UI.engine);
    }
    C.FitnessAudio.music.stop();
    UI.engine = null;
    UI.activeWrap = null;
    try {
      if (w.speechSynthesis) w.speechSynthesis.cancel();
    } catch (e) {
    }
    return true;
  };
  UI.open = function(source) {
    UI.returnFocus = source && source.id === "home-fitness" ? source : document.getElementById("home-fitness");
    root().style.height = Math.max(300, Math.min(850, document.querySelector("main").clientHeight - root().offsetTop - 60)) + "px";
    show("home");
  };
  UI.back = function() {
    if (UI.screen === "music" && UI.activeWrap) {
      show("active");
      bootActiveResume();
      return;
    }
    if (running()) {
      var target = UI.returnFocus;
      C.showView("home");
      if (root().hidden && target) C.Focus.focus(target);
      return;
    }
    if (UI.screen !== "home") {
      show("home");
      return;
    }
    var target = UI.returnFocus;
    C.showView("home");
    if (target) C.Focus.focus(target);
  };
  function mount() {
    setS(C.FitnessStore.settings());
    if (!root()) {
      var sec = document.createElement("section");
      sec.className = "view";
      sec.id = "view-fitness";
      sec.hidden = true;
      sec.setAttribute("data-scroll", "vertical");
      sec.setAttribute("data-no-translate", "");
      var main = document.querySelector("main"), footer = main.querySelector("footer");
      main.insertBefore(sec, footer && footer.parentNode === main ? footer : null);
    }
    var nav = document.getElementById("nav-fitness");
    if (!nav) {
      nav = C.el("button", "nav");
      nav.id = "nav-fitness";
      nav.setAttribute("data-view", "fitness");
      document.querySelector("header nav").appendChild(nav);
    }
    nav.setAttribute("data-no-translate", "");
    nav.onclick = function() {
      C.showView("fitness", nav);
    };
    var sidebar = document.getElementById("home-fitness");
    if (!sidebar) {
      sidebar = C.el("button", "tool");
      sidebar.id = "home-fitness";
      sidebar.setAttribute("data-no-translate", "");
      var tools = document.querySelector("#view-home .home-tools");
      tools.insertBefore(sidebar, tools.firstChild);
    }
    sidebar.onclick = function() {
      C.showView("fitness", sidebar);
    };
    function labels() {
      nav.textContent = t("fitness");
      sidebar.textContent = t("fitness");
      sidebar.setAttribute("aria-label", t("fitness"));
      root().setAttribute("aria-label", t("sportsHome"));
    }
    labels();
    w.addEventListener("morphLanguage", function() {
      labels();
      if (!root().hidden && UI.screen !== "active") show(UI.screen, UI.params);
    });
    w.addEventListener("morphAudioExclusive", function() {
      if (running()) pauseKeep(UI.engine);
    });
    document.addEventListener("visibilitychange", function() {
      if (document.hidden) {
        C.FitnessAudio.music.pause();
        if (running()) pauseKeep(UI.engine);
      }
    });
  }
  w.addEventListener("morphFitnessMusic", function() {
    var label = document.querySelector("[data-fit-music-status]");
    if (label) label.textContent = C.FitnessAudio.music.statusText();
    var snap = C.FitnessAudio.music.snapshot();
    document.querySelectorAll("[data-music-preview]").forEach(function(b) {
      var playing = snap.mode === "preview" && snap.track === b.getAttribute("data-music-preview") && !snap.paused;
      b.textContent = t(playing ? "stopPreview" : "listen");
      b.setAttribute("aria-pressed", String(playing));
    });
  });
  C.FitnessUI = UI;
  w.addEventListener("load", mount);
  w.addEventListener("morphViewer", function() {
    setS(C.FitnessStore.settings());
  });
})(window);
