Morph TV 0.8.151 / EXPERIMENTAL Tizen 4 computer project for Samsung N5300 (2018).
config.xml already targets Tizen 4.0. Import into Tizen Studio, use your Samsung TV author certificate with the TV DUID, connect Developer Mode and run.
Not an APK or direct USB installer. No Orsay / F6400 support. Physical N5300 validation pending.
https://morphtv.herroshetta.com/install.html
