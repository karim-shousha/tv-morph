(function(w) {
  "use strict";
  var C = w.ClearTV = w.ClearTV || {};
  var ctx = null;
  function ac() {
    try {
      if (!ctx) ctx = new (w.AudioContext || w.webkitAudioContext)();
      if (ctx.state === "suspended") ctx.resume();
      return ctx;
    } catch (e) {
      return null;
    }
  }
  function tone(freq, ms, vol, when) {
    try {
      var c = ac();
      if (!c) return;
      var t = c.currentTime + (when || 0);
      var o = c.createOscillator(), g = c.createGain();
      o.type = "sine";
      o.frequency.value = freq;
      g.gain.setValueAtTime(1e-4, t);
      g.gain.exponentialRampToValueAtTime(Math.max(1e-3, vol || 0.25), t + 0.02);
      g.gain.exponentialRampToValueAtTime(1e-4, t + ms / 1e3);
      o.connect(g);
      g.connect(c.destination);
      o.start(t);
      o.stop(t + ms / 1e3 + 0.05);
    } catch (e) {
    }
  }
  var Audio = {
    enabled: function() {
      try {
        return C.FitnessStore.settings().beeps !== false;
      } catch (e) {
        return true;
      }
    },
    count: function(n) {
      if (!Audio.enabled()) return;
      tone(n <= 0 ? 880 : 520, n <= 0 ? 450 : 160, 0.3);
    },
    go: function() {
      if (!Audio.enabled()) return;
      tone(880, 450, 0.32);
      setTimeout(function() {
        tone(1174, 350, 0.28);
      }, 120);
    },
    rest: function() {
      if (!Audio.enabled()) return;
      tone(392, 300, 0.28);
    },
    done: function() {
      if (!Audio.enabled()) return;
      [523, 659, 784, 1046].forEach(function(f, i) {
        tone(f, 260, 0.3, i * 0.16);
      });
    },
    click: function() {
      if (!Audio.enabled()) return;
      tone(660, 60, 0.12);
    }
  };
  function speak(text, lang) {
    try {
      var s = C.FitnessStore.settings();
      if (s && s.voice === false) return false;
      if (!("speechSynthesis" in w)) return false;
      w.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(text);
      u.lang = lang || "en-US";
      u.rate = 1;
      u.volume = 0.9;
      w.speechSynthesis.speak(u);
      return true;
    } catch (e) {
      return false;
    }
  }
  var PACKS = [
    { id: "motivation", title: { en: "Motivation", ar: "\u062A\u062D\u0641\u064A\u0632", fr: "Motivation", zh: "\u6FC0\u52B1", ja: "\u30E2\u30C1\u30D9\u30FC\u30B7\u30E7\u30F3" }, status: "built-in" },
    { id: "energy", title: { en: "High Energy", ar: "\u0637\u0627\u0642\u0629 \u0639\u0627\u0644\u064A\u0629", fr: "Haute \xE9nergie", zh: "\u9AD8\u80FD\u91CF", ja: "\u30CF\u30A4\u30A8\u30CA\u30B8\u30FC" }, status: "unavailable" },
    { id: "focus", title: { en: "Deep Focus", ar: "\u062A\u0631\u0643\u064A\u0632 \u0639\u0645\u064A\u0642", fr: "Concentration", zh: "\u4E13\u6CE8", ja: "\u96C6\u4E2D" }, status: "unavailable" },
    { id: "chill", title: { en: "Chill & Stretch", ar: "\u0627\u0633\u062A\u0631\u062E\u0627\u0621 \u0648\u062A\u0645\u062F\u062F", fr: "D\xE9tente", zh: "\u653E\u677E\u62C9\u4F38", ja: "\u30C1\u30EB\uFF06\u30B9\u30C8\u30EC\u30C3\u30C1" }, status: "unavailable" },
    { id: "none", title: { en: "No Music", ar: "\u0628\u062F\u0648\u0646 \u0645\u0648\u0633\u064A\u0642\u0649", fr: "Sans musique", zh: "\u65E0\u97F3\u4E50", ja: "\u97F3\u697D\u306A\u3057" }, status: "off" }
  ];
  C.FitnessAudio = {
    beep: Audio,
    speak,
    PACKS,
    packTitle: function(id, lang) {
      var p = PACKS.filter(function(x) {
        return x.id === id;
      })[0] || PACKS[0];
      return p.title[lang] || p.title.en;
    }
  };
})(window);
