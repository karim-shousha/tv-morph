(function(w) {
  "use strict";
  var origin = "https://morphtv.herroshetta.com", free = ["gta6", "blue-cinema", "blue", "emerald", "violet", "ahly", "zamalek", "ismaily", "saudi-national", "egypt-national", "madrid", "barcelona"], active = false, token = "", device = "", overlay, previous;
  function read(k) {
    try {
      return localStorage.getItem("morph.plus." + k) || "";
    } catch (e) {
      return "";
    }
  }
  function write(k, v) {
    try {
      localStorage.setItem("morph.plus." + k, v);
      return true;
    } catch (e) {
      return false;
    }
  }
  function api(path, data) {
    return new Promise(function(resolve, reject) {
      var x = new XMLHttpRequest();
      x.open("POST", origin + "/api/plus/" + path, true);
      x.setRequestHeader("Content-Type", "application/json");
      x.timeout = 12e3;
      x.onload = function() {
        try {
          var value = JSON.parse(x.responseText);
          if (x.status !== 200) throw Error(value.error || "unavailable");
          resolve(value);
        } catch (e) {
          reject(e);
        }
      };
      x.onerror = x.ontimeout = function() {
        reject(Error("network_unavailable"));
      };
      x.send(JSON.stringify(data));
    });
  }
  function random() {
    if (!w.crypto || !w.crypto.getRandomValues) throw Error("secure_random_unavailable");
    var b = new Uint8Array(24);
    w.crypto.getRandomValues(b);
    return Array.prototype.map.call(b, function(n) {
      return ("0" + n.toString(16)).slice(-2);
    }).join("");
  }
  function changed() {
    if (active) paintActivated(false);
    w.dispatchEvent(new Event("morphPlus"));
  }
  token = read("token");
  device = read("device");
  var scope = w.MorphPlusClient === "studio" ? "studio" : "tv";
  var ready = token ? api("status", { token }).then(function(v) {
    active = v.active === true && v.scope === scope;
    changed();
  }, function() {
    active = false;
    changed();
  }) : Promise.resolve();
  function allowed(theme) {
    return free.indexOf(theme) >= 0 || active;
  }
  function packAllowed(pack) {
    return active || pack.themes.every(function(t) {
      return free.indexOf(t) >= 0;
    });
  }
  function ar() {
    return document.documentElement.lang === "ar";
  }
  function close() {
    if (!overlay) return;
    overlay.remove();
    overlay = null;
    document.removeEventListener("keydown", back, true);
    var C = w.ClearTV;
    if (C && C.Focus) {
      C.Focus.setScope(previous && previous.closest("#theme-packs-overlay,#overlay") || document);
      if (previous) C.Focus.focus(previous);
    } else if (previous) previous.focus();
  }
  function back(e) {
    if (e.keyCode === 27 || e.keyCode === 10009 || e.keyCode === 461) {
      e.preventDefault();
      e.stopImmediatePropagation();
      close();
    }
  }
  function paintActivated(success) {
    if (!overlay || !active) return;
    var q = function(s) {
      return overlay.querySelector(s);
    }, lang = MorphLocale.get(), words = { ar: ["Plus \u0645\u0641\u0639\u0651\u0644 \u2713", "\u062A\u0645\u062A \u0625\u0636\u0627\u0641\u0629 \u0627\u0644\u0643\u0648\u062F \u0648\u062A\u0641\u0639\u064A\u0644 Plus \u0628\u0646\u062C\u0627\u062D. \u0645\u0632\u0627\u064A\u0627 \u0627\u0634\u062A\u0631\u0627\u0643\u0643 \u0645\u062A\u0627\u062D\u0629 \u0627\u0644\u0622\u0646.", "Plus \u0645\u0641\u0639\u0651\u0644 \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632. \u0645\u0634 \u0645\u062D\u062A\u0627\u062C \u062A\u062F\u062E\u0644 \u0627\u0644\u0643\u0648\u062F \u062A\u0627\u0646\u064A.", "\u062A\u0645 \u0627\u0644\u062A\u0641\u0639\u064A\u0644 \u2713", "\u062A\u0645", "\u0627\u0644\u062A\u0641\u0639\u064A\u0644 \u0645\u0643\u062A\u0645\u0644"], en: ["Plus is active \u2713", "Code accepted. Plus activated successfully. Your benefits are ready.", "Plus is active on this device. You do not need to enter the code again.", "Activated \u2713", "Done", "Activation complete"], fr: ["Plus est actif \u2713", "Code accept\xE9. Plus est activ\xE9. Vos avantages sont disponibles.", "Plus est actif sur cet appareil. Inutile de saisir le code \xE0 nouveau.", "Activ\xE9 \u2713", "Termin\xE9", "Activation termin\xE9e"], zh: ["Plus \u5DF2\u6FC0\u6D3B \u2713", "\u6FC0\u6D3B\u7801\u5DF2\u63A5\u53D7\uFF0CPlus \u6FC0\u6D3B\u6210\u529F\uFF0C\u6743\u76CA\u73B0\u5DF2\u53EF\u7528\u3002", "\u6B64\u8BBE\u5907\u5DF2\u6FC0\u6D3B Plus\uFF0C\u65E0\u9700\u518D\u6B21\u8F93\u5165\u6FC0\u6D3B\u7801\u3002", "\u5DF2\u6FC0\u6D3B \u2713", "\u5B8C\u6210", "\u6FC0\u6D3B\u5B8C\u6210"], ja: ["Plus \u306F\u6709\u52B9\u3067\u3059 \u2713", "\u30B3\u30FC\u30C9\u3092\u53D7\u3051\u4ED8\u3051\u3001Plus \u3092\u6709\u52B9\u306B\u3057\u307E\u3057\u305F\u3002\u7279\u5178\u3092\u5229\u7528\u3067\u304D\u307E\u3059\u3002", "\u3053\u306E\u7AEF\u672B\u3067\u306F Plus \u304C\u6709\u52B9\u3067\u3059\u3002\u30B3\u30FC\u30C9\u306E\u518D\u5165\u529B\u306F\u4E0D\u8981\u3067\u3059\u3002", "\u6709\u52B9 \u2713", "\u5B8C\u4E86", "\u6709\u52B9\u5316\u5B8C\u4E86"] }, labels = words[lang] || words.en;
    overlay.classList.add("plus-is-active");
    q("h2").textContent = labels[0];
    q(".plus-status").textContent = success ? labels[1] : labels[2];
    q("label").textContent = labels[5];
    q("input").value = "";
    q("input").placeholder = labels[5];
    q("input").disabled = true;
    q("input").readOnly = true;
    q(".plus-activate").disabled = true;
    q(".plus-activate").textContent = labels[3];
    q(".plus-close").textContent = labels[4];
    [".plus-plans", ".plus-purchase", ".plus-address", ".plus-description"].forEach(function(sel) {
      q(sel).hidden = true;
    });
    if (w.ClearTV && w.ClearTV.Focus) w.ClearTV.Focus.focus(q(".plus-close"));
    else q(".plus-close").focus();
  }
  function open() {
    if (overlay) return;
    previous = document.activeElement;
    overlay = document.createElement("div");
    overlay.className = "morph-plus-overlay";
    overlay.setAttribute("data-no-translate", "");
    overlay.innerHTML = '<section class="morph-plus-dialog" role="dialog" aria-modal="true" aria-labelledby="plus-title"><small>MORPH TV PLUS</small><h2 id="plus-title"></h2><p class="plus-description"></p><div class="plus-plans"><article><strong>Plus \xB7 $5 USD</strong><span class="plus-single"></span></article><article><strong>Plus Family \xB7 $10 USD</strong><span class="plus-family"></span></article></div><div class="plus-purchase"><img class="plus-purchase-qr" width="150" height="150" alt="Scan to open Morph TV Plus purchase page"><div><button class="plus-buy"></button><p class="plus-purchase-hint"></p></div></div><p class="plus-address">morphtv.herroshetta.com/plus.html</p><label for="plus-code"></label><input id="plus-code" type="text" maxlength="38" autocomplete="off" spellcheck="false" dir="ltr"><p class="plus-status" role="status"></p><div class="plus-actions"><button class="plus-activate"></button><button class="plus-close"></button></div><small class="plus-note"></small></section>';
    document.body.appendChild(overlay);
    var panel = overlay, q = function(s) {
      return panel.querySelector(s);
    };
    q("h2").textContent = MorphLocale.t("\u0627\u0641\u062A\u062D \u0643\u0644 \u0627\u0644\u062B\u064A\u0645\u0627\u062A \u0645\u0639 Plus", "Unlock every theme with Plus");
    q(".plus-description").textContent = MorphLocale.t("\u0627\u0644\u0623\u0632\u0631\u0642 \u0648\u0627\u0644\u0623\u062E\u0636\u0631 \u0627\u0644\u0633\u0627\u062D\u0644\u064A \u0648\u0623\u0648\u0631\u0648\u0631\u0627 \u0648\u0627\u0644\u0623\u0647\u0644\u064A \u0648\u0627\u0644\u0632\u0645\u0627\u0644\u0643 \u0648\u0627\u0644\u0625\u0633\u0645\u0627\u0639\u064A\u0644\u064A \u0648\u062B\u064A\u0645\u0627 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 \u0648\u0645\u0635\u0631 \u0627\u0644\u0648\u0637\u0646\u064A\u0627\u0646 \u0645\u062C\u0627\u0646\u064B\u0627. \u0628\u0627\u0642\u064A \u0627\u0644\u062D\u0632\u0645 \u0648\u062A\u0639\u062F\u064A\u0644\u0627\u062A \u0627\u0644\u0645\u0638\u0647\u0631 \u0627\u0644\u0645\u062A\u0642\u062F\u0645\u0629 \u0636\u0645\u0646 Plus.", "Blue, Coastal and Aurora, Al Ahly, Zamalek, Ismaily and the Saudi and Egyptian patriotic themes are free. More packs and advanced appearance controls are included in Plus.");
    q(".plus-single").textContent = MorphLocale.t("\u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \xB7 \u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u062D\u062F", "One-time purchase \xB7 1 TV");
    q(".plus-family").textContent = MorphLocale.t("\u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \xB7 \u0665 \u062A\u0644\u0641\u0632\u064A\u0648\u0646\u0627\u062A \xB7 \u0646\u0642\u0644 \u0627\u0644\u062A\u0641\u0639\u064A\u0644", "One-time purchase \xB7 5 TVs \xB7 transfer activation");
    q("label").textContent = MorphLocale.t("\u0643\u0648\u062F \u0627\u0644\u062A\u0641\u0639\u064A\u0644 \u0628\u0639\u062F \u062A\u0623\u0643\u064A\u062F \u0627\u0644\u0634\u0631\u0627\u0621", "Activation code after confirmed purchase");
    q(".plus-activate").textContent = MorphLocale.t("\u062A\u0641\u0639\u064A\u0644 Plus", "Activate Plus");
    q(".plus-close").textContent = MorphLocale.t("\u0631\u062C\u0648\u0639", "Back");
    q(".plus-note").textContent = MorphLocale.t("\u0627\u0644\u062F\u0639\u0645 \u0648\u0627\u0644\u062A\u0628\u0631\u0639\u0627\u062A \u0644\u0627 \u062A\u0641\u0639\u0651\u0644 Plus. \u064A\u0644\u0632\u0645 \u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A \u0644\u0644\u062A\u062D\u0642\u0642 \u0639\u0646\u062F \u0641\u062A\u062D \u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0648\u062A\u0646\u0632\u064A\u0644 \u0627\u0644\u062D\u0632\u0645.", "Donations do not activate Plus. Internet is required for startup verification and pack downloads.");
    q(".plus-close").onclick = close;
    q(".plus-purchase-qr").src = scope === "studio" ? "plus-purchase.webp" : "assets/plus-purchase.webp";
    q(".plus-buy").textContent = MorphLocale.t("\u0634\u0631\u0627\u0621 Plus \u0648\u0641\u062A\u062D \u0627\u0644\u062B\u064A\u0645\u0627\u062A \u2197", "Buy Plus and unlock themes \u2197");
    q(".plus-purchase-hint").textContent = MorphLocale.t("\u0627\u0641\u062A\u062D \u0635\u0641\u062D\u0629 \u0627\u0644\u0634\u0631\u0627\u0621\u060C \u0623\u0648 \u0627\u0645\u0633\u062D QR \u0628\u0627\u0644\u0645\u0648\u0628\u0627\u064A\u0644. \u0627\u0644\u062F\u0641\u0639 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629.", "Open the purchase page or scan with your phone. One-time payment.");
    q(".plus-description").textContent = MorphLocale.t("Plus \u064A\u0641\u062A\u062D \u062D\u0632\u0645 \u0627\u0644\u062B\u064A\u0645\u0627\u062A \u0627\u0644\u0625\u0636\u0627\u0641\u064A\u0629 \u0648\u062A\u063A\u064A\u064A\u0631 \u0627\u0644\u0627\u0633\u0645 \u0648\u0627\u0644\u0643\u062A\u0627\u0628\u0629 \u0648\u0627\u0644\u0635\u0648\u0631 \u0648\u0627\u0644\u0644\u0648\u062C\u0648 \u0648\u0633\u0644\u0627\u064A\u062F \u0634\u0648 \u0635\u0648\u0631\u0643. \u0642\u0631\u064A\u0628\u064B\u0627 \u0628\u0631\u0646\u0627\u0645\u062C \u0631\u064A\u0627\u0636\u064A \u0645\u062A\u0643\u0627\u0645\u0644 \u0636\u0645\u0646 Plus\u060C \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u062D\u0627\u0644\u064A\u064B\u0627.", "Plus unlocks extra theme packs, custom name and text, your images and logo, and a photo slideshow. A complete fitness module is coming to Plus; it is not available yet.");
    q(".plus-single").textContent = MorphLocale.t("$5 \xB7 \u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u062D\u062F \xB7 \u0631\u0627\u062C\u0639 \u0645\u062F\u0629 \u0627\u0644\u062A\u0641\u0639\u064A\u0644 \u0639\u0646\u062F \u0627\u0644\u0634\u0631\u0627\u0621", "$5 \xB7 1 TV \xB7 check activation term at checkout");
    q(".plus-family").textContent = MorphLocale.t("$10 \xB7 \u062D\u062A\u0649 \u0665 \u062A\u0644\u0641\u0632\u064A\u0648\u0646\u0627\u062A \xB7 \u0631\u0627\u062C\u0639 \u0627\u0644\u0645\u062F\u0629 \u0639\u0646\u062F \u0627\u0644\u0634\u0631\u0627\u0621", "$10 \xB7 up to 5 TVs \xB7 check the term at checkout");
    q(".plus-purchase-hint").textContent = MorphLocale.t("\u0639\u0631\u0636 \u0627\u0644\u0625\u0637\u0644\u0627\u0642: \u0634\u0631\u0627\u0621 \u0645\u062F\u0649 \u0627\u0644\u062D\u064A\u0627\u0629 \u062E\u0644\u0627\u0644 \u0634\u0647\u0631 \u0627\u0644\u0639\u0631\u0636. \u0628\u0639\u062F\u0647 \u062A\u0641\u0639\u064A\u0644 \u0633\u0646\u0648\u064A \u0644\u0644\u0645\u0634\u062A\u0631\u064A\u0646 \u0627\u0644\u062C\u062F\u062F. \u0627\u0644\u062A\u0631\u0627\u062E\u064A\u0635 \u0645\u062F\u0649 \u0627\u0644\u062D\u064A\u0627\u0629 \u0644\u0627 \u062A\u062A\u062D\u0648\u0644 \u0644\u0633\u0646\u0648\u064A\u0629. \u0631\u0627\u062C\u0639 \u0627\u0644\u062A\u0627\u0631\u064A\u062E \u0648\u0627\u0644\u0634\u0631\u0648\u0637 \u0641\u064A \u0635\u0641\u062D\u0629 \u0627\u0644\u0634\u0631\u0627\u0621.", "Launch offer: lifetime purchase during the offer month. Annual activation for new buyers afterwards. Lifetime licenses remain lifetime. Check dates and terms on the purchase page.");
    q(".plus-buy").onclick = function() {
      window.open(origin + "/plus.html?lang=" + MorphLocale.get(), "_blank", "noopener");
    };
    var locale = MorphLocale.get();
    if (locale === "fr") {
      q(".plus-description").textContent = "Plus d\xE9bloque les packs suppl\xE9mentaires, le nom et les textes personnalis\xE9s, vos images et votre logo, ainsi qu\u2019un diaporama. Un programme sportif complet est en pr\xE9paration, indisponible actuellement.";
      q(".plus-single").textContent = "5 $ \xB7 1 TV \xB7 dur\xE9e indiqu\xE9e au paiement";
      q(".plus-family").textContent = "10 $ \xB7 5 TV maximum \xB7 dur\xE9e indiqu\xE9e au paiement";
      q(".plus-purchase-hint").textContent = "Offre de lancement : achat \xE0 vie pendant un mois. Ensuite, activation annuelle pour les nouveaux achats. Les licences \xE0 vie restent \xE0 vie. Dates et conditions sur la page d\u2019achat.";
    }
    if (locale === "zh") {
      q(".plus-description").textContent = "Plus \u89E3\u9501\u989D\u5916\u4E3B\u9898\u3001\u81EA\u5B9A\u4E49\u540D\u79F0\u548C\u6587\u5B57\u3001\u56FE\u7247\u3001\u6807\u5FD7\u53CA\u80CC\u666F\u5E7B\u706F\u7247\u3002\u5B8C\u6574\u5065\u8EAB\u6A21\u5757\u5373\u5C06\u63A8\u51FA\uFF0C\u76EE\u524D\u5C1A\u672A\u63D0\u4F9B\u3002";
      q(".plus-single").textContent = "$5 \xB7 1 \u53F0\u7535\u89C6 \xB7 \u8BF7\u5728\u4ED8\u6B3E\u9875\u786E\u8BA4\u671F\u9650";
      q(".plus-family").textContent = "$10 \xB7 \u6700\u591A 5 \u53F0\u7535\u89C6 \xB7 \u8BF7\u5728\u4ED8\u6B3E\u9875\u786E\u8BA4\u671F\u9650";
      q(".plus-purchase-hint").textContent = "\u9996\u53D1\u4F18\u60E0\u6708\u5185\u53EF\u4E00\u6B21\u4ED8\u6B3E\u7EC8\u8EAB\u6FC0\u6D3B\uFF1B\u4E4B\u540E\u65B0\u8D2D\u4E70\u6539\u4E3A\u5E74\u5EA6\u6FC0\u6D3B\u3002\u5DF2\u6709\u7EC8\u8EAB\u8BB8\u53EF\u4FDD\u6301\u4E0D\u53D8\u3002\u8BF7\u67E5\u770B\u8D2D\u4E70\u9875\u7684\u65E5\u671F\u548C\u6761\u6B3E\u3002";
    }
    if (locale === "ja") {
      q(".plus-description").textContent = "Plus \u3067\u8FFD\u52A0\u30C6\u30FC\u30DE\u3001\u540D\u524D\u3084\u6587\u5B57\u3001\u753B\u50CF\u3001\u30ED\u30B4\u3001\u5199\u771F\u30B9\u30E9\u30A4\u30C9\u30B7\u30E7\u30FC\u3092\u30AB\u30B9\u30BF\u30DE\u30A4\u30BA\u3067\u304D\u307E\u3059\u3002\u30D5\u30A3\u30C3\u30C8\u30CD\u30B9\u6A5F\u80FD\u306F\u8FD1\u65E5\u516C\u958B\u4E88\u5B9A\u3067\u3001\u73FE\u5728\u306F\u5229\u7528\u3067\u304D\u307E\u305B\u3093\u3002";
      q(".plus-single").textContent = "$5 \xB7 \u30C6\u30EC\u30D3 1 \u53F0 \xB7 \u6709\u52B9\u671F\u9593\u306F\u8CFC\u5165\u30DA\u30FC\u30B8\u3067\u78BA\u8A8D";
      q(".plus-family").textContent = "$10 \xB7 \u30C6\u30EC\u30D3\u6700\u5927 5 \u53F0 \xB7 \u6709\u52B9\u671F\u9593\u306F\u8CFC\u5165\u30DA\u30FC\u30B8\u3067\u78BA\u8A8D";
      q(".plus-purchase-hint").textContent = "\u767A\u58F2\u8A18\u5FF5\u306E 1 \u304B\u6708\u9593\u306F\u8CB7\u3044\u5207\u308A\u306E\u6C38\u4E45\u30E9\u30A4\u30BB\u30F3\u30B9\u3067\u3059\u3002\u305D\u306E\u5F8C\u306E\u65B0\u898F\u8CFC\u5165\u306F\u5E74\u9593\u5229\u7528\u3068\u306A\u308A\u307E\u3059\u3002\u65E2\u5B58\u306E\u6C38\u4E45\u30E9\u30A4\u30BB\u30F3\u30B9\u306F\u5909\u308F\u308A\u307E\u305B\u3093\u3002\u8CFC\u5165\u30DA\u30FC\u30B8\u3067\u671F\u9593\u3068\u6761\u4EF6\u3092\u3054\u78BA\u8A8D\u304F\u3060\u3055\u3044\u3002";
    }
    q(".plus-activate").onclick = function() {
      if (active || q(".plus-activate").disabled) return;
      var code = q("input").value.trim().toUpperCase();
      if (!/^MORPH-[A-Z2-7]{32}$/.test(code)) {
        q(".plus-status").textContent = MorphLocale.t("\u0631\u0627\u062C\u0639 \u0643\u0648\u062F \u0627\u0644\u062A\u0641\u0639\u064A\u0644.", "Check the activation code.");
        return;
      }
      var b = q(".plus-activate");
      b.disabled = true;
      q("input").disabled = true;
      q(".plus-status").textContent = MorphLocale.t("\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0642\u0642\u2026", "Verifying\u2026");
      try {
        if (!device) {
          device = random();
          if (!write("device", device)) throw Error("storage_unavailable");
        }
      } catch (e) {
        b.disabled = false;
        q("input").disabled = false;
        q(".plus-status").textContent = MorphLocale.t("\u0627\u0644\u062A\u062E\u0632\u064A\u0646 \u0623\u0648 \u0627\u0644\u062A\u0634\u0641\u064A\u0631 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632.", "Secure storage or random generation is unavailable.");
        return;
      }
      api(scope === "studio" ? "studio" : "activate", { code, device, name: read("name") || "Morph TV" }).then(function(v) {
        if (v.active !== true || v.scope !== scope || !v.token) throw Error("activation_failed");
        if (!write("token", v.token)) throw Error("storage_unavailable");
        token = v.token;
        active = true;
        changed();
        paintActivated(true);
      }, function() {
        q(".plus-status").textContent = MorphLocale.t("\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u062A\u0641\u0639\u064A\u0644. \u0631\u0627\u062C\u0639 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0648\u0627\u0644\u0643\u0648\u062F \u0648\u0639\u062F\u062F \u0627\u0644\u0623\u062C\u0647\u0632\u0629 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0634\u0631\u0627\u0621.", "Activation failed. Check connection, code and device limit on the purchase page.");
      }).then(function() {
        b.disabled = active;
        q("input").disabled = active;
      }, function() {
        b.disabled = false;
        q("input").disabled = false;
        q(".plus-status").textContent = MorphLocale.t("\u062A\u0639\u0630\u0651\u0631 \u062D\u0641\u0638 \u0627\u0644\u062A\u0641\u0639\u064A\u0644. \u0631\u0627\u062C\u0639 \u0627\u0644\u062A\u062E\u0632\u064A\u0646 \u0648\u062D\u0627\u0648\u0644 \u062A\u0641\u0639\u064A\u0644\u0647 \u0628\u0627\u0644\u0643\u0648\u062F \u0646\u0641\u0633\u0647.", "Unable to save activation. Check storage and activate again with the same code.");
      });
    };
    var codeInput = q("input");
    if (w.TVNative && w.TVNative.showKeyboard) {
      let editCode = function() {
        if (codeInput.disabled) return;
        if (w.ClearTV) ClearTV.keyboardVisible = true;
        w.TVNative.showKeyboard("plus-code", codeInput.value);
      };
      codeInput.readOnly = true;
      codeInput.onclick = editCode;
      codeInput.addEventListener("keydown", function(e) {
        if (e.keyCode === 13) {
          e.preventDefault();
          e.stopImmediatePropagation();
          editCode();
        }
      }, true);
    } else {
      codeInput.addEventListener("focus", function() {
        codeInput.scrollIntoView({ block: "center" });
      });
      codeInput.addEventListener("keydown", function(e) {
        if (e.keyCode === 13 || e.keyCode === 65376) {
          e.preventDefault();
          e.stopImmediatePropagation();
          codeInput.blur();
          q(".plus-activate").focus();
          if (w.ClearTV) ClearTV.keyboardVisible = false;
        }
      }, true);
    }
    document.addEventListener("keydown", back, true);
    var C = w.ClearTV;
    if (C && C.Focus) {
      C.Focus.setScope(overlay);
      C.Focus.focus(q("input"));
    } else q("input").focus();
    if (active) paintActivated(false);
  }
  w.MorphPlus = { ready, freeThemes: free, isActive: function() {
    return active;
  }, allowed, packAllowed, open, token: function() {
    return active ? token : "";
  }, advancedKeys: ["cardWidth", "customTitle", "customSubtitle", "logoImage", "artImage", "backgroundStart", "backgroundEnd", "cardColor", "textColor", "accent", "backgroundImages", "slideshowEnabled", "slideshowSeconds", "glassOpacity", "iconTint", "highlightColor", "artOffsetX", "artOffsetY", "textOffsetX", "textOffsetY", "logoOffsetX", "logoOffsetY", "heroTitleSize", "heroSubtitleSize", "heroArtSize", "heroLogoSize"] };
})(window);
