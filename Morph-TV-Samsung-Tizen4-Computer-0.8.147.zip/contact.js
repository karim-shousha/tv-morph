(function(w) {
  "use strict";
  function make() {
    var ar = w.MorphLocale ? MorphLocale.get() === "ar" : document.documentElement.lang === "ar", box = document.createElement("div");
    box.className = "morph-contact";
    box.setAttribute("data-no-translate", "");
    var title = document.createElement("h3"), text = document.createElement("p"), email = document.createElement("a");
    title.textContent = MorphLocale.t("\u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627", "Contact us");
    text.textContent = MorphLocale.t("\u0644\u0648 \u0639\u0627\u064A\u0632 \u062A\u0635\u0645\u0645 \u062B\u064A\u0645 \u062E\u0627\u0635 \u0628\u0634\u0631\u0643\u062A\u0643 \u0623\u0648 \u0628\u0639\u0644\u0627\u0645\u062A\u0643 \u0627\u0644\u062A\u062C\u0627\u0631\u064A\u0629\u060C \u0623\u0648 \u0639\u0646\u062F\u0643 \u0623\u064A \u0645\u0634\u0643\u0644\u0629\u060C \u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0627\u0646\u0627.", "For a custom theme for your company or brand, or help with any issue, contact us.");
    email.textContent = "support@herroshetta.com";
    email.href = "mailto:support@herroshetta.com";
    email.dir = "ltr";
    email.onclick = function(e) {
      if (w.ClearNative && ClearNative.openContact) {
        e.preventDefault();
        ClearNative.openContact();
      }
    };
    email.style.cssText = "display:inline-block;color:inherit;font-weight:bold;overflow-wrap:anywhere;user-select:all";
    box.appendChild(title);
    box.appendChild(text);
    box.appendChild(email);
    return box;
  }
  w.MorphContact = { create: make };
  function phone() {
    var host = document.querySelector(".about-us");
    if (!host) return;
    var old = document.getElementById("morph-contact-panel");
    if (old) old.remove();
    var details = document.createElement("details"), summary = document.createElement("summary");
    details.id = "morph-contact-panel";
    details.className = "panel";
    summary.textContent = w.MorphLocale && MorphLocale.t("\u062A\u0648\u0627\u0635\u0644 \u0645\u0639\u0646\u0627", "Contact us");
    details.appendChild(summary);
    details.appendChild(make());
    host.parentNode.insertBefore(details, host);
  }
  w.addEventListener("load", phone);
  w.addEventListener("morphLanguage", phone);
})(window);
