(function(w) {
  "use strict";
  var C = w.ClearTV = w.ClearTV || {};
  var ctx = null;
  function ac() {
    try {
      if (!ctx) ctx = new (w.AudioContext || w.webkitAudioContext)();
      if (ctx.state === "suspended") ctx.resume();
      return ctx;
    } catch (e) {
      return null;
    }
  }
  function tone(freq, ms, vol, when) {
    try {
      var c = ac();
      if (!c) return;
      var t = c.currentTime + (when || 0);
      var o = c.createOscillator(), g = c.createGain();
      o.type = "sine";
      o.frequency.value = freq;
      g.gain.setValueAtTime(1e-4, t);
      g.gain.exponentialRampToValueAtTime(Math.max(1e-3, vol || 0.25), t + 0.02);
      g.gain.exponentialRampToValueAtTime(1e-4, t + ms / 1e3);
      o.connect(g);
      g.connect(c.destination);
      o.start(t);
      o.stop(t + ms / 1e3 + 0.05);
    } catch (e) {
    }
  }
  var Audio = {
    enabled: function() {
      try {
        return C.FitnessStore.settings().beeps !== false;
      } catch (e) {
        return true;
      }
    },
    count: function(n) {
      if (!Audio.enabled()) return;
      tone(n <= 0 ? 880 : 520, n <= 0 ? 450 : 160, 0.3);
    },
    go: function() {
      if (!Audio.enabled()) return;
      tone(880, 450, 0.32);
      setTimeout(function() {
        tone(1174, 350, 0.28);
      }, 120);
    },
    rest: function() {
      if (!Audio.enabled()) return;
      tone(392, 300, 0.28);
    },
    done: function() {
      if (!Audio.enabled()) return;
      [523, 659, 784, 1046].forEach(function(f, i) {
        tone(f, 260, 0.3, i * 0.16);
      });
    },
    click: function() {
      if (!Audio.enabled()) return;
      tone(660, 60, 0.12);
    }
  };
  function speak(text, lang) {
    try {
      var s = C.FitnessStore.settings();
      if (s && s.voice === false) return false;
      if (!("speechSynthesis" in w)) return false;
      w.speechSynthesis.cancel();
      var u = new SpeechSynthesisUtterance(text);
      u.lang = lang || "en-US";
      u.rate = 1;
      u.volume = 0.9;
      w.speechSynthesis.speak(u);
      return true;
    } catch (e) {
      return false;
    }
  }
  var PACKS = [
    { id: "motivation", title: { ar: "\u0637\u0627\u0642\u0629 \u0627\u0644\u0635\u0628\u0627\u062D", en: "Morning Energy", fr: "\xC9nergie du matin", zh: "\u6668\u95F4\u6D3B\u529B", ja: "\u671D\u306E\u30A8\u30CD\u30EB\u30AE\u30FC" }, status: "streaming", url: "https://morphtv.herroshetta.com/fitness-music/v1/Sport1.mp3" },
    { id: "energy", title: { ar: "\u0625\u064A\u0642\u0627\u0639 \u0627\u0644\u062D\u0631\u0643\u0629", en: "Rhythm of Movement", fr: "Rythme du mouvement", zh: "\u8FD0\u52A8\u8282\u594F", ja: "\u52D5\u304D\u306E\u30EA\u30BA\u30E0" }, status: "streaming", url: "https://morphtv.herroshetta.com/fitness-music/v1/Sport2.mp3" },
    { id: "focus", title: { ar: "\u062F\u0641\u0639\u0629 \u0642\u0648\u064A\u0629", en: "Power Boost", fr: "Coup de boost", zh: "\u5F3A\u52B2\u52A8\u529B", ja: "\u30D1\u30EF\u30FC\u30D6\u30FC\u30B9\u30C8" }, status: "streaming", url: "https://morphtv.herroshetta.com/fitness-music/v1/Sport3.mp3" },
    { id: "none", title: { ar: "\u0628\u062F\u0648\u0646 \u0645\u0648\u0633\u064A\u0642\u0649", en: "No Music", fr: "Sans musique", zh: "\u65E0\u97F3\u4E50", ja: "\u97F3\u697D\u306A\u3057" }, status: "off" }
  ];
  var words = {
    ar: { listen: "\u0627\u0633\u062A\u0645\u0627\u0639", stopPreview: "\u0625\u064A\u0642\u0627\u0641 \u0627\u0644\u0645\u0639\u0627\u064A\u0646\u0629", musicOnline: "\u0627\u0644\u0645\u0648\u0633\u064A\u0642\u0649 \u062A\u062D\u062A\u0627\u062C \u0627\u062A\u0635\u0627\u0644 \u0625\u0646\u062A\u0631\u0646\u062A\u060C \u0648\u062A\u062A\u062D\u0645\u0651\u0644 \u0639\u0646\u062F \u0627\u0644\u062A\u0634\u063A\u064A\u0644.", musicIdle: "\u0627\u062E\u062A\u0627\u0631 \u0645\u0642\u0637\u0639\u064B\u0627 \u0644\u0644\u0627\u0633\u062A\u0645\u0627\u0639 \u0623\u0648 \u0644\u0644\u062A\u0645\u0631\u064A\u0646.", musicLoading: "\u062C\u0627\u0631\u064A \u062A\u062C\u0647\u064A\u0632 \u0627\u0644\u0645\u0648\u0633\u064A\u0642\u0649\u2026", musicPlaying: "\u0627\u0644\u0645\u0648\u0633\u064A\u0642\u0649 \u062A\u0639\u0645\u0644", musicPaused: "\u0627\u0644\u0645\u0648\u0633\u064A\u0642\u0649 \u0645\u062A\u0648\u0642\u0641\u0629 \u0645\u0624\u0642\u062A\u064B\u0627", musicFailed: "\u062A\u0639\u0630\u0651\u0631 \u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0645\u0648\u0633\u064A\u0642\u0649. \u0631\u0627\u062C\u0639 \u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A \u0648\u062C\u0631\u0651\u0628 \u0627\u0644\u0627\u0633\u062A\u0645\u0627\u0639 \u0645\u0631\u0629 \u0623\u062E\u0631\u0649.", on: "\u062A\u0634\u063A\u064A\u0644", off: "\u0625\u064A\u0642\u0627\u0641" },
    en: { listen: "Listen", stopPreview: "Stop preview", musicOnline: "Music needs an internet connection and loads when played.", musicIdle: "Choose a track to preview or use during your workout.", musicLoading: "Loading music\u2026", musicPlaying: "Music is playing", musicPaused: "Music is paused", musicFailed: "Music could not play. Check your connection and try Listen again.", on: "On", off: "Off" },
    fr: { listen: "\xC9couter", stopPreview: "Arr\xEAter l\u2019\xE9coute", musicOnline: "La musique n\xE9cessite Internet et se charge \xE0 la lecture.", musicIdle: "Choisissez un morceau \xE0 \xE9couter ou \xE0 utiliser pendant la s\xE9ance.", musicLoading: "Chargement de la musique\u2026", musicPlaying: "Lecture en cours", musicPaused: "Musique en pause", musicFailed: "Lecture impossible. V\xE9rifiez la connexion puis r\xE9essayez.", on: "Activ\xE9", off: "D\xE9sactiv\xE9" },
    zh: { listen: "\u8BD5\u542C", stopPreview: "\u505C\u6B62\u8BD5\u542C", musicOnline: "\u97F3\u4E50\u64AD\u653E\u65F6\u52A0\u8F7D\uFF0C\u9700\u8981\u7F51\u7EDC\u8FDE\u63A5\u3002", musicIdle: "\u9009\u62E9\u97F3\u4E50\u8FDB\u884C\u8BD5\u542C\u6216\u7528\u4E8E\u953B\u70BC\u3002", musicLoading: "\u6B63\u5728\u52A0\u8F7D\u97F3\u4E50\u2026", musicPlaying: "\u97F3\u4E50\u6B63\u5728\u64AD\u653E", musicPaused: "\u97F3\u4E50\u5DF2\u6682\u505C", musicFailed: "\u97F3\u4E50\u65E0\u6CD5\u64AD\u653E\uFF0C\u8BF7\u68C0\u67E5\u7F51\u7EDC\u540E\u91CD\u8BD5\u3002", on: "\u5F00\u542F", off: "\u5173\u95ED" },
    ja: { listen: "\u8A66\u8074", stopPreview: "\u8A66\u8074\u3092\u505C\u6B62", musicOnline: "\u97F3\u697D\u306F\u518D\u751F\u6642\u306B\u8AAD\u307F\u8FBC\u307E\u308C\u3001\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u63A5\u7D9A\u304C\u5FC5\u8981\u3067\u3059\u3002", musicIdle: "\u8A66\u8074\u307E\u305F\u306F\u30C8\u30EC\u30FC\u30CB\u30F3\u30B0\u7528\u306E\u66F2\u3092\u9078\u3093\u3067\u304F\u3060\u3055\u3044\u3002", musicLoading: "\u97F3\u697D\u3092\u8AAD\u307F\u8FBC\u307F\u4E2D\u2026", musicPlaying: "\u97F3\u697D\u3092\u518D\u751F\u4E2D", musicPaused: "\u97F3\u697D\u306F\u4E00\u6642\u505C\u6B62\u4E2D", musicFailed: "\u518D\u751F\u3067\u304D\u307E\u305B\u3093\u3002\u63A5\u7D9A\u3092\u78BA\u8A8D\u3057\u3066\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002", on: "\u30AA\u30F3", off: "\u30AA\u30D5" }
  };
  Object.keys(words).forEach(function(lang) {
    Object.assign(C.FitnessI18n.all[lang], words[lang]);
  });
  var audio = null, track = "", mode = "", state = "idle", epoch = 0;
  function selected(id) {
    return PACKS.filter(function(p) {
      return p.id === id;
    })[0] || PACKS[0];
  }
  function notify(next) {
    state = next;
    if (w.dispatchEvent && w.CustomEvent) w.dispatchEvent(new CustomEvent("morphFitnessMusic"));
  }
  function ensure() {
    if (audio) return audio;
    audio = document.createElement("audio");
    audio.id = "fitness-background-music";
    audio.preload = "none";
    audio.loop = true;
    audio.style.display = "none";
    document.body.appendChild(audio);
    audio.addEventListener("playing", function() {
      if (mode) notify("playing");
    });
    audio.addEventListener("pause", function() {
      if (mode && (audio.error || state === "error")) {
        notify("error");
        return;
      }
      notify(mode ? "paused" : "idle");
    });
    audio.addEventListener("error", function() {
      if (mode) notify("error");
    });
    return audio;
  }
  function stop() {
    epoch++;
    mode = "";
    track = "";
    if (audio) {
      audio.pause();
      audio.removeAttribute("src");
      audio.load();
    }
    notify("idle");
  }
  function pause() {
    epoch++;
    if (audio) audio.pause();
    if (mode) notify("paused");
  }
  function start(kind, id) {
    var settings = C.FitnessStore.settings(), p = selected(id || settings.musicPack);
    if (p.status === "off" || kind !== "preview" && settings.musicEnabled === false) {
      stop();
      return Promise.resolve(false);
    }
    var a = ensure(), token = ++epoch;
    mode = kind || "workout";
    a.volume = Math.max(0, Math.min(100, Number(settings.musicVolume) || 0)) / 100;
    if (track !== p.id || a.error || state === "error") {
      a.pause();
      a.src = p.url;
      track = p.id;
      a.load();
    }
    notify("loading");
    var promise;
    try {
      promise = a.play();
    } catch (e) {
      notify("error");
      return Promise.resolve(false);
    }
    return Promise.resolve(promise).then(function() {
      return token === epoch && !a.paused;
    }, function(e) {
      if (token === epoch && e.name !== "AbortError") notify("error");
      return false;
    });
  }
  function sync(running) {
    var settings = C.FitnessStore.settings();
    if (settings.musicEnabled === false || selected(settings.musicPack).status === "off") {
      stop();
      return;
    }
    if (audio) audio.volume = Math.max(0, Math.min(100, Number(settings.musicVolume) || 0)) / 100;
    if (running) return start("workout");
    if (mode === "workout" && track !== selected(settings.musicPack).id) pause();
  }
  var music = {
    start,
    pause,
    stop,
    sync,
    select: function(id) {
      var settings = C.FitnessStore.settings();
      settings.musicPack = selected(id).id;
      C.FitnessStore.saveSettings(settings);
      stop();
    },
    preview: function(id) {
      if (mode === "preview" && track === id && audio && !audio.paused) {
        stop();
        return Promise.resolve(false);
      }
      return start("preview", id);
    },
    stopPreview: function() {
      if (mode === "preview") stop();
    },
    snapshot: function() {
      return { track, mode, state, paused: !audio || audio.paused, volume: audio ? audio.volume : 0, time: audio ? audio.currentTime : 0, duration: audio && isFinite(audio.duration) ? audio.duration : 0 };
    },
    statusText: function() {
      return C.FitnessI18n.t({ idle: "musicIdle", loading: "musicLoading", playing: "musicPlaying", paused: "musicPaused", error: "musicFailed" }[state] || "musicIdle");
    }
  };
  C.FitnessAudio = {
    beep: Audio,
    speak,
    PACKS,
    music,
    packTitle: function(id, lang) {
      var p = selected(id);
      return p.title[lang] || p.title.en;
    }
  };
  if (w.addEventListener) {
    w.addEventListener("morphAudioExclusive", pause);
    w.addEventListener("unload", stop);
  }
})(window);
