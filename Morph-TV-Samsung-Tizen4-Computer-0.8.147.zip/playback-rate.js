(function(C) {
  "use strict";
  var values = [0.5, 0.75, 1, 1.25, 1.5, 2, 3];
  function words() {
    return { ar: ["\u0627\u0644\u0633\u0631\u0639\u0629", "\u0647\u0630\u0647 \u0627\u0644\u0633\u0631\u0639\u0629 \u063A\u064A\u0631 \u0645\u062F\u0639\u0648\u0645\u0629 \u0645\u0646 \u0627\u0644\u062C\u0647\u0627\u0632 \u0623\u0648 \u0627\u0644\u0628\u062B.", "\u0627\u0646\u062A\u0638\u0631 \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0641\u064A\u062F\u064A\u0648."], en: ["Speed", "This speed is not supported by the device or stream.", "Wait for the video to load."], fr: ["Vitesse", "Cette vitesse n\u2019est pas prise en charge par l\u2019appareil ou le flux.", "Attendez le chargement de la vid\xE9o."], zh: ["\u901F\u5EA6", "\u8BBE\u5907\u6216\u89C6\u9891\u6D41\u4E0D\u652F\u6301\u6B64\u901F\u5EA6\u3002", "\u8BF7\u7B49\u5F85\u89C6\u9891\u52A0\u8F7D\u3002"], ja: ["\u901F\u5EA6", "\u6A5F\u5668\u307E\u305F\u306F\u914D\u4FE1\u304C\u3053\u306E\u901F\u5EA6\u306B\u5BFE\u5FDC\u3057\u3066\u3044\u307E\u305B\u3093\u3002", "\u52D5\u753B\u306E\u8AAD\u307F\u8FBC\u307F\u3092\u304A\u5F85\u3061\u304F\u3060\u3055\u3044\u3002"] }[window.MorphLocale ? MorphLocale.get() : "en"] || ["Speed", "This speed is not supported.", "Wait for the video to load."];
  }
  function apply(video, rate) {
    if (values.indexOf(rate) < 0) throw Error("Invalid playback rate");
    var previous = video.playbackRate, paused = video.paused;
    try {
      video.playbackRate = rate;
      if (!isFinite(video.playbackRate) || Math.abs(video.playbackRate - rate) > 0.02) throw Error("Rate rejected");
      return video.playbackRate;
    } catch (error) {
      try {
        video.playbackRate = previous;
      } catch (ignore) {
      }
      throw error;
    } finally {
      if (paused && !video.paused) video.pause();
    }
  }
  C.PlaybackRate = { values, words, apply };
})(window.ClearTV);
