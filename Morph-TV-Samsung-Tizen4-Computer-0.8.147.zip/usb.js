(function(C) {
  "use strict";
  var rows = [], rail, dialog, returnFocus, generation = 0, storageListener = null;
  function t(ar, en) {
    return window.MorphLocale ? MorphLocale.t(ar, en) : en;
  }
  function error() {
    C.toast(t("\u062A\u0639\u0630\u0651\u0631 \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0641\u0644\u0627\u0634\u0629. \u062A\u0623\u0643\u062F \u0623\u0646 \u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u062A\u0639\u0631\u0651\u0641 \u0639\u0644\u064A\u0647\u0627 \u0648\u0623\u0646 \u0646\u0648\u0639 \u0627\u0644\u0645\u0644\u0641\u0627\u062A \u0645\u062F\u0639\u0648\u0645.", "USB could not be read. Check that the TV recognizes the drive and supports its files."));
  }
  function nativeFs() {
    return typeof tizen !== "undefined" && tizen.filesystem;
  }
  function merge(state) {
    state.sources = (state.sources || []).filter(function(s) {
      return s.type !== "USB";
    }).concat(rows);
    if (rows.some(function(r) {
      return r.connected === true;
    }) && !state.loading && !state.sources.some(function(s) {
      return s.type !== "USB";
    })) state.error = "";
  }
  function paint() {
    if (!rail) return;
    var focus = document.activeElement, was = rail.contains(focus), id = focus && focus.getAttribute("data-usb-id");
    rail.textContent = "";
    rows.filter(function(r) {
      return r.connected === true;
    }).forEach(function(r) {
      var b = C.el("button", "home-usb");
      b.setAttribute("data-usb-id", r.id);
      b.setAttribute("data-no-translate", "");
      b.innerHTML = '<svg viewBox="0 0 32 32" width="30" height="30" aria-hidden="true"><path d="M10 3h12v9H10zM8 12h16v16H8z" fill="none" stroke="currentColor" stroke-width="2"/><path d="M14 5v4m4-4v4M12 22h8" stroke="currentColor" stroke-width="2"/></svg>';
      b.appendChild(C.el("span", "", "USB \xB7 " + r.title));
      b.onclick = function() {
        open(r);
      };
      rail.appendChild(b);
    });
    rail.hidden = !rail.children.length;
    if (was) {
      var replacement = Array.prototype.filter.call(rail.children, function(b) {
        return b.getAttribute("data-usb-id") === id;
      })[0];
      C.Focus.focus(replacement || document.getElementById("nav-home"));
    }
    merge(C.Inputs.state);
    if (C.inputsChanged) C.inputsChanged(C.Inputs.state);
  }
  function setRows(next) {
    var old = rows.filter(function(r) {
      return r.connected;
    }).map(function(r) {
      return r.id;
    });
    rows = next;
    paint();
    if (next.some(function(r) {
      return r.connected === true && old.indexOf(r.id) < 0;
    })) C.toast(t("\u062A\u0645 \u062A\u0648\u0635\u064A\u0644 \u0641\u0644\u0627\u0634\u0629 USB. \u0627\u0641\u062A\u062D\u0647\u0627 \u0645\u0646 \u0627\u0644\u0623\u064A\u0642\u0648\u0646\u0629 \u0623\u0633\u0641\u0644 \u0627\u0644\u0647\u0648\u0645 \u0623\u0648 \u0645\u0646 \u0627\u0644\u0645\u062F\u0627\u062E\u0644.", "USB drive connected. Open it below Home or in Inputs."));
    if (dialog && dialog.getAttribute("data-volume") && !next.some(function(r) {
      return r.id === dialog.getAttribute("data-volume");
    })) close();
  }
  function refresh() {
    var run = ++generation;
    if (window.TVNative && TVNative.usbJson) {
      try {
        setRows(JSON.parse(TVNative.usbJson()).filter(function(r) {
          return r && r.type === "USB" && r.id && r.connected === true;
        }));
      } catch (e) {
        setRows([]);
      }
      return;
    }
    if (nativeFs()) {
      try {
        tizen.filesystem.listStorages(function(list) {
          if (run !== generation) return;
          setRows(list.filter(function(s) {
            return s.type === "EXTERNAL" && s.state === "MOUNTED";
          }).map(function(s, i) {
            return { id: "usb:" + s.label, type: "USB", number: 0, title: t("\u0648\u062D\u062F\u0629 \u062A\u062E\u0632\u064A\u0646", "Drive") + " " + (i + 1), storage: s.label, connected: true };
          }));
        }, function() {
          if (run === generation) setRows([]);
        });
      } catch (e) {
        setRows([]);
      }
      return;
    }
    if (window.MorphLG && window.webOS) {
      lgMedia(run);
    }
  }
  function lgMedia(run) {
    var candidates = ["com.webos.app.mediaplayer", "com.webos.app.photovideo", "com.webos.app.smartshare"];
    function check(i) {
      if (i >= candidates.length) {
        if (run === generation) setRows([]);
        return;
      }
      var id = candidates[i], done = false, timer = setTimeout(function() {
        finish(false);
      }, 2500);
      function finish(ok) {
        if (done) return;
        done = true;
        clearTimeout(timer);
        if (run !== generation) return;
        if (ok) setRows([{ id, type: "USB", number: 0, title: t("\u0645\u0634\u063A\u0651\u0644 \u0627\u0644\u0648\u0633\u0627\u0626\u0637", "Media player"), connected: null, mediaApp: id }]);
        else check(i + 1);
      }
      try {
        webOS.service.request("luna://com.webos.applicationManager", { method: "getAppLoadStatus", parameters: { appId: id }, onSuccess: function(r) {
          finish(r.returnValue === true && r.exist === true);
        }, onFailure: function() {
          finish(false);
        } });
      } catch (e) {
        finish(false);
      }
    }
    check(0);
  }
  function close() {
    if (!dialog) return;
    var old = dialog;
    dialog = null;
    var media = old.querySelector("video,audio");
    if (media) {
      media.pause();
      media.removeAttribute("src");
      media.load();
    }
    old.parentNode.removeChild(old);
    C.Focus.setScope(null);
    if (returnFocus && document.documentElement.contains(returnFocus)) C.Focus.focus(returnFocus);
    else C.Focus.focus(document.getElementById("nav-home"));
  }
  function modal(row) {
    if (dialog) close();
    returnFocus = document.activeElement;
    dialog = C.el("div", "usb-overlay");
    dialog.setAttribute("data-volume", row.id);
    dialog.setAttribute("role", "dialog");
    dialog.setAttribute("aria-modal", "true");
    dialog.setAttribute("aria-label", t("\u0645\u0644\u0641\u0627\u062A \u0627\u0644\u0641\u0644\u0627\u0634\u0629", "USB files"));
    dialog.setAttribute("data-no-translate", "");
    document.body.appendChild(dialog);
    C.Focus.setScope(dialog);
    return dialog;
  }
  function open(row) {
    if (C.Prayer && !C.Prayer.allowLaunch()) return;
    if (window.TVNative && TVNative.usbOpen) {
      TVNative.usbOpen(row.id);
      return;
    }
    if (row.mediaApp) {
      try {
        webOS.service.request("luna://com.webos.applicationManager", { method: "launch", parameters: { id: row.mediaApp }, onSuccess: function(r) {
          if (r.returnValue !== true) error();
        }, onFailure: error });
      } catch (e) {
        error();
      }
      return;
    }
    if (!nativeFs()) return error();
    try {
      tizen.filesystem.resolve(row.storage, function(dir) {
        browse(row, dir, []);
      }, error, "r");
    } catch (e) {
      error();
    }
  }
  function button(host, label, action) {
    var b = C.el("button", "usb-button", label);
    b.onclick = action;
    host.appendChild(b);
    return b;
  }
  function browse(row, dir, parents) {
    var box = modal(row), panel = C.el("section", "usb-panel");
    box.appendChild(panel);
    var title = C.el("h2", "", row.title + " / " + (dir.name || ""));
    panel.appendChild(title);
    var controls = C.el("div", "usb-actions");
    panel.appendChild(controls);
    button(controls, t("\u0625\u063A\u0644\u0627\u0642", "Close"), close);
    if (parents.length) button(controls, t("\u0627\u0644\u0645\u062C\u0644\u062F \u0627\u0644\u0633\u0627\u0628\u0642", "Previous folder"), function() {
      var copy = parents.slice(), previous = copy.pop();
      browse(row, previous, copy);
    });
    var status = C.el("p", "", t("\u062C\u0627\u0631\u064D \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0645\u0644\u0641\u0627\u062A\u2026", "Reading files\u2026"));
    panel.appendChild(status);
    var list = C.el("div", "usb-file-list");
    list.setAttribute("data-scroll", "vertical");
    panel.appendChild(list);
    C.Focus.focus(controls.firstChild);
    try {
      dir.listFiles(function(files) {
        if (dialog !== box) return;
        files = files.filter(function(f) {
          return f.isDirectory || /\.(mp4|mkv|avi|mov|webm|m4v|ts|mp3|aac|m4a|wav|flac|ogg|jpe?g|png|webp)$/i.test(f.name);
        }).sort(function(a, b) {
          return a.isDirectory !== b.isDirectory ? a.isDirectory ? -1 : 1 : a.name.localeCompare(b.name);
        });
        status.textContent = files.length ? t("\u0627\u062E\u062A\u0627\u0631 \u0645\u0644\u0641\u064B\u0627 \u0644\u0641\u062A\u062D\u0647. \u062F\u0639\u0645 \u0627\u0644\u0635\u064A\u063A\u0629 \u064A\u0639\u062A\u0645\u062F \u0639\u0644\u0649 \u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646.", "Choose a file. Format support depends on the TV.") : t("\u0644\u0627 \u062A\u0648\u062C\u062F \u0645\u0644\u0641\u0627\u062A \u0648\u0633\u0627\u0626\u0637 \u0645\u062F\u0639\u0648\u0645\u0629 \u0641\u064A \u0647\u0630\u0627 \u0627\u0644\u0645\u062C\u0644\u062F.", "No supported media files in this folder.");
        var page = 0;
        function more() {
          var end = Math.min(files.length, page + 60);
          for (; page < end; page++) (function(file) {
            button(list, (file.isDirectory ? "\u25A3 " : "\u25B6 ") + file.name, function() {
              if (file.isDirectory) browse(row, file, parents.concat([dir]));
              else play(row, file, dir, parents);
            });
          })(files[page]);
          if (page < files.length) {
            var next = button(list, t("\u0639\u0631\u0636 \u0627\u0644\u0645\u0632\u064A\u062F", "Show more"), function() {
              list.removeChild(next);
              more();
            });
          }
        }
        more();
      }, function() {
        status.textContent = t("\u062A\u0639\u0630\u0651\u0631 \u0642\u0631\u0627\u0621\u0629 \u0627\u0644\u0645\u062C\u0644\u062F. \u0631\u0628\u0645\u0627 \u062A\u0645 \u0641\u0635\u0644 \u0627\u0644\u0641\u0644\u0627\u0634\u0629.", "Folder unavailable. The USB drive may have been removed.");
      });
    } catch (e) {
      error();
    }
  }
  function play(row, file, dir, parents) {
    var box = modal(row), panel = C.el("section", "usb-panel usb-play");
    box.appendChild(panel);
    button(panel, t("\u0631\u062C\u0648\u0639 \u0644\u0644\u0645\u0644\u0641\u0627\u062A", "Back to files"), function() {
      browse(row, dir, parents);
    });
    var image = /\.(jpe?g|png|webp)$/i.test(file.name), audio = /\.(mp3|aac|m4a|wav|flac|ogg)$/i.test(file.name), media = document.createElement(image ? "img" : audio ? "audio" : "video");
    media.src = file.toURI();
    if (!image) {
      media.controls = true;
      media.autoplay = true;
    } else media.alt = file.name;
    media.onerror = error;
    panel.appendChild(media);
    C.Focus.focus(panel.firstChild);
  }
  window.addEventListener("load", function() {
    rail = C.el("div", "home-usb-rail");
    rail.id = "home-usb-rail";
    rail.hidden = true;
    rail.setAttribute("data-no-translate", "");
    document.getElementById("view-home").appendChild(rail);
    var changed = C.inputsChanged, label = C.Inputs.label, watch = C.Inputs.watch, load = C.Inputs.load;
    C.Inputs.load = function() {
      load.call(C.Inputs);
      refresh();
    };
    C.inputsChanged = function(state) {
      merge(state);
      changed(state);
    };
    C.Inputs.label = function(source) {
      return source.type === "USB" ? "USB \xB7 " + source.title : label(source);
    };
    C.Inputs.watch = function(source) {
      if (source && source.type === "USB") open(source);
      else watch.call(C.Inputs, source);
    };
    var back = C.back;
    C.back = function() {
      if (dialog) {
        close();
        return;
      }
      back();
    };
    refresh();
    if (nativeFs()) try {
      storageListener = tizen.filesystem.addStorageStateChangeListener(refresh, error);
    } catch (e) {
    }
    ;
  });
  window.addEventListener("morphStorageChanged", refresh);
  window.addEventListener("morphLanguage", paint);
  document.addEventListener("visibilitychange", function() {
    if (!document.hidden) refresh();
  });
  window.addEventListener("unload", function() {
    if (storageListener !== null && nativeFs()) try {
      tizen.filesystem.removeStorageStateChangeListener(storageListener);
    } catch (e) {
    }
  });
  C.USB = { refresh, open, close };
})(window.ClearTV);
