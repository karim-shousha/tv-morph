(function(C) {
  "use strict";
  var P = window.MorphPlus;
  if (!P) return;
  function refresh() {
    document.querySelectorAll(".theme-option").forEach(function(b2) {
      var theme = Array.prototype.filter.call(b2.classList, function(c) {
        return c !== "theme-option" && c !== "plus-locked";
      })[0];
      b2.classList.toggle("plus-locked", !!theme && !P.allowed(theme));
    });
  }
  function fallback() {
    if (!P.allowed(C.settings.theme)) {
      C.write("plusSuspendedSettings", JSON.parse(JSON.stringify(C.settings)));
      C.applyRemoteConfig({ theme: "blue" });
    }
  }
  P.ready.then(function() {
    fallback();
    refresh();
  });
  window.addEventListener("morphViewer", function() {
    fallback();
    refresh();
  });
  window.addEventListener("morphPlus", function() {
    if (P.isActive()) {
      var saved = C.read("plusSuspendedSettings", null);
      if (saved) {
        C.applyRemoteConfig(saved);
        C.write("plusSuspendedSettings", null);
      }
    } else fallback();
    refresh();
  });
  var panel = document.getElementById("setting-theme").closest(".settings-panel"), b = C.el("button", "setting morph-plus-setting", "\u{1F513} Morph TV Plus \xB7 \u0634\u0631\u0627\u0621 \u0627\u0644\u062B\u064A\u0645\u0627\u062A / Buy themes \u2192");
  b.setAttribute("data-no-translate", "");
  var badge = C.el("span", "morph-plus-active-badge");
  badge.id = "tv-plus-active-badge";
  badge.setAttribute("data-no-translate", "");
  badge.hidden = true;
  var brand = document.querySelector(".brand");
  if (brand) brand.appendChild(badge);
  function label() {
    badge.hidden = !P.isActive();
    badge.textContent = MorphLocale.t("\u2713 Plus \u0645\u0641\u0639\u0651\u0644", "\u2713 Plus Active");
    badge.setAttribute("aria-label", badge.textContent);
    b.textContent = P.isActive() ? MorphLocale.t("\u2713 \u0628\u0644\u0633 \u0645\u0641\u0639\u0651\u0644", "\u2713 Morph TV Plus \xB7 Active") : MorphLocale.t("Morph TV Plus \xB7 \u0634\u0631\u0627\u0621 \u0627\u0644\u062B\u064A\u0645\u0627\u062A", "Morph TV Plus \xB7 Buy themes");
  }
  label();
  P.ready.then(label);
  window.addEventListener("morphPlus", label);
  window.addEventListener("morphLanguage", label);
  b.onclick = P.open;
  if (panel) panel.insertBefore(b, panel.firstChild);
  document.addEventListener("click", function(e) {
    var target = e.target.closest && e.target.closest(".theme-option");
    if (target) refresh();
  }, true);
})(window.ClearTV);
