(function(w) {
  "use strict";
  var key = "morph.welcome-support.v1", box = null, previous = null, timer = null;
  var copy = {
    ar: ["\u0623\u0647\u0644\u064B\u0627 \u0628\u064A\u0643 \u0641\u064A Morph TV \u2665", "\u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0627\u0644\u0623\u0633\u0627\u0633\u064A \u0644\u0644\u062A\u0637\u0628\u064A\u0642 \u0645\u062C\u0627\u0646\u064A. \u0644\u0648 \u062D\u0627\u0628\u0628 \u062A\u062F\u0639\u0645\u0646\u0627\u060C \u062A\u0642\u062F\u0631 \u062A\u0633\u0627\u0647\u0645 \u0628\u0627\u0644\u0645\u0628\u0644\u063A \u0627\u0644\u0644\u064A \u062A\u062E\u062A\u0627\u0631\u0647 \u0639\u0644\u0634\u0627\u0646 \u0646\u0637\u0648\u0651\u0631 \u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0648\u0646\u062D\u0633\u0651\u0646 \u062A\u062C\u0631\u0628\u062A\u0643.", "\u0627\u0644\u062F\u0639\u0645 \u0627\u062E\u062A\u064A\u0627\u0631\u064A \u0648\u062F\u0641\u0639\u0629 \u0648\u0627\u062D\u062F\u0629\u060C \u0648\u062A\u0642\u062F\u0631 \u062A\u0628\u062F\u0623 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645 \u0641\u0648\u0631\u064B\u0627. \u0634\u0631\u0627\u0621 \u0645\u0632\u0627\u064A\u0627 \u0628\u0644\u0633 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0629 \u0645\u0646\u0641\u0635\u0644 \u0639\u0646 \u0627\u0644\u062F\u0639\u0645.", "\u0627\u0628\u062F\u0623 \u0627\u0644\u0627\u0633\u062A\u062E\u062F\u0627\u0645", "\u0627\u062F\u0639\u0645 \u0627\u0644\u062A\u0637\u0648\u064A\u0631"],
    en: ["Welcome to Morph TV \u2665", "The core app is free. If you would like to support us, contribute any amount to help us develop the app and improve your experience.", "Support is optional and one-time. You can start using the app immediately. Paid Plus features are purchased separately from donations.", "Start using the app", "Support development"],
    fr: ["Bienvenue sur Morph TV \u2665", "Les fonctions de base sont gratuites. Si vous souhaitez nous soutenir, contribuez du montant de votre choix pour d\xE9velopper l\u2019application et am\xE9liorer votre exp\xE9rience.", "Le soutien est facultatif et ponctuel. Vous pouvez utiliser l\u2019application imm\xE9diatement. Les fonctions Plus payantes sont achet\xE9es s\xE9par\xE9ment des dons.", "Commencer", "Soutenir le d\xE9veloppement"]
  };
  function seen() {
    try {
      return localStorage.getItem(key) === "1";
    } catch (e) {
      return false;
    }
  }
  function paint() {
    if (!box) return;
    var lang = w.MorphLocale ? MorphLocale.get() : "en", row = copy[lang] || copy.en;
    box.dir = lang === "ar" ? "rtl" : "ltr";
    box.querySelector("h2").textContent = row[0];
    box.querySelector(".welcome-message").textContent = row[1];
    box.querySelector(".welcome-note").textContent = row[2];
    box.querySelector("[data-start]").textContent = row[3];
    box.querySelector("[data-support]").textContent = row[4];
  }
  function done() {
    try {
      localStorage.setItem(key, "1");
    } catch (e) {
    }
    if (!box) return;
    box.remove();
    box = null;
    document.removeEventListener("keydown", keys, true);
    if (w.ClearTV && ClearTV.Focus) ClearTV.Focus.setScope(document);
    if (previous && document.documentElement.contains(previous)) previous.focus();
  }
  function keys(e) {
    if (!box) return;
    var code = e.keyCode;
    if (e.key === "Escape" || code === 27 || code === 10009 || code === 461) {
      e.preventDefault();
      e.stopImmediatePropagation();
      done();
      return;
    }
    if (e.key === "Tab" || code >= 37 && code <= 40) {
      e.preventDefault();
      e.stopImmediatePropagation();
      var buttons = box.querySelectorAll("button");
      (document.activeElement === buttons[0] ? buttons[1] : buttons[0]).focus();
    }
  }
  function support() {
    done();
    var button = document.getElementById("setting-support");
    if (button) {
      button.click();
      return;
    }
    if (w.ClearNative && ClearNative.openSupport) {
      ClearNative.openSupport();
      return;
    }
    w.open("https://morphtv.herroshetta.com/#support", "_blank", "noopener");
  }
  function attempt() {
    if (seen() || box) return;
    var busy = Array.prototype.some.call(document.querySelectorAll("[role=dialog],#operation"), function(e) {
      return e.offsetWidth && e.offsetHeight && !e.hidden;
    });
    if (document.hidden || busy) {
      timer = setTimeout(attempt, 500);
      return;
    }
    previous = document.activeElement;
    box = document.createElement("div");
    box.id = "morph-welcome-support";
    box.setAttribute("data-no-translate", "");
    box.innerHTML = '<section class="welcome-card" role="dialog" aria-modal="true" aria-labelledby="welcome-support-title" aria-describedby="welcome-support-message welcome-support-note"><span class="welcome-heart" aria-hidden="true">\u2665</span><h2 id="welcome-support-title"></h2><p class="welcome-message" id="welcome-support-message"></p><p class="welcome-note" id="welcome-support-note"></p><div class="welcome-actions"><button data-start></button><button data-support></button></div></section>';
    document.body.appendChild(box);
    paint();
    box.querySelector("[data-start]").onclick = done;
    box.querySelector("[data-support]").onclick = support;
    document.addEventListener("keydown", keys, true);
    if (w.ClearTV && ClearTV.Focus) ClearTV.Focus.setScope(box);
    box.querySelector("[data-start]").focus();
  }
  w.addEventListener("morphLanguage", paint);
  w.addEventListener("load", function() {
    timer = setTimeout(attempt, 150);
  });
  w.addEventListener("unload", function() {
    clearTimeout(timer);
  });
})(window);
