(function(w) {
  "use strict";
  var overlay, previous, scope, index, pack;
  function ar() {
    return w.MorphLocale ? MorphLocale.get() === "ar" : document.documentElement.lang === "ar";
  }
  function close() {
    if (!overlay) return;
    overlay.remove();
    overlay = null;
    w.removeEventListener("keydown", back, true);
    if (w.ClearTV && ClearTV.Focus) {
      ClearTV.Focus.setScope(scope && scope.isConnected ? scope : document);
      ClearTV.Focus.focus(previous);
    } else if (previous && previous.isConnected) previous.focus();
  }
  function back(e) {
    if ([27, 10009, 461].indexOf(e.keyCode) >= 0) {
      e.preventDefault();
      e.stopImmediatePropagation();
      close();
    }
  }
  function draw() {
    var theme = pack.themes[index], clubs = w.MorphClubs || w.ClearTV && ClearTV.ClubThemes || {}, club = clubs[theme], title = MorphThemeLocale.name(theme);
    overlay.querySelector("h2").textContent = title;
    overlay.querySelector(".theme-preview-count").textContent = index + 1 + " / " + pack.themes.length;
    var image = overlay.querySelector("img"), status = overlay.querySelector(".theme-preview-status");
    status.hidden = true;
    image.onerror = function() {
      status.hidden = false;
      status.textContent = MorphLocale.t("\u062A\u0639\u0630\u0651\u0631 \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0645\u0639\u0627\u064A\u0646\u0629. \u0631\u0627\u062C\u0639 \u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A \u0648\u062D\u0627\u0648\u0644 \u0645\u062C\u062F\u062F\u064B\u0627.", "Preview unavailable. Check your connection and try again.");
    };
    image.alt = title;
    image.src = "https://morphtv.herroshetta.com/theme-previews/" + (theme === "gta6" ? "v144" : "v115") + "/" + (["ar", "en", "fr"].indexOf(MorphLocale.get()) >= 0 ? MorphLocale.get() : "en") + "/" + encodeURIComponent(theme) + ".webp";
  }
  function open(p) {
    if (!p || !p.themes || !p.themes.length) return;
    if (overlay) close();
    pack = p;
    index = 0;
    previous = document.activeElement;
    scope = document.getElementById("theme-packs-overlay") || document.querySelector("#overlay:not([hidden])") || document;
    overlay = document.createElement("div");
    overlay.className = "theme-preview-overlay";
    overlay.setAttribute("data-no-translate", "");
    overlay.innerHTML = '<section class="theme-preview-dialog" role="dialog" aria-modal="true" aria-labelledby="theme-preview-title"><div class="theme-preview-heading"><h2 id="theme-preview-title"></h2><span class="theme-preview-count"></span></div><div class="theme-preview-picture"><img draggable="false"><p class="theme-preview-status" role="status" hidden></p></div><p class="theme-preview-note"></p><div class="theme-preview-actions"><button class="theme-preview-prev"></button><button class="theme-preview-next"></button><button class="theme-preview-buy"></button><button class="theme-preview-close"></button></div></section>';
    overlay.querySelector(".theme-preview-note").textContent = MorphLocale.t("\u0645\u0639\u0627\u064A\u0646\u0629 \u0644\u0644\u0634\u0643\u0644 \u0639\u0644\u0649 \u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646. \u0627\u0644\u062A\u0637\u0628\u064A\u0642\u0627\u062A \u0648\u0627\u0644\u0645\u0648\u0627\u0642\u064A\u062A \u062A\u0648\u0636\u064A\u062D\u064A\u0629. \u062A\u0637\u0628\u064A\u0642 \u0627\u0644\u062B\u064A\u0645 \u0648\u062D\u0641\u0638 \u0627\u0644\u062D\u0632\u0645\u0629 \u0645\u062A\u0627\u062D\u0627\u0646 \u0628\u0639\u062F \u062A\u0641\u0639\u064A\u0644 Plus \u0644\u0644\u062D\u0632\u0645 \u0627\u0644\u0645\u062F\u0641\u0648\u0639\u0629.", "Preview of the TV layout. Apps and times are illustrative. Paid packs require Plus to apply and save.");
    overlay.querySelector(".theme-preview-prev").textContent = MorphLocale.t("\u0627\u0644\u0633\u0627\u0628\u0642", "Previous");
    overlay.querySelector(".theme-preview-next").textContent = MorphLocale.t("\u0627\u0644\u062A\u0627\u0644\u064A", "Next");
    overlay.querySelector(".theme-preview-buy").textContent = MorphLocale.t("\u0641\u062A\u062D Plus", "Unlock Plus");
    overlay.querySelector(".theme-preview-close").textContent = MorphLocale.t("\u0625\u063A\u0644\u0627\u0642", "Close");
    overlay.querySelector(".theme-preview-prev").onclick = function() {
      index = (index + pack.themes.length - 1) % pack.themes.length;
      draw();
    };
    overlay.querySelector(".theme-preview-next").onclick = function() {
      index = (index + 1) % pack.themes.length;
      draw();
    };
    overlay.querySelector(".theme-preview-prev").hidden = overlay.querySelector(".theme-preview-next").hidden = p.themes.length < 2;
    overlay.querySelector(".theme-preview-buy").hidden = !w.MorphPlus || MorphPlus.packAllowed(p);
    overlay.querySelector(".theme-preview-buy").onclick = function() {
      close();
      MorphPlus.open();
    };
    overlay.querySelector(".theme-preview-close").onclick = close;
    overlay.onclick = function(e) {
      if (e.target === overlay) close();
    };
    document.body.appendChild(overlay);
    draw();
    w.addEventListener("keydown", back, true);
    if (w.ClearTV && ClearTV.Focus) {
      ClearTV.Focus.setScope(overlay);
      ClearTV.Focus.first();
    } else overlay.querySelector(".theme-preview-close").focus();
  }
  w.addEventListener("morphLanguage", function() {
    if (overlay) {
      var p = pack, i = index;
      close();
      open(p);
      index = i;
      draw();
    }
  });
  w.MorphThemePreview = { open, close };
})(window);
