(function(w) {
  "use strict";
  var records = /* @__PURE__ */ new WeakMap(), inline = /* @__PURE__ */ new WeakMap(), scheduled = false, last = "", factor = 1;
  function configuration() {
    try {
      if (w.ClearTV && ClearTV.settings) return ClearTV.settings;
      if (parent !== w && parent.ClearTV) return parent.ClearTV.settings;
      var bridge = w.IptvNative || w.RadioNative;
      if (bridge && bridge.settingsJson) return JSON.parse(bridge.settingsJson());
    } catch (e) {
    }
    return {};
  }
  function language() {
    return w.MorphLocale ? MorphLocale.get() : document.documentElement.lang || "en";
  }
  function property(style, key, record) {
    var current = style.getPropertyValue(key), priority = style.getPropertyPriority(key), saved = record[key];
    if (!saved || current !== saved.output) saved = record[key] = { base: current, priority, output: current };
    var match = /^([0-9]+(?:\.[0-9]+)?)px$/.exec(saved.base);
    if (!match) return;
    var output = factor === 1 ? saved.base : Math.round(Number(match[1]) * factor * 100) / 100 + "px";
    if (current !== output) style.setProperty(key, output, saved.priority);
    saved.output = output;
  }
  function declaration(style, cache, key) {
    var record = cache.get(key) || {};
    cache.set(key, record);
    property(style, "font-size", record);
    property(style, "line-height", record);
  }
  function rules(list) {
    for (var i = 0; i < list.length; i++) {
      var rule = list[i];
      if (rule.style) declaration(rule.style, records, rule);
      try {
        if (rule.cssRules) rules(rule.cssRules);
      } catch (e) {
      }
    }
  }
  function apply() {
    scheduled = false;
    var cfg = configuration(), value = cfg[language() === "ar" ? "fontSizeAr" : "fontSizeEn"] || "normal";
    factor = value === "small" ? 0.9 : value === "large" ? 1.1 : 1;
    document.documentElement.setAttribute("data-text-size", value);
    for (var i = 0; i < document.styleSheets.length; i++) try {
      rules(document.styleSheets[i].cssRules);
    } catch (e) {
    }
    Array.prototype.forEach.call(document.querySelectorAll("[style]"), function(node) {
      if (node.style.fontSize || inline.has(node)) declaration(node.style, inline, node);
    });
    if (w.ClearTV && ClearTV.Focus && ClearTV.Focus.invalidate) ClearTV.Focus.invalidate();
  }
  function queue() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(apply);
  }
  var sizeDialog = null, sizeReturn = null;
  function t(ar, en) {
    return w.MorphLocale ? MorphLocale.t(ar, en) : en;
  }
  function sizeName(value) {
    return value === "small" ? t("\u0623\u0635\u063A\u0631", "Smaller") : value === "large" ? t("\u0623\u0643\u0628\u0631", "Larger") : t("\u0627\u0644\u062D\u0627\u0644\u064A", "Current");
  }
  function closePicker() {
    if (!sizeDialog) return;
    sizeDialog.parentNode.removeChild(sizeDialog);
    sizeDialog = null;
    ClearTV.Focus.setScope(null);
    if (sizeReturn && document.documentElement.contains(sizeReturn)) ClearTV.Focus.focus(sizeReturn);
  }
  function picker(key, label, source) {
    if (sizeDialog) closePicker();
    sizeReturn = source;
    var C = w.ClearTV, layer = C.el("div", "text-size-overlay");
    sizeDialog = layer;
    layer.setAttribute("role", "dialog");
    layer.setAttribute("aria-modal", "true");
    layer.setAttribute("data-no-translate", "");
    layer.setAttribute("aria-label", label);
    var panel = C.el("section", "text-size-dialog");
    panel.appendChild(C.el("h2", "", label));
    ["small", "normal", "large"].forEach(function(value) {
      var button = C.el("button", "text-size-option", sizeName(value));
      button.setAttribute("data-text-preset", value);
      button.setAttribute("aria-pressed", String((C.settings[key] || "normal") === value));
      button.onclick = function() {
        var config = {};
        config[key] = value;
        C.applyRemoteConfig(config);
        closePicker();
        C.toast(label + " \xB7 " + sizeName(value));
      };
      panel.appendChild(button);
    });
    var back = C.el("button", "text-size-option", t("\u0631\u062C\u0648\u0639", "Back"));
    back.onclick = closePicker;
    panel.appendChild(back);
    layer.appendChild(panel);
    document.body.appendChild(layer);
    C.Focus.setScope(layer);
    C.Focus.focus(layer.querySelector("[aria-pressed=true]"));
  }
  function tvControls() {
    var C = w.ClearTV, root = document.getElementById("view-settings");
    if (!C || !root) return;
    var host = root.querySelector(".settings-panel");
    if (!host) return;
    var buttons = [];
    [["fontSizeAr", "setting-text-size-ar"], ["fontSizeEn", "setting-text-size-en"]].forEach(function(item) {
      var button = C.el("button", "setting");
      button.id = item[1];
      button.setAttribute("data-no-translate", "");
      button.onclick = function() {
        picker(item[0], item[0] === "fontSizeAr" ? t("\u062D\u062C\u0645 \u0627\u0644\u062E\u0637 \u0627\u0644\u0639\u0631\u0628\u064A", "Arabic text size") : t("\u062D\u062C\u0645 \u0627\u0644\u062E\u0637 \u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A", "English text size"), button);
      };
      host.appendChild(button);
      buttons.push([button, item[0]]);
    });
    function labels() {
      buttons.forEach(function(item) {
        item[0].textContent = (item[1] === "fontSizeAr" ? t("\u062D\u062C\u0645 \u0627\u0644\u062E\u0637 \u0627\u0644\u0639\u0631\u0628\u064A", "Arabic text size") : t("\u062D\u062C\u0645 \u0627\u0644\u062E\u0637 \u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A", "English text size")) + " \xB7 " + sizeName(C.settings[item[1]] || "normal") + " \u2192";
      });
    }
    labels();
    w.addEventListener("morphLanguage", labels);
    w.addEventListener("morphViewer", labels);
    w.addEventListener("morphTextSize", labels);
    var back = C.back;
    C.back = function() {
      if (sizeDialog) {
        closePicker();
        return;
      }
      back();
    };
    if (C.SettingsNav) C.SettingsNav.refresh();
  }
  function mount() {
    var C = w.ClearTV;
    if (C && C.applyRemoteConfig) {
      var previous = C.applyRemoteConfig;
      C.applyRemoteConfig = function(value) {
        var result = previous(value);
        if (result && result.applied) {
          w.dispatchEvent(new Event("morphTextSize"));
          try {
            if (w.TVNative && TVNative.saveSettings) TVNative.saveSettings(JSON.stringify({ fontSizeAr: C.settings.fontSizeAr || "normal", fontSizeEn: C.settings.fontSizeEn || "normal" }));
          } catch (e) {
          }
          queue();
        }
        return result;
      };
    }
    tvControls();
    apply();
    var observer = new MutationObserver(function(changes) {
      if (changes.some(function(change) {
        return Array.prototype.some.call(change.addedNodes, function(node) {
          return node.nodeType === 1 && (node.tagName === "STYLE" || node.tagName === "LINK" || node.hasAttribute("style") || node.querySelector("[style]"));
        });
      })) queue();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
  w.MorphTextSize = { apply };
  w.addEventListener("load", mount);
  ["morphLanguage", "morphViewer", "focus", "storage"].forEach(function(name) {
    w.addEventListener(name, queue);
  });
})(window);
