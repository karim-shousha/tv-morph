(function() {
  "use strict";
  function apply() {
    var mode = "light", low = false;
    try {
      if (parent !== window && parent.ClearTV && parent.ClearTV.Performance) {
        low = parent.ClearTV.Performance.isLight();
        mode = low ? "light" : "full";
      } else {
        var bridge = window.IptvNative || window.RadioNative;
        if (bridge && bridge.deviceInfo) low = JSON.parse(bridge.deviceInfo()).lowMemory === true;
        if (bridge && bridge.performanceMode) mode = bridge.performanceMode() || "light";
        else mode = JSON.parse(localStorage.getItem("cleartv.performanceMode") || '"light"');
      }
    } catch (e) {
    }
    var tv = (navigator.userAgent || "").match(/Tizen[ \/]([0-9]+)/i);
    low = low || !!(tv && Number(tv[1]) <= 6) || !!(navigator.deviceMemory && navigator.deviceMemory <= 2) || !!(navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2);
    document.body.classList.toggle("light-mode", mode === "light" || mode !== "full" && low);
  }
  var css = document.createElement("style");
  css.textContent = "body.light-mode *,body.light-mode *:before,body.light-mode *:after{animation:none!important;transition:none!important;backdrop-filter:none!important;-webkit-backdrop-filter:none!important;scroll-behavior:auto!important}body.light-mode .glow{display:none!important}body.light-mode .tile,body.light-mode .tile:focus,body.light-mode .station,body.light-mode .station:focus,body.light-mode .portal-grid button{filter:none!important;box-shadow:none!important;transform:none!important}body.light-mode button:focus{outline:3px solid var(--media-accent,#91e8ff)!important;outline-offset:3px!important}";
  document.head.appendChild(css);
  apply();
  window.addEventListener("focus", apply);
  window.addEventListener("storage", apply);
  try {
    if (parent !== window) parent.addEventListener("morphPerformance", apply);
  } catch (e) {
  }
})();
