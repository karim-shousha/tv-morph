(function(C, w) {
  "use strict";
  var ID = "local.tvmorph.tv.kids", STREAM = "https://stream-201526.castr.net/647cfcb338286342d6a88374/live_4e29439011a111f1b5f455e47a6a4e9a/index.m3u8";
  var root = null, video = null, hls = null, av = null, avObject = null, previous = null, pauseButton, muteButton, status, attempt = 0, timeout = null, library = null, paused = false, muted = false, restoreMute = null, changedMute = false, adhanResume = false;
  function t(ar, en) {
    return w.MorphLocale ? MorphLocale.t(ar, en) : en;
  }
  function title() {
    return t("\u0639\u0627\u0644\u0645 \u0627\u0644\u0635\u063A\u0627\u0631", "Kids World");
  }
  function showStatus(text) {
    if (!status) return;
    status.textContent = text;
    status.hidden = !text;
  }
  function labels() {
    if (pauseButton) pauseButton.textContent = paused ? "\u25B6 " + t("\u062A\u0634\u063A\u064A\u0644", "Play") : "\u2161 " + t("\u0625\u064A\u0642\u0627\u0641 \u0645\u0624\u0642\u062A", "Pause");
    if (muteButton) muteButton.textContent = muted ? "\u266A " + t("\u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0635\u0648\u062A", "Sound on") : "\u266A " + t("\u0643\u062A\u0645 \u0627\u0644\u0635\u0648\u062A", "Mute");
  }
  function playing() {
    clearTimeout(timeout);
    showStatus("");
    paused = false;
    labels();
  }
  function failure() {
    clearTimeout(timeout);
    showStatus(t("\u0627\u0644\u0628\u062B \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u062D\u0627\u0644\u064A\u064B\u0627. \u062C\u0631\u0651\u0628 \u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629.", "The live stream is unavailable. Try again."));
  }
  function stopEngine() {
    attempt++;
    clearTimeout(timeout);
    if (hls) {
      hls.destroy();
      hls = null;
    }
    if (video) {
      video.onplaying = video.onwaiting = video.onerror = video.onended = null;
      video.pause();
      video.removeAttribute("src");
      video.load();
    }
    if (av) {
      try {
        av.stop();
        av.close();
      } catch (e) {
      }
      av = null;
    }
    if (avObject && avObject.parentNode) avObject.parentNode.removeChild(avObject);
    avObject = null;
  }
  function libraryReady() {
    if (w.Hls) return Promise.resolve();
    if (library) return library;
    library = new Promise(function(resolve, reject) {
      var script = document.createElement("script");
      script.src = "vendor/hls-1.5.18.light.min.js";
      script.onload = function() {
        resolve();
      };
      script.onerror = function() {
        library = null;
        reject(Error("player unavailable"));
      };
      document.head.appendChild(script);
    });
    return library;
  }
  function startHtml(run) {
    if (!root || run !== attempt) return;
    video.hidden = false;
    video.muted = muted;
    video.onplaying = function() {
      if (run === attempt) playing();
    };
    video.onwaiting = function() {
      if (run === attempt) showStatus(t("\u062C\u0627\u0631\u064D \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0628\u062B\u2026", "Loading the live stream\u2026"));
    };
    video.onerror = function() {
      if (run === attempt) failure();
    };
    video.onended = function() {
      if (run === attempt) failure();
    };
    function play() {
      var result = video.play();
      if (result && result.catch) result.catch(function() {
        if (root && run === attempt) showStatus(t("\u0627\u0636\u063A\u0637 \u062A\u0634\u063A\u064A\u0644 \u0644\u0628\u062F\u0621 \u0627\u0644\u0645\u0634\u0627\u0647\u062F\u0629.", "Press Play to start watching."));
      });
    }
    if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = STREAM;
      play();
      return;
    }
    libraryReady().then(function() {
      if (!root || run !== attempt) return;
      if (!w.Hls || !Hls.isSupported()) {
        failure();
        return;
      }
      hls = new Hls({ enableWorker: true, maxBufferLength: 20, backBufferLength: 10, maxBufferSize: 2e7, manifestLoadingMaxRetry: 2, levelLoadingMaxRetry: 2 });
      hls.on(Hls.Events.MEDIA_ATTACHED, function() {
        if (hls) hls.loadSource(STREAM);
      });
      hls.on(Hls.Events.MANIFEST_PARSED, play);
      hls.on(Hls.Events.ERROR, function(event, data) {
        if (run === attempt && data.fatal) failure();
      });
      hls.attachMedia(video);
    }, failure);
  }
  function start() {
    stopEngine();
    var run = attempt;
    if (!root) return;
    paused = false;
    labels();
    showStatus(t("\u062C\u0627\u0647\u0632\u064A\u0646 \u0644\u0644\u0645\u0634\u0627\u0647\u062F\u0629\u061F \u0628\u0646\u0641\u062A\u062D \u0627\u0644\u0628\u062B\u2026", "Ready to watch? Connecting\u2026"));
    timeout = setTimeout(function() {
      if (run === attempt) failure();
    }, 2e4);
    if (w.webapis && webapis.avplay) {
      try {
        let fallback = function() {
          if (!root || run !== attempt) return;
          try {
            av.stop();
            av.close();
          } catch (e) {
          }
          av = null;
          if (avObject && avObject.parentNode) avObject.parentNode.removeChild(avObject);
          avObject = null;
          startHtml(run);
        };
        av = webapis.avplay;
        av.open(STREAM);
        video.hidden = true;
        avObject = document.createElement("object");
        avObject.type = "application/avplayer";
        avObject.className = "kids-av-object";
        root.querySelector(".kids-stage").insertBefore(avObject, video);
        var rect = root.querySelector(".kids-stage").getBoundingClientRect(), body = document.body.getBoundingClientRect(), scale = w.MorphScreenFit ? MorphScreenFit.scale() : 1;
        av.setDisplayRect(Math.round((rect.left - body.left) / scale), Math.round((rect.top - body.top) / scale), Math.round(rect.width / scale), Math.round(rect.height / scale));
        try {
          av.setDisplayMethod("PLAYER_DISPLAY_MODE_LETTER_BOX");
        } catch (e) {
        }
        av.setListener({ onbufferingstart: function() {
          if (run === attempt) showStatus(t("\u062C\u0627\u0631\u064D \u062A\u062D\u0645\u064A\u0644 \u0627\u0644\u0628\u062B\u2026", "Loading\u2026"));
        }, onbufferingcomplete: function() {
          if (run === attempt) playing();
        }, onerror: fallback, onstreamcompleted: failure });
        av.prepareAsync(function() {
          if (!root || run !== attempt) return;
          try {
            av.play();
            playing();
          } catch (e) {
            fallback();
          }
        }, fallback);
        return;
      } catch (e) {
        if (av) try {
          av.close();
        } catch (ignore) {
        }
        av = null;
      }
    }
    startHtml(run);
  }
  function pause() {
    if (!root || paused) return;
    try {
      if (av) av.pause();
      else video.pause();
      paused = true;
      labels();
    } catch (e) {
    }
  }
  function resume() {
    if (!root || C.Prayer && !C.Prayer.allowLaunch()) return;
    try {
      if (av) {
        av.play();
        playing();
      } else {
        var p = video.play();
        if (p && p.catch) p.catch(failure);
        paused = false;
        labels();
      }
    } catch (e) {
      failure();
    }
  }
  function close() {
    if (!root) return;
    var old = root;
    root = null;
    stopEngine();
    if (changedMute && restoreMute !== null) try {
      webapis.audiocontrol.setMute(restoreMute);
    } catch (e) {
    }
    changedMute = false;
    restoreMute = null;
    if (C.ParentControls && C.ParentControls.mediaStopped) C.ParentControls.mediaStopped();
    if (w.TVNative && TVNative.kidsState) TVNative.kidsState(false);
    old.parentNode.removeChild(old);
    video = null;
    pauseButton = muteButton = status = null;
    adhanResume = false;
    C.Focus.setScope(null);
    if (previous && document.documentElement.contains(previous)) C.Focus.focus(previous);
    else if (C.restoreHomeDock) C.restoreHomeDock();
  }
  function button(host, text, action, id) {
    var b = C.el("button", "kids-control", text);
    if (id) b.id = id;
    b.onclick = action;
    host.appendChild(b);
    return b;
  }
  function open() {
    if (root) return;
    if (C.Prayer && !C.Prayer.allowLaunch()) return;
    if (C.ParentControls && C.ParentControls.mediaGuard && !C.ParentControls.mediaGuard(ID, open)) return;
    w.dispatchEvent(new Event("morphAudioExclusive"));
    previous = document.activeElement;
    root = C.el("section", "kids-player");
    root.id = "kids-player";
    root.setAttribute("role", "dialog");
    root.setAttribute("aria-modal", "true");
    root.setAttribute("aria-label", title());
    root.setAttribute("data-no-translate", "");
    var header = C.el("header", "kids-header"), name = C.el("div", "kids-name"), icon = document.createElement("img");
    icon.src = "assets/tvm-kids.svg";
    icon.alt = "";
    name.appendChild(icon);
    var text = C.el("div");
    text.appendChild(C.el("h1", "", title()));
    text.appendChild(C.el("p", "", t("\u062D\u0643\u0627\u064A\u0627\u062A \u0648\u0623\u0644\u0648\u0627\u0646\u2026 \u0641\u064A \u0645\u0643\u0627\u0646 \u0648\u0627\u062D\u062F", "Stories and colors, all together")));
    name.appendChild(text);
    header.appendChild(name);
    header.appendChild(C.el("span", "kids-live", "\u25CF " + t("\u0645\u0628\u0627\u0634\u0631", "LIVE")));
    root.appendChild(header);
    var stage = C.el("div", "kids-stage");
    video = document.createElement("video");
    video.setAttribute("playsinline", "");
    video.setAttribute("webkit-playsinline", "");
    video.preload = "auto";
    stage.appendChild(video);
    status = C.el("p", "kids-status");
    status.setAttribute("role", "status");
    stage.appendChild(status);
    root.appendChild(stage);
    var controls = C.el("div", "kids-controls");
    pauseButton = button(controls, "", function() {
      if (paused) resume();
      else pause();
    }, "kids-pause");
    muteButton = button(controls, "", function() {
      muted = !muted;
      if (av && w.webapis && webapis.audiocontrol) {
        try {
          if (restoreMute === null) restoreMute = webapis.audiocontrol.isMute();
          webapis.audiocontrol.setMute(muted);
          changedMute = true;
        } catch (e) {
        }
      } else video.muted = muted;
      labels();
    }, "kids-mute");
    button(controls, "\u21BB " + t("\u0625\u0639\u0627\u062F\u0629 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629", "Try again"), start, "kids-retry");
    button(controls, "\u2302 " + t("\u0631\u062C\u0648\u0639 \u0644\u0644\u0645\u0646\u0632\u0644", "Back Home"), close, "kids-close");
    root.appendChild(controls);
    document.body.appendChild(root);
    C.Focus.setScope(root);
    C.Focus.focus(pauseButton);
    if (C.ParentControls && C.ParentControls.mediaStarted) C.ParentControls.mediaStarted(ID);
    if (w.TVNative && TVNative.kidsState) TVNative.kidsState(true);
    muted = false;
    start();
    var ids = C.read("recent", []).filter(function(id) {
      return id !== ID;
    });
    ids.unshift(ID);
    C.write("recent", ids.slice(0, 5));
  }
  function ensure() {
    if (!C.Catalog.get(ID)) C.Catalog.apps.push({ id: ID, name: title() });
    C.Catalog.get(ID).name = title();
    if (!C.read("kidsHomePinnedV1", false)) {
      var pins = C.getRemoteState().pins.slice();
      if (pins.indexOf(ID) < 0) pins.push(ID);
      C.setRemotePins(pins);
      C.write("kidsHomePinnedV1", true);
    }
    C.refreshAppViews();
  }
  function pinLabels() {
    var button2 = document.getElementById("setting-kids-home");
    if (button2) button2.textContent = title() + " \xB7 " + (C.getRemoteState().pins.indexOf(ID) >= 0 ? t("\u0638\u0627\u0647\u0631\u0629 \u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0645 \xB7 \u0625\u062E\u0641\u0627\u0621", "On Home \xB7 Hide") : t("\u0645\u062E\u0641\u064A\u0629 \xB7 \u0625\u0638\u0647\u0627\u0631 \u0639\u0644\u0649 \u0627\u0644\u0647\u0648\u0645", "Hidden \xB7 Show on Home"));
  }
  function togglePin() {
    var pins = C.getRemoteState().pins.slice(), index = pins.indexOf(ID);
    if (index >= 0) pins.splice(index, 1);
    else pins.push(ID);
    C.setRemotePins(pins);
    C.write("kidsHomePinnedV1", true);
    pinLabels();
  }
  w.addEventListener("load", function() {
    ensure();
    var host = document.querySelector("#view-settings .settings-panel"), setting = C.el("button", "setting");
    setting.id = "setting-kids-home";
    setting.setAttribute("data-no-translate", "");
    setting.onclick = togglePin;
    if (host) host.appendChild(setting);
    pinLabels();
    if (C.SettingsNav) C.SettingsNav.refresh();
    if (C.Remote) {
      var remoteKey = C.Remote.key;
      C.Remote.key = function(key) {
        if (root && (key === "HOME" || key === "RETURN")) {
          close();
          return { sent: true };
        }
        var code = { PLAY: 415, PAUSE: 19, STOP: 413 }[key];
        if (root && code) {
          var e = new Event("keydown", { bubbles: true, cancelable: true });
          Object.defineProperty(e, "keyCode", { value: code });
          document.dispatchEvent(e);
          return { sent: true };
        }
        return remoteKey.call(C.Remote, key);
      };
    }
    var savePins = C.setRemotePins;
    C.setRemotePins = function(ids) {
      var result = savePins(ids);
      pinLabels();
      return result;
    };
    var back = C.back;
    C.back = function() {
      if (root) {
        close();
        return;
      }
      back();
    };
    var show = C.showView;
    C.showView = function() {
      if (root) close();
      return show.apply(C, arguments);
    };
  });
  w.addEventListener("morphLanguage", function() {
    if (root) close();
    ensure();
    pinLabels();
  });
  w.addEventListener("morphViewer", function() {
    close();
    ensure();
    pinLabels();
  });
  document.addEventListener("visibilitychange", function() {
    if (document.hidden) close();
  });
  w.addEventListener("morphAudioExclusive", function() {
    if (root && !paused) {
      adhanResume = true;
      pause();
    }
  });
  w.addEventListener("morphAdhanEnded", function() {
    if (root && adhanResume) {
      adhanResume = false;
      resume();
      if (!document.querySelector("#prayer-break-overlay:not([hidden])")) {
        C.Focus.setScope(root);
        C.Focus.focus(pauseButton);
      }
    }
  });
  document.addEventListener("keydown", function(e) {
    if (!root) return;
    var prayer = document.querySelector("#prayer-adhan-overlay:not([hidden]),#prayer-break-overlay:not([hidden])");
    if (prayer && prayer.offsetHeight) return;
    var key = e.keyCode;
    if (key === 27 || key === 10009 || key === 461 || key === 413) {
      e.preventDefault();
      e.stopImmediatePropagation();
      close();
    } else if (key === 415 || key === 19 || key === 10252) {
      e.preventDefault();
      e.stopImmediatePropagation();
      if (key === 415) resume();
      else if (key === 19) pause();
      else if (paused) resume();
      else pause();
    }
  }, true);
  C.Kids = { id: ID, open, close, togglePin, isOpen: function() {
    return !!root;
  }, stream: STREAM };
})(window.ClearTV, window);
