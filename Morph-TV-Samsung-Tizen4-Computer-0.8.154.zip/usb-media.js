(function(C) {
  "use strict";
  var groups = { video: "mp4 m4v mkv avi mov webm ts tp trp mts m2ts mpg mpeg mpe m2v vob vro wmv asf flv 3gp 3g2 divx ogv rm rmvb", audio: "mp3 aac m4a wav flac ogg oga opus wma aif aiff ac3 eac3 dts ape alac", image: "jpg jpeg png webp bmp gif heic heif avif tif tiff" };
  function kind(name) {
    var ext = String(name || "").toLowerCase().split(".").pop(), keys = Object.keys(groups);
    for (var i = 0; i < keys.length; i++) if ((" " + groups[keys[i]] + " ").indexOf(" " + ext + " ") >= 0) return keys[i];
    return "";
  }
  function words() {
    var rows = { ar: ["\u0631\u062C\u0648\u0639 \u0644\u0644\u0645\u0644\u0641\u0627\u062A", "\u0625\u064A\u0642\u0627\u0641 / \u062A\u0634\u063A\u064A\u0644", "\u2212\u0661\u0660 \u062B", "+\u0661\u0660 \u062B", "\u0645\u0644\u0627\u0621\u0645\u0629 / \u0645\u0644\u0621 \u0627\u0644\u0634\u0627\u0634\u0629", "\u062C\u0627\u0631\u064A \u0641\u062A\u062D \u0627\u0644\u0645\u0644\u0641\u2026", "\u062A\u0639\u0630\u0651\u0631 \u062A\u0634\u063A\u064A\u0644 \u0627\u0644\u0645\u0644\u0641 \u0628\u0647\u0630\u0627 \u0627\u0644\u0645\u0634\u063A\u0651\u0644. \u062F\u0639\u0645 \u0627\u0644\u062A\u0631\u0645\u064A\u0632 \u064A\u0639\u062A\u0645\u062F \u0639\u0644\u0649 \u0627\u0644\u062A\u0644\u0641\u0632\u064A\u0648\u0646.", "\u0627\u0644\u0645\u0644\u0641 \u062C\u0627\u0647\u0632"], en: ["Back to files", "Play / Pause", "\u221210 sec", "+10 sec", "Fit / Fill screen", "Opening file\u2026", "This player could not play the file. Codec support depends on the TV.", "Ready"], fr: ["Retour aux fichiers", "Lecture / Pause", "\u221210 s", "+10 s", "Adapter / Remplir", "Ouverture\u2026", "Lecture impossible. Les codecs d\xE9pendent du t\xE9l\xE9viseur.", "Pr\xEAt"], zh: ["\u8FD4\u56DE\u6587\u4EF6", "\u64AD\u653E / \u6682\u505C", "\u221210\u79D2", "+10\u79D2", "\u9002\u5E94 / \u586B\u6EE1\u5C4F\u5E55", "\u6B63\u5728\u6253\u5F00\u2026", "\u65E0\u6CD5\u64AD\u653E\u6B64\u6587\u4EF6\uFF0C\u7F16\u89E3\u7801\u5668\u652F\u6301\u53D6\u51B3\u4E8E\u7535\u89C6\u3002", "\u5DF2\u5C31\u7EEA"], ja: ["\u30D5\u30A1\u30A4\u30EB\u3078\u623B\u308B", "\u518D\u751F / \u4E00\u6642\u505C\u6B62", "\u221210\u79D2", "+10\u79D2", "\u5168\u4F53\u8868\u793A / \u5168\u753B\u9762", "\u8AAD\u307F\u8FBC\u307F\u4E2D\u2026", "\u518D\u751F\u3067\u304D\u307E\u305B\u3093\u3002\u30B3\u30FC\u30C7\u30C3\u30AF\u5BFE\u5FDC\u306F\u30C6\u30EC\u30D3\u306B\u3088\u3063\u3066\u7570\u306A\u308A\u307E\u3059\u3002", "\u6E96\u5099\u5B8C\u4E86"] };
    return rows[window.MorphLocale ? MorphLocale.get() : "en"] || rows.en;
  }
  function open(box, uri, name, type, back) {
    var text = words(), av = null, media = null, object = null, dead = false, full = false, tick = null, prepared = false, loading = false;
    box.classList.add("usb-player");
    var stage = C.el("div", "usb-stage"), bar = C.el("section", "usb-player-controls"), title = C.el("strong", "usb-player-title", name), status = C.el("p", "usb-player-status", text[5]), times = C.el("span", "usb-time", "00:00 / --:--"), progress = C.el("div", "usb-progress"), fill = C.el("div"), actions = C.el("div", "usb-actions");
    progress.appendChild(fill);
    bar.appendChild(title);
    bar.appendChild(status);
    bar.appendChild(progress);
    bar.appendChild(times);
    bar.appendChild(actions);
    box.appendChild(stage);
    box.appendChild(bar);
    status.setAttribute("role", "status");
    function button(label, fn) {
      var b = C.el("button", "usb-button", label);
      b.onclick = fn;
      actions.appendChild(b);
      return b;
    }
    function fail() {
      if (dead) return;
      status.textContent = text[6];
      bar.classList.add("usb-playback-error");
    }
    function stamp(ms) {
      var s = Math.max(0, Math.floor(ms / 1e3));
      return (s >= 3600 ? Math.floor(s / 3600) + ":" : "") + String(Math.floor(s / 60) % 60).padStart(2, "0") + ":" + String(s % 60).padStart(2, "0");
    }
    function paint(ms) {
      if (dead) return;
      try {
        var duration = av ? av.getDuration() : media && isFinite(media.duration) ? media.duration * 1e3 : 0, pos = typeof ms === "number" ? ms : av ? av.getCurrentTime() : media ? media.currentTime * 1e3 : 0;
        times.textContent = stamp(pos) + " / " + (duration > 0 ? stamp(duration) : "--:--");
        fill.style.width = duration > 0 ? Math.min(100, pos / duration * 100) + "%" : "0";
      } catch (ignore) {
      }
    }
    function toggle() {
      try {
        if (av) {
          if (!prepared) return;
          av.getState() === "PLAYING" ? av.pause() : av.play();
        } else if (media) {
          if (media.paused) {
            var promise = media.play();
            if (promise && promise.catch) promise.catch(fail);
          } else media.pause();
        }
      } catch (e) {
        fail();
      }
    }
    function seek(delta) {
      try {
        if (av && prepared) {
          var end = av.getDuration();
          av.seekTo(Math.max(0, Math.min(Math.max(0, end - 1e3), av.getCurrentTime() + delta * 1e3)));
        } else if (media && isFinite(media.duration)) media.currentTime = Math.max(0, Math.min(Math.max(0, media.duration - 0.1), media.currentTime + delta));
        paint();
      } catch (ignore) {
      }
    }
    function size() {
      full = !full;
      if (media) media.style.objectFit = full ? "cover" : "contain";
      try {
        if (av && prepared) av.setDisplayMethod(full ? "PLAYER_DISPLAY_MODE_FULL_SCREEN" : "PLAYER_DISPLAY_MODE_LETTER_BOX");
      } catch (ignore) {
      }
    }
    var backButton = button(text[0], back);
    if (type !== "image") {
      button(text[1], toggle);
      button(text[2], function() {
        seek(-10);
      });
      button(text[3], function() {
        seek(10);
      });
    }
    if (type !== "audio") button(text[4], size);
    function html() {
      if (dead || media) return;
      document.body.classList.remove("usb-native-playing");
      if (object) {
        object.parentNode.removeChild(object);
        object = null;
      }
      try {
        if (av) av.close();
      } catch (ignore) {
      }
      av = null;
      media = document.createElement(type === "image" ? "img" : type === "audio" ? "audio" : "video");
      media.className = "usb-media";
      media.src = uri;
      if (type === "image") {
        media.alt = name;
        media.onload = function() {
          status.textContent = text[7];
        };
      } else {
        media.autoplay = true;
        media.controls = false;
        media.preload = "metadata";
        media.onloadedmetadata = function() {
          status.textContent = text[7];
          paint();
        };
        media.ontimeupdate = function() {
          paint();
        };
        media.onplay = function() {
          status.textContent = text[7];
        };
        media.onended = function() {
          paint();
        };
      }
      media.onerror = fail;
      stage.appendChild(media);
    }
    if ((type === "video" || type === "audio") && window.webapis && webapis.avplay) {
      try {
        if (window.SamsungMedia && SamsungMedia.radioStop) SamsungMedia.radioStop();
        document.body.classList.add("usb-native-playing");
        av = webapis.avplay;
        object = document.createElement("object");
        object.type = "application/avplayer";
        object.className = "usb-av-object";
        stage.appendChild(object);
        av.open(uri);
        av.setDisplayRect(0, 0, 1920, 1080);
        av.setListener({ oncurrentplaytime: paint, onstreamcompleted: function() {
          if (!dead) status.textContent = text[7];
        }, onerror: function() {
          if (!prepared) html();
          else fail();
        } });
        av.prepareAsync(function() {
          if (dead || !av) return;
          prepared = true;
          try {
            av.setDisplayMethod("PLAYER_DISPLAY_MODE_LETTER_BOX");
            av.play();
            status.textContent = text[7];
          } catch (e) {
            html();
          }
        }, html);
      } catch (e) {
        html();
      }
    } else html();
    function keys(e) {
      var k = e.keyCode;
      if ([10252, 179, 32, 415, 19, 417, 412].indexOf(k) < 0) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      if (k === 417) seek(10);
      else if (k === 412) seek(-10);
      else toggle();
    }
    function hidden() {
      if (!document.hidden) return;
      try {
        if (av && prepared && av.getState() === "PLAYING") av.pause();
        if (media && media.pause) media.pause();
      } catch (ignore) {
      }
    }
    box.addEventListener("keydown", keys, true);
    document.addEventListener("visibilitychange", hidden);
    C.Focus.focus(backButton);
    return function() {
      if (dead) return;
      dead = true;
      document.body.classList.remove("usb-native-playing");
      box.removeEventListener("keydown", keys, true);
      document.removeEventListener("visibilitychange", hidden);
      if (media && media.pause) {
        media.pause();
        media.removeAttribute("src");
        media.load();
      }
      if (av) {
        try {
          av.stop();
        } catch (ignore) {
        }
        try {
          av.close();
        } catch (ignore) {
        }
      }
      av = null;
    };
  }
  C.USBMedia = { kind, open };
})(window.ClearTV);
