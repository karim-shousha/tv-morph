(function(w) {
  "use strict";
  var records = /* @__PURE__ */ new WeakMap(), inline = /* @__PURE__ */ new WeakMap(), scheduled = false, last = "", factor = 1;
  function configuration() {
    try {
      if (w.ClearTV && ClearTV.settings) return ClearTV.settings;
      if (parent !== w && parent.ClearTV) return parent.ClearTV.settings;
      var bridge = w.IptvNative || w.RadioNative;
      if (bridge && bridge.settingsJson) return JSON.parse(bridge.settingsJson());
    } catch (e) {
    }
    return {};
  }
  function language() {
    return w.MorphLocale ? MorphLocale.get() : document.documentElement.lang || "en";
  }
  function property(style, key, record) {
    var current = style.getPropertyValue(key), priority = style.getPropertyPriority(key), saved = record[key];
    if (!saved || current !== saved.output) saved = record[key] = { base: current, priority, output: current };
    var match = /^([0-9]+(?:\.[0-9]+)?)px$/.exec(saved.base);
    if (!match) return;
    var output = factor === 1 ? saved.base : Math.round(Number(match[1]) * factor * 100) / 100 + "px";
    if (current !== output) style.setProperty(key, output, saved.priority);
    saved.output = output;
  }
  function declaration(style, cache, key) {
    var record = cache.get(key) || {};
    cache.set(key, record);
    property(style, "font-size", record);
    property(style, "line-height", record);
  }
  function rules(list) {
    for (var i = 0; i < list.length; i++) {
      var rule = list[i];
      if (rule.style) declaration(rule.style, records, rule);
      try {
        if (rule.cssRules) rules(rule.cssRules);
      } catch (e) {
      }
    }
  }
  function apply() {
    scheduled = false;
    var cfg = configuration(), value = cfg[language() === "ar" ? "fontSizeAr" : "fontSizeEn"] || "normal";
    factor = value === "small" ? 0.9 : value === "large" ? 1.1 : 1;
    document.documentElement.setAttribute("data-text-size", value);
    for (var i = 0; i < document.styleSheets.length; i++) try {
      rules(document.styleSheets[i].cssRules);
    } catch (e) {
    }
    Array.prototype.forEach.call(document.querySelectorAll("[style]"), function(node) {
      if (node.style.fontSize || inline.has(node)) declaration(node.style, inline, node);
    });
    if (w.ClearTV && ClearTV.Focus && ClearTV.Focus.invalidate) ClearTV.Focus.invalidate();
  }
  function queue() {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(apply);
  }
  function mount() {
    var C = w.ClearTV;
    if (C && C.applyRemoteConfig) {
      var previous = C.applyRemoteConfig;
      C.applyRemoteConfig = function(value) {
        var result = previous(value);
        if (result && result.applied) {
          try {
            if (w.TVNative && TVNative.saveSettings) TVNative.saveSettings(JSON.stringify({ fontSizeAr: C.settings.fontSizeAr || "normal", fontSizeEn: C.settings.fontSizeEn || "normal" }));
          } catch (e) {
          }
          queue();
        }
        return result;
      };
    }
    apply();
    var observer = new MutationObserver(function(changes) {
      if (changes.some(function(change) {
        return Array.prototype.some.call(change.addedNodes, function(node) {
          return node.nodeType === 1 && (node.tagName === "STYLE" || node.tagName === "LINK" || node.hasAttribute("style") || node.querySelector("[style]"));
        });
      })) queue();
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });
  }
  w.MorphTextSize = { apply };
  w.addEventListener("load", mount);
  ["morphLanguage", "morphViewer", "focus", "storage"].forEach(function(name) {
    w.addEventListener(name, queue);
  });
})(window);
