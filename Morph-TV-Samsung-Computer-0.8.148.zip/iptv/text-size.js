(function(w) {
  "use strict";
  var records = /* @__PURE__ */ new WeakMap(), scheduled = false, factor = 1, observer = null, observing = false, nativeStamp = "";
  function configuration() {
    try {
      if (w.ClearTV && ClearTV.settings) return ClearTV.settings;
      if (parent !== w && parent.ClearTV) return parent.ClearTV.settings;
      var bridge = w.IptvNative || w.RadioNative;
      if (bridge && bridge.settingsJson) return JSON.parse(bridge.settingsJson());
    } catch (e) {
    }
    return {};
  }
  function language() {
    return w.MorphLocale ? MorphLocale.get() : (document.documentElement.lang || "en").split("-")[0];
  }
  function observe() {
    if (!observer || observing) return;
    observer.observe(document.documentElement, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ["style", "class", "hidden", "lang", "dir", "data-ui-mode", "data-ui-home"] });
    observing = true;
  }
  function restore(node, record) {
    ["font-size", "line-height"].forEach(function(key) {
      var item = record[key], style = node.style;
      if (!item) return;
      if (style.getPropertyValue(key) === item.output && style.getPropertyPriority(key) === "important") {
        if (item.value) style.setProperty(key, item.value, item.priority);
        else style.removeProperty(key);
      }
    });
  }
  function textNode(node) {
    if (node.closest("script,style,noscript,svg,.app-icon,.plus-icon,.ui-icon,[aria-hidden=true]")) return false;
    if (/^(INPUT|TEXTAREA|SELECT)$/.test(node.tagName)) return true;
    for (var i = 0; i < node.childNodes.length; i++) if (node.childNodes[i].nodeType === 3 && /\S/.test(node.childNodes[i].nodeValue || "")) return true;
    return false;
  }
  function apply() {
    scheduled = false;
    if (observer) {
      observer.disconnect();
      observing = false;
    }
    try {
      var cfg = configuration(), stamp = JSON.stringify([w.ClearTV && ClearTV.Profiles ? ClearTV.Profiles.active() : "default", cfg.fontSizeAr || "normal", cfg.fontSizeEn || "normal"]);
      if (w.ClearTV && w.TVNative && TVNative.saveSettings && stamp !== nativeStamp) {
        nativeStamp = stamp;
        try {
          TVNative.saveSettings(JSON.stringify({ fontSizeAr: cfg.fontSizeAr || "normal", fontSizeEn: cfg.fontSizeEn || "normal" }));
        } catch (nativeError) {
        }
      }
      var value = cfg[language() === "ar" ? "fontSizeAr" : "fontSizeEn"] || "normal";
      factor = value === "small" ? 0.9 : value === "large" ? 1.1 : 1;
      document.documentElement.setAttribute("data-text-size", value);
      var all = Array.prototype.slice.call(document.querySelectorAll("body *")), targets = [];
      all.forEach(function(node) {
        var record = records.get(node);
        if (record) restore(node, record);
      });
      all.forEach(function(node) {
        if (!node.getClientRects().length || !textNode(node)) return;
        var style = getComputedStyle(node), size2 = parseFloat(style.fontSize), line2 = parseFloat(style.lineHeight);
        if (!isFinite(size2) || size2 <= 0) return;
        var record = {};
        ["font-size", "line-height"].forEach(function(key) {
          record[key] = { value: node.style.getPropertyValue(key), priority: node.style.getPropertyPriority(key), output: "" };
        });
        records.set(node, record);
        targets.push({ node, record, size: size2, line: line2 });
      });
      targets.forEach(function(item) {
        if (factor === 1) return;
        var size2 = Math.round(item.size * factor * 100) / 100 + "px";
        item.record["font-size"].output = size2;
        item.node.style.setProperty("font-size", size2, "important");
        if (isFinite(item.line)) {
          var line2 = Math.round(item.line * factor * 100) / 100 + "px";
          item.record["line-height"].output = line2;
          item.node.style.setProperty("line-height", line2, "important");
        }
      });
      var title = document.querySelector("#view-home .club-hero h1"), entry = title && records.get(title);
      if (title && entry && title.clientHeight > 0) {
        var size = parseFloat(getComputedStyle(title).fontSize), line = parseFloat(getComputedStyle(title).lineHeight), ratio = isFinite(line) ? line / size : 1.3;
        while (title.scrollHeight > title.clientHeight + 2 && size > 36) {
          size -= 2;
          entry["font-size"].output = size + "px";
          title.style.setProperty("font-size", size + "px", "important");
          entry["line-height"].output = size * ratio + "px";
          title.style.setProperty("line-height", size * ratio + "px", "important");
        }
      }
      if (w.ClearTV && ClearTV.Focus && ClearTV.Focus.invalidate) ClearTV.Focus.invalidate();
    } finally {
      observe();
    }
  }
  function queue() {
    if (scheduled) return;
    scheduled = true;
    (w.requestAnimationFrame || function(fn) {
      setTimeout(fn, 16);
    })(apply);
  }
  var sizeDialog = null, sizeReturn = null;
  function t(ar, en) {
    return w.MorphLocale ? MorphLocale.t(ar, en) : en;
  }
  function sizeName(value) {
    return value === "small" ? t("\u0623\u0635\u063A\u0631", "Smaller") : value === "large" ? t("\u0623\u0643\u0628\u0631", "Larger") : t("\u0627\u0644\u062D\u0627\u0644\u064A", "Current");
  }
  function closePicker() {
    if (!sizeDialog) return;
    sizeDialog.parentNode.removeChild(sizeDialog);
    sizeDialog = null;
    ClearTV.Focus.setScope(null);
    if (sizeReturn && document.documentElement.contains(sizeReturn)) ClearTV.Focus.focus(sizeReturn);
  }
  function picker(key, label, source) {
    if (sizeDialog) closePicker();
    sizeReturn = source;
    var C = w.ClearTV, layer = C.el("div", "text-size-overlay");
    sizeDialog = layer;
    layer.setAttribute("role", "dialog");
    layer.setAttribute("aria-modal", "true");
    layer.setAttribute("data-no-translate", "");
    layer.setAttribute("aria-label", label);
    var panel = C.el("section", "text-size-dialog");
    panel.appendChild(C.el("h2", "", label));
    ["small", "normal", "large"].forEach(function(value) {
      var button = C.el("button", "text-size-option", sizeName(value));
      button.setAttribute("data-text-preset", value);
      button.setAttribute("aria-pressed", String((C.settings[key] || "normal") === value));
      button.onclick = function() {
        var config = {};
        config[key] = value;
        C.applyRemoteConfig(config);
        closePicker();
        C.toast(label + " \xB7 " + sizeName(value));
      };
      panel.appendChild(button);
    });
    var back = C.el("button", "text-size-option", t("\u0631\u062C\u0648\u0639", "Back"));
    back.onclick = closePicker;
    panel.appendChild(back);
    layer.appendChild(panel);
    document.body.appendChild(layer);
    C.Focus.setScope(layer);
    C.Focus.focus(layer.querySelector("[aria-pressed=true]"));
  }
  function tvControls() {
    var C = w.ClearTV, root = document.getElementById("view-settings");
    if (!C || !root) return;
    var host = root.querySelector(".settings-panel");
    if (!host) return;
    var buttons = [];
    [["fontSizeAr", "setting-text-size-ar"], ["fontSizeEn", "setting-text-size-en"]].forEach(function(item) {
      var button = C.el("button", "setting");
      button.id = item[1];
      button.setAttribute("data-no-translate", "");
      button.onclick = function() {
        picker(item[0], item[0] === "fontSizeAr" ? t("\u062D\u062C\u0645 \u0627\u0644\u062E\u0637 \u0627\u0644\u0639\u0631\u0628\u064A", "Arabic text size") : t("\u062D\u062C\u0645 \u0627\u0644\u062E\u0637 \u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A", "English text size"), button);
      };
      host.appendChild(button);
      buttons.push([button, item[0]]);
    });
    function labels() {
      buttons.forEach(function(item) {
        item[0].textContent = (item[1] === "fontSizeAr" ? t("\u062D\u062C\u0645 \u0627\u0644\u062E\u0637 \u0627\u0644\u0639\u0631\u0628\u064A", "Arabic text size") : t("\u062D\u062C\u0645 \u0627\u0644\u062E\u0637 \u0627\u0644\u0625\u0646\u062C\u0644\u064A\u0632\u064A", "English text size")) + " \xB7 " + sizeName(C.settings[item[1]] || "normal") + " \u2192";
      });
    }
    labels();
    w.addEventListener("morphLanguage", labels);
    w.addEventListener("morphViewer", labels);
    w.addEventListener("morphTextSize", labels);
    var back = C.back;
    C.back = function() {
      if (sizeDialog) {
        closePicker();
        return;
      }
      back();
    };
    if (C.SettingsNav) C.SettingsNav.refresh();
  }
  function mount() {
    var C = w.ClearTV;
    if (C && C.applyRemoteConfig) {
      var previous = C.applyRemoteConfig;
      C.applyRemoteConfig = function(value) {
        var result = previous(value);
        if (result && result.applied) {
          w.dispatchEvent(new Event("morphTextSize"));
          try {
            if (w.TVNative && TVNative.saveSettings) TVNative.saveSettings(JSON.stringify({ fontSizeAr: C.settings.fontSizeAr || "normal", fontSizeEn: C.settings.fontSizeEn || "normal" }));
          } catch (e) {
          }
          queue();
        }
        return result;
      };
    }
    tvControls();
    observer = new MutationObserver(function(changes) {
      if (changes.some(function(change) {
        var node = change.target.nodeType === 1 ? change.target : change.target.parentElement;
        if (!node) return false;
        if (node.tagName === "STYLE" || node.tagName === "LINK") return true;
        if (node.closest("script,svg,.app-icon,.plus-icon,.ui-icon")) return false;
        if (change.type === "attributes") {
          if (change.attributeName === "class") return node === document.body || node === document.documentElement || node.classList.contains("view");
          if (change.attributeName === "style") return node === document.body || node === document.documentElement || records.has(node) || !!node.style.fontSize || !!node.style.lineHeight;
          return true;
        }
        if (change.type === "childList") return Array.prototype.some.call(change.addedNodes, function(n) {
          return n.nodeType === 3 || n.nodeType === 1 && !n.matches("svg,.app-icon,.plus-icon,.ui-icon");
        }) || change.removedNodes.length > 0;
        return true;
      })) queue();
    });
    apply();
    try {
      if (parent !== w) ["morphTextSize", "morphViewer", "morphLanguage"].forEach(function(name) {
        parent.addEventListener(name, queue);
      });
    } catch (ignore) {
    }
  }
  w.MorphTextSize = { apply };
  if (document.readyState === "complete") mount();
  else w.addEventListener("load", mount);
  ["morphLanguage", "morphViewer", "focus", "storage"].forEach(function(name) {
    w.addEventListener(name, queue);
  });
})(window);
