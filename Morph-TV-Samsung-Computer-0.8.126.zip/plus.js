(function(w) {
  "use strict";
  var origin = "https://morphtv.herroshetta.com", free = ["blue", "emerald", "violet", "ahly", "zamalek", "ismaily", "saudi-national", "egypt-national"], active = false, token = "", device = "", overlay, previous;
  function read(k) {
    try {
      return localStorage.getItem("morph.plus." + k) || "";
    } catch (e) {
      return "";
    }
  }
  function write(k, v) {
    try {
      localStorage.setItem("morph.plus." + k, v);
      return true;
    } catch (e) {
      return false;
    }
  }
  function api(path, data) {
    return new Promise(function(resolve, reject) {
      var x = new XMLHttpRequest();
      x.open("POST", origin + "/api/plus/" + path, true);
      x.setRequestHeader("Content-Type", "application/json");
      x.timeout = 12e3;
      x.onload = function() {
        try {
          var value = JSON.parse(x.responseText);
          if (x.status !== 200) throw Error(value.error || "unavailable");
          resolve(value);
        } catch (e) {
          reject(e);
        }
      };
      x.onerror = x.ontimeout = function() {
        reject(Error("network_unavailable"));
      };
      x.send(JSON.stringify(data));
    });
  }
  function random() {
    if (!w.crypto || !w.crypto.getRandomValues) throw Error("secure_random_unavailable");
    var b = new Uint8Array(24);
    w.crypto.getRandomValues(b);
    return Array.prototype.map.call(b, function(n) {
      return ("0" + n.toString(16)).slice(-2);
    }).join("");
  }
  function changed() {
    w.dispatchEvent(new Event("morphPlus"));
  }
  token = read("token");
  device = read("device");
  var scope = w.MorphPlusClient === "studio" ? "studio" : "tv";
  var ready = token ? api("status", { token }).then(function(v) {
    active = v.active === true && v.scope === scope;
    changed();
  }, function() {
    active = false;
    changed();
  }) : Promise.resolve();
  function allowed(theme) {
    return free.indexOf(theme) >= 0 || active;
  }
  function packAllowed(pack) {
    return active || pack.themes.every(function(t) {
      return free.indexOf(t) >= 0;
    });
  }
  function ar() {
    return document.documentElement.lang === "ar";
  }
  function close() {
    if (!overlay) return;
    overlay.remove();
    overlay = null;
    document.removeEventListener("keydown", back, true);
    var C = w.ClearTV;
    if (C && C.Focus) {
      C.Focus.setScope(previous && previous.closest("#theme-packs-overlay,#overlay") || document);
      if (previous) C.Focus.focus(previous);
    } else if (previous) previous.focus();
  }
  function back(e) {
    if (e.keyCode === 27 || e.keyCode === 10009 || e.keyCode === 461) {
      e.preventDefault();
      e.stopImmediatePropagation();
      close();
    }
  }
  function open() {
    if (overlay) return;
    previous = document.activeElement;
    overlay = document.createElement("div");
    overlay.className = "morph-plus-overlay";
    overlay.setAttribute("data-no-translate", "");
    overlay.innerHTML = '<section class="morph-plus-dialog" role="dialog" aria-modal="true" aria-labelledby="plus-title"><small>MORPH TV PLUS</small><h2 id="plus-title"></h2><p class="plus-description"></p><div class="plus-plans"><article><strong>Plus \xB7 $5 USD</strong><span class="plus-single"></span></article><article><strong>Plus Family \xB7 $10 USD</strong><span class="plus-family"></span></article></div><div class="plus-purchase"><img class="plus-purchase-qr" width="150" height="150" alt="Scan to open Morph TV Plus purchase page"><div><button class="plus-buy"></button><p class="plus-purchase-hint"></p></div></div><p class="plus-address">morphtv.herroshetta.com/plus.html</p><label for="plus-code"></label><input id="plus-code" type="text" maxlength="38" autocomplete="off" spellcheck="false" dir="ltr"><p class="plus-status" role="status"></p><div class="plus-actions"><button class="plus-activate"></button><button class="plus-close"></button></div><small class="plus-note"></small></section>';
    document.body.appendChild(overlay);
    var q = function(s) {
      return overlay.querySelector(s);
    };
    q("h2").textContent = MorphLocale.t("\u0627\u0641\u062A\u062D \u0643\u0644 \u0627\u0644\u062B\u064A\u0645\u0627\u062A \u0645\u0639 Plus", "Unlock every theme with Plus");
    q(".plus-description").textContent = MorphLocale.t("\u0627\u0644\u0623\u0632\u0631\u0642 \u0648\u0627\u0644\u0623\u062E\u0636\u0631 \u0627\u0644\u0633\u0627\u062D\u0644\u064A \u0648\u0623\u0648\u0631\u0648\u0631\u0627 \u0648\u0627\u0644\u0623\u0647\u0644\u064A \u0648\u0627\u0644\u0632\u0645\u0627\u0644\u0643 \u0648\u0627\u0644\u0625\u0633\u0645\u0627\u0639\u064A\u0644\u064A \u0648\u062B\u064A\u0645\u0627 \u0627\u0644\u0633\u0639\u0648\u062F\u064A\u0629 \u0648\u0645\u0635\u0631 \u0627\u0644\u0648\u0637\u0646\u064A\u0627\u0646 \u0645\u062C\u0627\u0646\u064B\u0627. \u0628\u0627\u0642\u064A \u0627\u0644\u062D\u0632\u0645 \u0648\u062A\u0639\u062F\u064A\u0644\u0627\u062A \u0627\u0644\u0645\u0638\u0647\u0631 \u0627\u0644\u0645\u062A\u0642\u062F\u0645\u0629 \u0636\u0645\u0646 Plus.", "Blue, Coastal and Aurora, Al Ahly, Zamalek, Ismaily and the Saudi and Egyptian patriotic themes are free. More packs and advanced appearance controls are included in Plus.");
    q(".plus-single").textContent = MorphLocale.t("\u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \xB7 \u062A\u0644\u0641\u0632\u064A\u0648\u0646 \u0648\u0627\u062D\u062F", "One-time purchase \xB7 1 TV");
    q(".plus-family").textContent = MorphLocale.t("\u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629 \xB7 \u0665 \u062A\u0644\u0641\u0632\u064A\u0648\u0646\u0627\u062A \xB7 \u0646\u0642\u0644 \u0627\u0644\u062A\u0641\u0639\u064A\u0644", "One-time purchase \xB7 5 TVs \xB7 transfer activation");
    q("label").textContent = MorphLocale.t("\u0643\u0648\u062F \u0627\u0644\u062A\u0641\u0639\u064A\u0644 \u0628\u0639\u062F \u062A\u0623\u0643\u064A\u062F \u0627\u0644\u0634\u0631\u0627\u0621", "Activation code after confirmed purchase");
    q(".plus-activate").textContent = MorphLocale.t("\u062A\u0641\u0639\u064A\u0644 Plus", "Activate Plus");
    q(".plus-close").textContent = MorphLocale.t("\u0631\u062C\u0648\u0639", "Back");
    q(".plus-note").textContent = MorphLocale.t("\u0627\u0644\u062F\u0639\u0645 \u0648\u0627\u0644\u062A\u0628\u0631\u0639\u0627\u062A \u0644\u0627 \u062A\u0641\u0639\u0651\u0644 Plus. \u064A\u0644\u0632\u0645 \u0627\u0644\u0625\u0646\u062A\u0631\u0646\u062A \u0644\u0644\u062A\u062D\u0642\u0642 \u0639\u0646\u062F \u0641\u062A\u062D \u0627\u0644\u062A\u0637\u0628\u064A\u0642 \u0648\u062A\u0646\u0632\u064A\u0644 \u0627\u0644\u062D\u0632\u0645.", "Donations do not activate Plus. Internet is required for startup verification and pack downloads.");
    q(".plus-close").onclick = close;
    q(".plus-purchase-qr").src = scope === "studio" ? "plus-purchase.webp" : "assets/plus-purchase.webp";
    q(".plus-buy").textContent = MorphLocale.t("\u0634\u0631\u0627\u0621 Plus \u0648\u0641\u062A\u062D \u0627\u0644\u062B\u064A\u0645\u0627\u062A \u2197", "Buy Plus and unlock themes \u2197");
    q(".plus-purchase-hint").textContent = MorphLocale.t("\u0627\u0641\u062A\u062D \u0635\u0641\u062D\u0629 \u0627\u0644\u0634\u0631\u0627\u0621\u060C \u0623\u0648 \u0627\u0645\u0633\u062D QR \u0628\u0627\u0644\u0645\u0648\u0628\u0627\u064A\u0644. \u0627\u0644\u062F\u0641\u0639 \u0645\u0631\u0629 \u0648\u0627\u062D\u062F\u0629.", "Open the purchase page or scan with your phone. One-time payment.");
    q(".plus-buy").onclick = function() {
      window.open(origin + "/plus.html", "_blank", "noopener");
    };
    q(".plus-activate").onclick = function() {
      var code = q("input").value.trim().toUpperCase();
      if (!/^MORPH-[A-Z2-7]{32}$/.test(code)) {
        q(".plus-status").textContent = MorphLocale.t("\u0631\u0627\u062C\u0639 \u0643\u0648\u062F \u0627\u0644\u062A\u0641\u0639\u064A\u0644.", "Check the activation code.");
        return;
      }
      var b = q(".plus-activate");
      b.disabled = true;
      q(".plus-status").textContent = MorphLocale.t("\u062C\u0627\u0631\u064D \u0627\u0644\u062A\u062D\u0642\u0642\u2026", "Verifying\u2026");
      try {
        if (!device) {
          device = random();
          if (!write("device", device)) throw Error("storage_unavailable");
        }
      } catch (e) {
        b.disabled = false;
        q(".plus-status").textContent = MorphLocale.t("\u0627\u0644\u062A\u062E\u0632\u064A\u0646 \u0623\u0648 \u0627\u0644\u062A\u0634\u0641\u064A\u0631 \u063A\u064A\u0631 \u0645\u062A\u0627\u062D \u0639\u0644\u0649 \u0647\u0630\u0627 \u0627\u0644\u062C\u0647\u0627\u0632.", "Secure storage or random generation is unavailable.");
        return;
      }
      api(scope === "studio" ? "studio" : "activate", { code, device, name: read("name") || "Morph TV" }).then(function(v) {
        if (v.active !== true || v.scope !== scope || !v.token) throw Error("activation_failed");
        if (!write("token", v.token)) throw Error("storage_unavailable");
        token = v.token;
        active = true;
        changed();
        q(".plus-status").textContent = MorphLocale.t("\u062A\u0645 \u062A\u0641\u0639\u064A\u0644 Plus.", "Plus activated.");
      }, function() {
        q(".plus-status").textContent = MorphLocale.t("\u062A\u0639\u0630\u0651\u0631 \u0627\u0644\u062A\u0641\u0639\u064A\u0644. \u0631\u0627\u062C\u0639 \u0627\u0644\u0627\u062A\u0635\u0627\u0644 \u0648\u0627\u0644\u0643\u0648\u062F \u0648\u0639\u062F\u062F \u0627\u0644\u0623\u062C\u0647\u0632\u0629 \u0645\u0646 \u0635\u0641\u062D\u0629 \u0627\u0644\u0634\u0631\u0627\u0621.", "Activation failed. Check connection, code and device limit on the purchase page.");
      }).then(function() {
        b.disabled = false;
      }, function() {
        b.disabled = false;
        q(".plus-status").textContent = MorphLocale.t("\u062A\u0639\u0630\u0651\u0631 \u062D\u0641\u0638 \u0627\u0644\u062A\u0641\u0639\u064A\u0644. \u0631\u0627\u062C\u0639 \u0627\u0644\u062A\u062E\u0632\u064A\u0646 \u0648\u062D\u0627\u0648\u0644 \u062A\u0641\u0639\u064A\u0644\u0647 \u0628\u0627\u0644\u0643\u0648\u062F \u0646\u0641\u0633\u0647.", "Unable to save activation. Check storage and activate again with the same code.");
      });
    };
    document.addEventListener("keydown", back, true);
    var C = w.ClearTV;
    if (C && C.Focus) {
      C.Focus.setScope(overlay);
      C.Focus.focus(q("input"));
    } else q("input").focus();
  }
  w.MorphPlus = { ready, freeThemes: free, isActive: function() {
    return active;
  }, allowed, packAllowed, open, token: function() {
    return active ? token : "";
  }, advancedKeys: ["cardWidth", "customTitle", "customSubtitle", "logoImage", "artImage", "backgroundStart", "backgroundEnd", "cardColor", "textColor", "accent", "backgroundImages", "slideshowEnabled", "slideshowSeconds", "glassOpacity", "iconTint", "highlightColor", "artOffsetX", "artOffsetY", "textOffsetX", "textOffsetY", "logoOffsetX", "logoOffsetY", "heroTitleSize", "heroSubtitleSize", "heroArtSize", "heroLogoSize"] };
})(window);
