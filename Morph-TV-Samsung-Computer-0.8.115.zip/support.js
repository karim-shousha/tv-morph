(function() {
  "use strict";
  window.addEventListener("load", function() {
    var panel = document.getElementById("setting-theme").closest(".settings-panel");
    if (!panel) return;
    var button = document.createElement("button");
    button.className = "setting";
    function paint() {
      button.textContent = MorphLocale.t("\u2665 \u0627\u062F\u0639\u0645 \u0645\u0648\u0631\u0641 \u062A\u064A \u0641\u064A \u2192", "\u2665 Support Morph TV \u2192");
    }
    paint();
    window.addEventListener("morphLanguage", paint);
    button.setAttribute("data-no-translate", "");
    panel.appendChild(button);
    button.onclick = function() {
      var C = window.ClearTV, previous = document.activeElement, overlay = document.createElement("div");
      overlay.className = "overlay";
      overlay.innerHTML = '<section class="modal support-modal" role="dialog" aria-modal="true" aria-label="Support Morph TV"><h2>\u0627\u062F\u0639\u0645 Morph TV \u2665</h2><p>Optional one-time support for app development. Choose your amount.</p><div class="support-codes"><div><strong>Stripe</strong><img src="assets/support-stripe.webp" width="300" height="300" alt="Scan with your phone to support Morph TV through Stripe"></div><div><strong>PayPal</strong><img src="assets/support-paypal.webp" width="300" height="300" alt="Scan to support Morph TV through PayPal"></div></div><p>Scan with your phone to open a support page.</p><div class="support-actions"><button data-pay="stripe">\u0627\u0644\u062F\u0639\u0645 \u0639\u0628\u0631 Stripe \u2197</button><button data-pay="paypal">\u0627\u0644\u062F\u0639\u0645 \u0639\u0628\u0631 PayPal \u2197</button><button class="primary" data-close>Close</button></div></section>';
      document.body.appendChild(overlay);
      var close = overlay.querySelector("[data-close]");
      overlay.querySelectorAll("[data-pay]").forEach(function(b) {
        b.onclick = function() {
          window.open(b.getAttribute("data-pay") === "stripe" ? "https://donate.stripe.com/9B66oI2xb4yCdar0VB6EU03" : "https://www.paypal.com/donate/?business=lynkomentor%40gmail.com&currency_code=CAD", "_blank", "noopener");
        };
      });
      C.Focus.setScope(overlay);
      C.Focus.focus(close);
      function done() {
        overlay.remove();
        C.Focus.setScope(document);
        C.Focus.focus(previous);
        document.removeEventListener("keydown", back, true);
      }
      function back(e) {
        if (e.key === "Escape" || e.keyCode === 27 || e.keyCode === 10009 || e.keyCode === 461) {
          e.preventDefault();
          e.stopImmediatePropagation();
          done();
        }
      }
      close.onclick = done;
      document.addEventListener("keydown", back, true);
    };
  });
})();
