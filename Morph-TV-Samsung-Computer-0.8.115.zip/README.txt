Morph TV 0.8.115 / Samsung Tizen 4.0+
Prepared TV Web project; not a USB installer.
Import in Tizen Studio, create your own Samsung TV certificate including your TV DUID, connect the TV in Developer Mode, then Run As > Tizen Web Application.
Keep your original author certificate for updates. No private certificate is included.
Guide: https://morphtv.herroshetta.com/install.html
Physical N5300 testing pending.
