(function(C, w) {
  "use strict";
  var editor = null, returnKey = "", previous = null;
  var rows = { ar: ["\u062A\u063A\u064A\u064A\u0631 \u0627\u0633\u0645 \u0627\u0644\u0645\u062F\u062E\u0644", "\u0627\u0643\u062A\u0628 \u0627\u0633\u0645\u064B\u0627 \u0645\u062B\u0644 \u0631\u0633\u064A\u0641\u0631 \u0627\u0644\u062F\u0634 \u0623\u0648 \u0628\u0644\u0627\u064A\u0633\u062A\u064A\u0634\u0646", "\u062D\u0641\u0638", "\u0627\u0644\u0627\u0633\u0645 \u0627\u0644\u0623\u0635\u0644\u064A", "\u0625\u0644\u063A\u0627\u0621"], en: ["Rename input", "Enter a name, such as Satellite receiver or PlayStation", "Save", "Original name", "Cancel"], fr: ["Renommer l\u2019entr\xE9e", "Exemple : r\xE9cepteur satellite ou PlayStation", "Enregistrer", "Nom d\u2019origine", "Annuler"], zh: ["\u91CD\u547D\u540D\u8F93\u5165\u6E90", "\u4F8B\u5982\uFF1A\u536B\u661F\u63A5\u6536\u5668\u6216 PlayStation", "\u4FDD\u5B58", "\u539F\u59CB\u540D\u79F0", "\u53D6\u6D88"], ja: ["\u5165\u529B\u540D\u3092\u5909\u66F4", "\u4F8B\uFF1A\u885B\u661F\u653E\u9001\u53D7\u4FE1\u6A5F\u3001PlayStation", "\u4FDD\u5B58", "\u5143\u306E\u540D\u524D", "\u30AD\u30E3\u30F3\u30BB\u30EB"] };
  function words() {
    return rows[w.MorphLocale ? MorphLocale.get() : "en"] || rows.en;
  }
  function key(source) {
    return String(source.id || source.type + ":" + source.number);
  }
  function names() {
    var value = C.read("inputNames", {});
    return value && typeof value === "object" && !Array.isArray(value) ? value : {};
  }
  var label = C.Inputs.label;
  C.Inputs.label = function(source) {
    var custom = names()[key(source)];
    return typeof custom === "string" && custom.trim() ? custom.trim() : label(source);
  };
  function close() {
    if (!editor) return;
    editor.parentNode.removeChild(editor);
    editor = null;
    C.keyboardVisible = false;
    C.Focus.setScope(null);
    var target = Array.prototype.filter.call(document.querySelectorAll("[data-rename-source]"), function(b) {
      return b.getAttribute("data-rename-source") === returnKey;
    })[0];
    if (target && target.offsetWidth) C.Focus.focus(target);
    else if (previous && document.documentElement.contains(previous)) C.Focus.focus(previous);
  }
  function rename(source) {
    if (editor) close();
    var text = words();
    returnKey = key(source);
    previous = document.activeElement;
    editor = C.el("div", "input-name-overlay");
    editor.setAttribute("data-no-translate", "");
    var panel = C.el("section", "input-name-panel");
    panel.setAttribute("role", "dialog");
    panel.setAttribute("aria-modal", "true");
    panel.setAttribute("aria-labelledby", "input-name-title");
    panel.appendChild(C.el("h2", "", text[0])).id = "input-name-title";
    panel.appendChild(C.el("p", "", text[1]));
    var input = document.createElement("input");
    input.id = "input-custom-name";
    input.type = "text";
    input.maxLength = 40;
    input.value = names()[returnKey] || "";
    input.placeholder = label(source);
    input.setAttribute("aria-label", text[0]);
    panel.appendChild(input);
    function action(title, fn) {
      var b = C.el("button", "usb-button", title);
      b.onclick = fn;
      panel.appendChild(b);
      return b;
    }
    function save(value) {
      var next = names();
      if (value) next[returnKey] = value;
      else delete next[returnKey];
      C.write("inputNames", next);
      close();
      if (C.inputsChanged) C.inputsChanged(C.Inputs.state);
    }
    action(text[2], function() {
      save(input.value.replace(/[\u0000-\u001f]/g, "").trim().slice(0, 40));
    }).id = "input-name-save";
    action(text[3], function() {
      save("");
    }).id = "input-name-reset";
    action(text[4], close);
    editor.appendChild(panel);
    document.body.appendChild(editor);
    C.Focus.setScope(editor);
    C.Focus.focus(input);
  }
  function decorate() {
    var grid = document.getElementById("input-grid");
    if (!grid) return;
    Array.prototype.forEach.call(grid.querySelectorAll("button.source-card"), function(card) {
      if (card.parentNode.classList.contains("input-source-group")) return;
      var id = card.getAttribute("data-source"), source = C.Inputs.state.sources.filter(function(s) {
        return String(s.id || s.type + s.number) === id;
      })[0];
      if (!source || ["HDMI", "AV", "COMP", "USB"].indexOf(source.type) < 0) return;
      var group = C.el("div", "input-source-group");
      card.parentNode.insertBefore(group, card);
      group.appendChild(card);
      var edit = C.el("button", "input-rename", words()[0]);
      edit.setAttribute("data-no-translate", "");
      edit.setAttribute("data-rename-source", key(source));
      edit.onclick = function() {
        rename(source);
      };
      group.appendChild(edit);
    });
  }
  var changed = C.inputsChanged;
  C.inputsChanged = function(state) {
    var focused = document.activeElement.getAttribute("data-rename-source");
    if (changed) changed(state);
    decorate();
    if (focused && !editor) {
      var next = Array.prototype.filter.call(document.querySelectorAll("[data-rename-source]"), function(b) {
        return b.getAttribute("data-rename-source") === focused;
      })[0];
      if (next) C.Focus.focus(next);
    }
  };
  var back = C.back;
  C.back = function() {
    if (editor) {
      close();
      return;
    }
    return back.apply(C, arguments);
  };
  w.addEventListener("load", decorate);
  w.addEventListener("morphViewer", function() {
    close();
    if (C.inputsChanged) C.inputsChanged(C.Inputs.state);
  });
  w.addEventListener("morphLanguage", function() {
    close();
    if (C.inputsChanged) C.inputsChanged(C.Inputs.state);
  });
  C.InputNames = { key, rename };
})(window.ClearTV, window);
