(function(C) {
  "use strict";
  if (!window.TVNative || typeof TVNative.checkAppUpdate !== "function") return;
  var button, latest = "";
  function words() {
    return { ar: ["\u062A\u062D\u062F\u064A\u062B \u0627\u0644\u062A\u0637\u0628\u064A\u0642", "\u0641\u062D\u0635 \u0627\u0644\u062A\u062D\u062F\u064A\u062B\u0627\u062A", "\u062A\u062D\u062F\u064A\u062B \u0645\u062A\u0627\u062D \xB7 "], en: ["App update", "Check for updates", "Update available \xB7 "], fr: ["Mise \xE0 jour", "Rechercher une mise \xE0 jour", "Mise \xE0 jour disponible \xB7 "], zh: ["\u5E94\u7528\u66F4\u65B0", "\u68C0\u67E5\u66F4\u65B0", "\u6709\u53EF\u7528\u66F4\u65B0 \xB7 "], ja: ["\u30A2\u30D7\u30EA\u66F4\u65B0", "\u66F4\u65B0\u3092\u78BA\u8A8D", "\u66F4\u65B0\u304C\u3042\u308A\u307E\u3059 \xB7 "] }[MorphLocale.get()] || ["App update", "Check for updates", "Update available \xB7 "];
  }
  function paint() {
    if (!button) return;
    var w = words();
    button.querySelector("span").textContent = w[0];
    button.querySelector("strong").textContent = latest ? w[2] + latest : w[1];
  }
  function init() {
    var host = document.querySelector("#settings-category-general .settings-panel") || document.querySelector("#view-settings .settings-panel:last-child");
    if (!host) return;
    button = C.el("button", "setting");
    button.id = "setting-app-update";
    button.dataset.noTranslate = "";
    button.appendChild(C.el("span"));
    button.appendChild(C.el("strong"));
    button.onclick = function() {
      TVNative.checkAppUpdate(true);
    };
    host.appendChild(button);
    paint();
    setTimeout(function() {
      TVNative.checkAppUpdate(false);
    }, 15e3);
  }
  window.addEventListener("morphAppUpdate", function(e) {
    latest = e.detail && e.detail.version || "";
    paint();
  });
  window.addEventListener("morphLanguage", paint);
  if (document.readyState === "complete") init();
  else window.addEventListener("load", init);
})(window.ClearTV);
