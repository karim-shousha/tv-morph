(function(C) {
  "use strict";
  var rows = { en: ["Performance mode", "Automatic", "Light", "Full", "Light: the same interface with reduced effects."], ar: ["\u0648\u0636\u0639 \u0627\u0644\u0623\u062F\u0627\u0621", "\u062A\u0644\u0642\u0627\u0626\u064A", "\u062E\u0641\u064A\u0641", "\u0643\u0627\u0645\u0644", "\u062E\u0641\u064A\u0641: \u0646\u0641\u0633 \u0627\u0644\u0648\u0627\u062C\u0647\u0629 \u0628\u0645\u0624\u062B\u0631\u0627\u062A \u0623\u0642\u0644."], fr: ["Mode de performance", "Automatique", "L\xE9ger", "Complet", "L\xE9ger : m\xEAme interface, effets r\xE9duits."], zh: ["\u6027\u80FD\u6A21\u5F0F", "\u81EA\u52A8", "\u8F7B\u91CF", "\u5B8C\u6574", "\u8F7B\u91CF\uFF1A\u76F8\u540C\u754C\u9762\uFF0C\u51CF\u5C11\u7279\u6548\u3002"], ja: ["\u30D1\u30D5\u30A9\u30FC\u30DE\u30F3\u30B9", "\u81EA\u52D5", "\u8EFD\u91CF", "\u901A\u5E38", "\u8EFD\u91CF\uFF1A\u540C\u3058\u753B\u9762\u3067\u52B9\u679C\u3092\u6291\u3048\u307E\u3059\u3002"] }, modes = ["auto", "light", "full"];
  var mode = C.read("performanceMode", "light"), device = {};
  if (modes.indexOf(mode) < 0) mode = "light";
  try {
    if (window.TVNative && TVNative.deviceInfo) device = JSON.parse(TVNative.deviceInfo());
  } catch (e) {
  }
  if (window.MorphTVCompatibility && MorphTVCompatibility.legacyLayout) device.lowMemory = true;
  var ua = navigator.userAgent || "", tv = ua.match(/Tizen[ \/]([0-9]+)/i);
  if (tv && Number(tv[1]) <= 6 || navigator.deviceMemory && navigator.deviceMemory <= 2 || navigator.hardwareConcurrency && navigator.hardwareConcurrency <= 2) device.lowMemory = true;
  try {
    if (window.TVNative && TVNative.performanceMode) {
      var saved = TVNative.performanceMode();
      if (modes.indexOf(saved) >= 0) mode = saved;
    }
  } catch (e) {
  }
  if (!C.read("performanceDefault133", false)) {
    if (mode === "auto") mode = "light";
    C.write("performanceMode", mode);
    C.write("performanceDefault133", true);
    try {
      if (window.TVNative && TVNative.setPerformanceMode) TVNative.setPerformanceMode(mode);
    } catch (e) {
    }
  }
  function words() {
    return rows[window.MorphLocale ? MorphLocale.get() : "en"] || rows.en;
  }
  function apply() {
    var light = mode === "light" || mode === "auto" && device.lowMemory === true;
    document.body.classList.toggle("light-mode", light);
    if (button) {
      var w = words();
      button.textContent = w[0] + " \xB7 " + w[mode === "light" || mode === "auto" && device.lowMemory === true ? 2 : 3];
      button.title = w[4];
    }
    if (C.applyRemoteConfig) C.applyRemoteConfig({});
    window.dispatchEvent(new Event("morphPerformance"));
  }
  C.Performance = { isLight: function() {
    return document.body.classList.contains("light-mode");
  }, get: function() {
    return mode;
  }, set: function(value) {
    if (modes.indexOf(value) < 0) return;
    mode = value;
    C.write("performanceMode", mode);
    try {
      if (window.TVNative && TVNative.setPerformanceMode) TVNative.setPerformanceMode(mode);
    } catch (e) {
    }
    apply();
  } };
  var button;
  window.addEventListener("load", function() {
    button = document.createElement("button");
    button.id = "setting-performance";
    button.className = "setting";
    button.setAttribute("data-no-translate", "");
    button.onclick = function() {
      C.Performance.set(C.Performance.isLight() ? "full" : "light");
    };
    var panel = document.querySelector("#view-settings .settings-panel:last-child");
    if (panel) panel.insertBefore(button, panel.firstChild);
    apply();
  });
  window.addEventListener("morphLanguage", function() {
    if (button) {
      var w = words();
      button.textContent = w[0] + " \xB7 " + w[mode === "light" || mode === "auto" && device.lowMemory === true ? 2 : 3];
      button.title = w[4];
    }
  });
  document.body.classList.toggle("light-mode", mode === "light" || mode === "auto" && device.lowMemory === true);
  function icons(root) {
    if (root.matches && root.matches(".shelf-card img,.app-card img")) {
      root.loading = "lazy";
      root.decoding = "async";
    }
    root.querySelectorAll(".shelf-card img,.app-card img").forEach(function(img) {
      img.loading = "lazy";
      img.decoding = "async";
    });
  }
  new MutationObserver(function(records) {
    records.forEach(function(r) {
      Array.prototype.forEach.call(r.addedNodes, function(n) {
        if (n.nodeType === 1) icons(n);
      });
    });
  }).observe(document.body, { childList: true, subtree: true });
})(window.ClearTV);
