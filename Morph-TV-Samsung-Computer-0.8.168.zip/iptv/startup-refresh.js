(function(w) {
  "use strict";
  var dialog = null, previous = null, offered = false, seenKey = "tvmorph.iptv.startup-refresh.seen.v1";
  try {
    offered = localStorage.getItem(seenKey) === "1";
  } catch (e) {
  }
  var words = { ar: ["\u062A\u062D\u062F\u064A\u062B \u0645\u0643\u062A\u0628\u0629 IPTV\u061F", "\u0647\u0644 \u062A\u0631\u064A\u062F \u062A\u062D\u0645\u064A\u0644 \u0623\u062D\u062F\u062B \u0627\u0644\u0642\u0646\u0648\u0627\u062A \u0648\u0627\u0644\u0623\u0641\u0644\u0627\u0645 \u0648\u0627\u0644\u0645\u0633\u0644\u0633\u0644\u0627\u062A \u0645\u0646 \u0645\u0632\u0648\u0651\u062F \u0627\u0634\u062A\u0631\u0627\u0643\u0643\u061F \u0633\u064A\u0628\u0642\u0649 \u0627\u0634\u062A\u0631\u0627\u0643\u0643 \u0648\u0645\u0641\u0636\u0644\u062A\u0643 \u0645\u062D\u0641\u0648\u0638\u064A\u0646.", "\u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0622\u0646", "\u0644\u064A\u0633 \u0627\u0644\u0622\u0646", "\u062C\u0627\u0631\u064A \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0645\u062D\u062A\u0648\u0649 \u0645\u0646 \u0627\u0644\u0645\u0632\u0648\u0651\u062F\u2026", "\u062A\u0645 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0645\u0643\u062A\u0628\u0629.", "\u062A\u0639\u0630\u0651\u0631 \u0625\u0643\u0645\u0627\u0644 \u0627\u0644\u062A\u062D\u062F\u064A\u062B. \u064A\u0645\u0643\u0646\u0643 \u0627\u0644\u0645\u062D\u0627\u0648\u0644\u0629 \u0645\u0646 \u062A\u062D\u062F\u064A\u062B \u0627\u0644\u0645\u062D\u062A\u0648\u0649."], en: ["Update IPTV library?", "Download the latest channels, movies and series from your provider? Your account and favorites will be kept.", "Update now", "Not now", "Updating content from your provider\u2026", "Library updated.", "Could not complete the update. Retry using Update content."], fr: ["Actualiser la biblioth\xE8que IPTV ?", "Charger les derni\xE8res cha\xEEnes, films et s\xE9ries du fournisseur ? Votre compte et vos favoris seront conserv\xE9s.", "Actualiser", "Pas maintenant", "Actualisation du contenu\u2026", "Biblioth\xE8que actualis\xE9e.", "Actualisation incompl\xE8te. R\xE9essayez avec Actualiser le contenu."], zh: ["\u66F4\u65B0 IPTV \u5A92\u4F53\u5E93\uFF1F", "\u4ECE\u63D0\u4F9B\u5546\u52A0\u8F7D\u6700\u65B0\u9891\u9053\u3001\u7535\u5F71\u548C\u5267\u96C6\uFF1F\u8D26\u53F7\u548C\u6536\u85CF\u5C06\u4FDD\u7559\u3002", "\u7ACB\u5373\u66F4\u65B0", "\u6682\u4E0D\u66F4\u65B0", "\u6B63\u5728\u66F4\u65B0\u63D0\u4F9B\u5546\u5185\u5BB9\u2026", "\u5A92\u4F53\u5E93\u5DF2\u66F4\u65B0\u3002", "\u66F4\u65B0\u672A\u5B8C\u6210\uFF0C\u8BF7\u4F7F\u7528\u66F4\u65B0\u5185\u5BB9\u91CD\u8BD5\u3002"], ja: ["IPTV \u30E9\u30A4\u30D6\u30E9\u30EA\u3092\u66F4\u65B0\u3057\u307E\u3059\u304B\uFF1F", "\u914D\u4FE1\u5143\u304B\u3089\u6700\u65B0\u306E\u30C1\u30E3\u30F3\u30CD\u30EB\u3001\u6620\u753B\u3001\u30B7\u30EA\u30FC\u30BA\u3092\u8AAD\u307F\u8FBC\u307F\u307E\u3059\u3002\u30A2\u30AB\u30A6\u30F3\u30C8\u3068\u304A\u6C17\u306B\u5165\u308A\u306F\u4FDD\u6301\u3055\u308C\u307E\u3059\u3002", "\u4ECA\u3059\u3050\u66F4\u65B0", "\u5F8C\u3067", "\u914D\u4FE1\u5143\u306E\u30B3\u30F3\u30C6\u30F3\u30C4\u3092\u66F4\u65B0\u4E2D\u2026", "\u66F4\u65B0\u3057\u307E\u3057\u305F\u3002", "\u66F4\u65B0\u3067\u304D\u307E\u305B\u3093\u3067\u3057\u305F\u3002\u30B3\u30F3\u30C6\u30F3\u30C4\u66F4\u65B0\u304B\u3089\u518D\u8A66\u884C\u3057\u3066\u304F\u3060\u3055\u3044\u3002"] };
  function close() {
    if (!dialog) return false;
    dialog.parentNode.removeChild(dialog);
    dialog = null;
    if (previous && previous.isConnected && !previous.closest("[hidden]")) previous.focus();
    return true;
  }
  function offer(info, call, done) {
    if (offered || dialog || !info || info.configured === false || typeof call !== "function") return;
    offered = true;
    var text = words[w.MorphLocale ? MorphLocale.get() : "en"] || words.en;
    previous = document.activeElement;
    dialog = document.createElement("div");
    dialog.id = "iptv-startup-refresh";
    dialog.className = "settings-overlay";
    dialog.dir = w.MorphLocale && MorphLocale.get() === "ar" ? "rtl" : "ltr";
    var box = document.createElement("section");
    box.className = "settings-dialog";
    box.setAttribute("role", "dialog");
    box.setAttribute("aria-modal", "true");
    box.setAttribute("aria-labelledby", "iptv-startup-refresh-title");
    var title = document.createElement("h2");
    title.id = "iptv-startup-refresh-title";
    title.textContent = text[0];
    var description = document.createElement("p");
    description.textContent = text[1];
    var status = document.createElement("p");
    status.setAttribute("role", "status");
    var yes = document.createElement("button"), no = document.createElement("button");
    yes.id = "iptv-startup-update";
    no.id = "iptv-startup-later";
    yes.textContent = text[2];
    no.textContent = text[3];
    no.onclick = close;
    box.appendChild(title);
    box.appendChild(description);
    box.appendChild(status);
    box.appendChild(yes);
    box.appendChild(no);
    dialog.appendChild(box);
    dialog.setAttribute("data-no-translate", "");
    document.body.appendChild(dialog);
    try {
      localStorage.setItem(seenKey, "1");
    } catch (e) {
    }
    yes.focus();
    var busy = false;
    yes.onclick = function() {
      if (busy) return;
      busy = true;
      yes.disabled = true;
      no.focus();
      status.textContent = text[4];
      var dashboard = document.getElementById("dashboard-status");
      if (dashboard) dashboard.textContent = text[4];
      var kinds = ["live", "vod", "series"].filter(function(k) {
        return info[k] !== false;
      });
      call("refresh").then(function() {
        var chain = Promise.resolve();
        kinds.forEach(function(kind) {
          chain = chain.then(function() {
            return call("categories", { kind });
          }).then(function() {
            return call("list", { kind, category: "", page: 0, search: "" });
          });
        });
        return chain;
      }).then(function() {
        if (dashboard) dashboard.textContent = text[5];
        if (dialog && dialog.contains(yes)) close();
        if (typeof done === "function") done();
      }, function() {
        if (dashboard) dashboard.textContent = text[6];
        if (dialog && dialog.contains(yes)) {
          status.textContent = text[6];
          yes.disabled = false;
          busy = false;
          yes.focus();
        }
      });
    };
  }
  w.IptvStartupRefresh = { offer, back: close };
})(window);
