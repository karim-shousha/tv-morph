(function() {
  "use strict";
  var dark = false, previous = null, released = 0, button = document.createElement("button"), cover = document.createElement("div");
  button.id = "radio-screen-off";
  button.type = "button";
  cover.id = "radio-dark-screen";
  cover.hidden = true;
  cover.tabIndex = -1;
  cover.setAttribute("role", "button");
  function labels() {
    var words = { ar: ["\u0634\u0627\u0634\u0629 \u0633\u0648\u062F\u0627\u0621", "\u0627\u0644\u0635\u0648\u062A \u0645\u0633\u062A\u0645\u0631. \u0627\u0636\u063A\u0637 \u0623\u064A \u0632\u0631 \u0644\u0625\u0638\u0647\u0627\u0631 \u0627\u0644\u0634\u0627\u0634\u0629.", "\u064A\u062E\u0641\u064A \u0627\u0644\u0635\u0648\u0631\u0629 \u0641\u0642\u0637 \u0645\u0639 \u0627\u0633\u062A\u0645\u0631\u0627\u0631 \u0627\u0644\u0631\u0627\u062F\u064A\u0648. \u0627\u0636\u063A\u0637 \u0623\u064A \u0632\u0631 \u0644\u0644\u0639\u0648\u062F\u0629."], en: ["Black screen", "Audio continues. Press any key to show the screen.", "Hides the picture while radio continues. Press any key to return."], fr: ["\xC9cran noir", "Le son continue. Appuyez sur une touche pour revenir.", "Masque l\u2019image sans interrompre la radio."], zh: ["\u9ED1\u5C4F", "\u97F3\u9891\u7EE7\u7EED\u64AD\u653E\uFF0C\u6309\u4EFB\u610F\u952E\u8FD4\u56DE\u3002", "\u9690\u85CF\u753B\u9762\uFF0C\u7EE7\u7EED\u64AD\u653E\u7535\u53F0\u3002"], ja: ["\u753B\u9762\u3092\u9ED2\u304F\u3059\u308B", "\u97F3\u58F0\u306F\u518D\u751F\u4E2D\u3067\u3059\u3002\u30DC\u30BF\u30F3\u3092\u62BC\u3057\u3066\u623B\u308A\u307E\u3059\u3002", "\u30E9\u30B8\u30AA\u3092\u518D\u751F\u3057\u305F\u307E\u307E\u753B\u9762\u3092\u96A0\u3057\u307E\u3059\u3002"] }[MorphLocale.get()] || ["Black screen", "Audio continues. Press any key to show the screen.", "Hides the picture while radio continues. Press any key to return."];
    button.textContent = words[0];
    button.title = words[2];
    button.setAttribute("aria-label", words[0] + ". " + words[2]);
    cover.setAttribute("aria-label", words[1]);
  }
  function wake() {
    if (!dark) return false;
    dark = false;
    document.documentElement.classList.remove("radio-screen-dark");
    cover.hidden = true;
    if (previous && document.body.contains(previous)) try {
      previous.focus({ preventScroll: true });
    } catch (e) {
      previous.focus();
    }
    return true;
  }
  function enter() {
    previous = document.activeElement;
    dark = true;
    cover.hidden = false;
    document.documentElement.classList.add("radio-screen-dark");
    cover.focus();
  }
  button.onclick = enter;
  cover.onclick = function(e) {
    e.preventDefault();
    e.stopPropagation();
    wake();
  };
  document.querySelector("header").insertBefore(button, document.getElementById("back"));
  document.body.appendChild(cover);
  document.addEventListener("keydown", function(e) {
    if (!dark && !released) return;
    if (dark) {
      wake();
      released = e.keyCode;
    }
    e.preventDefault();
    e.stopImmediatePropagation();
  }, true);
  document.addEventListener("keyup", function(e) {
    if (!released) return;
    e.preventDefault();
    e.stopImmediatePropagation();
    if (released === e.keyCode) released = 0;
  }, true);
  window.addEventListener("blur", function() {
    released = 0;
  });
  window.addEventListener("morphLanguage", labels);
  window.RadioScreen = { wake, isDark: function() {
    return dark;
  } };
  labels();
})();
