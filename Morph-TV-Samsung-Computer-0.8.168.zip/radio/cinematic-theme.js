(function(w) {
  "use strict";
  if (!/width=1920/.test(document.querySelector("meta[name=viewport]").content)) return;
  var root = document.documentElement, last = "", meta = document.querySelector("meta[name=tvm-media-root]"), base = meta ? meta.content : "../tv/", artNames = { "saudi-national": "saudi-patriotic-world-v1.webp", "egypt-national": "egypt-patriotic-world-v1.webp", "inter-miami": "intermiami.webp", ismaily: "ismaily-team-hq-v2.webp", "king-salman": "king-salman-portrait-v2.webp", "crown-prince": "crown-prince-cutout-v2.webp", nassr: "nassr-stars-cutout-v2.webp", hilal: "hilal-stars-cutout-v2.webp", ittihad: "ittihad-stars-cutout-hq-v3.webp", "ahli-saudi": "ahli-saudi-stars-cutout-v2.webp", ahly: "al-ahly-duel.webp", argentina: "argentina-champions-hq.webp", portugal: "portugal-team.webp", basketball: "basketball-team.webp", baseball: "baseball-team.webp", montreal: "montreal-team.webp", toronto: "toronto-team.webp", barcelona: "barcelona-team.webp", madrid: "madrid-team.webp", egypt: "egypt-national-team-v1.webp", zamalek: "zamalek-team.webp" };
  root.setAttribute("data-media-cinema", "");
  function configuration() {
    try {
      if (parent !== w && parent.ClearTV) return parent.ClearTV.settings;
      var viewer = localStorage.getItem("cleartv.activeViewer") || "default";
      if (!/^(default|v[0-9a-z]+)$/.test(viewer)) viewer = "default";
      return JSON.parse(localStorage.getItem("cleartv." + (viewer === "default" ? "" : "viewer." + viewer + ".") + "settings")) || {};
    } catch (e) {
      return {};
    }
  }
  function apply() {
    var cfg = configuration(), bridge = w.IptvNative || w.RadioNative;
    try {
      if (!cfg.theme && bridge && bridge.settingsJson) cfg = JSON.parse(bridge.settingsJson());
    } catch (e) {
    }
    var theme = cfg.theme || "blue", native = parent === w, source = "", packs = native ? w.ThemePacks : parent.ThemePacks;
    root.style.setProperty("--media-secondary", theme === "blue" ? "#7948ef" : "var(--media-card)");
    if (theme === "blue" && !cfg.highlightColor && !cfg.accent) root.style.setProperty("--media-accent", "#428cff");
    if (typeof cfg.artImage === "string" && cfg.artImage.length < 1e6 && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(cfg.artImage)) source = cfg.artImage;
    else if (artNames[theme]) {
      source = base + "assets/" + artNames[theme];
      if (packs) source = packs.src(source);
    }
    var backgrounds = { "saudi-national": "radial-gradient(ellipse at 80% 30%,#168451,#042d24 75%)", "egypt-national": "radial-gradient(ellipse at 85% 25%,#67303b,#101b28 70%)", "inter-miami": "radial-gradient(ellipse at 90% 15%,#f7b5cd44,transparent 60%),linear-gradient(125deg,#0b0b0e,#30212a)", blue: "radial-gradient(ellipse at 99% 7%,#c0d3d699,transparent 50%),radial-gradient(ellipse 140% 90% at 122% 125%,#234f6666 49%,transparent 49.2%),radial-gradient(ellipse 130% 95% at 115% 120%,#92bdc944 60%,transparent 60.2%),linear-gradient(110deg,#111c31 5%,#245777 54%,#81b8c3 100%)", night: "linear-gradient(130deg,#090d1b,#28324b)", emerald: "linear-gradient(130deg,#10242b,#39636b 65%,#8fb1ad)", amber: "linear-gradient(130deg,#251923,#815d56 65%,#c6a279)", violet: "linear-gradient(130deg,#17142d,#504271 65%,#9a88b7)" };
    var background = backgrounds[theme] || "linear-gradient(120deg,var(--media-bg),var(--media-card))";
    if (/^#[0-9a-f]{6}$/i.test(cfg.backgroundStart || "") && /^#[0-9a-f]{6}$/i.test(cfg.backgroundEnd || "")) background = "linear-gradient(125deg," + cfg.backgroundStart + "," + cfg.backgroundEnd + ")";
    try {
      var landscape = parent !== w && parent.document.querySelector(".landscape");
      if (landscape) background = parent.getComputedStyle(landscape).backgroundImage;
    } catch (e) {
    }
    root.style.setProperty("--radio-background", background);
    root.dataset.radioArt = source ? "true" : "false";
    var signature = theme + "|" + source;
    if (signature !== last) {
      last = signature;
      root.style.setProperty("--media-art", source ? "url(" + JSON.stringify(source) + ")" : "none");
      root.dataset.mediaTheme = theme;
    }
    var image = document.querySelector(".cinematic-hero-art");
    if (image && !image.hasAttribute("data-category-art")) {
      image.hidden = !source;
      if (source && image.getAttribute("src") !== source) image.src = source;
    }
  }
  w.MediaTheme = { apply };
  apply();
  w.addEventListener("load", apply);
  w.addEventListener("focus", apply);
  w.addEventListener("morphPacks", apply);
  w.addEventListener("storage", apply);
  if (parent !== w) {
    try {
      parent.addEventListener("morphPacks", apply);
      parent.addEventListener("morphViewer", apply);
    } catch (e) {
    }
  } else {
    var script = document.createElement("script");
    script.src = base + "theme-packs-manifest.js";
    script.onload = function() {
      var loader = document.createElement("script");
      loader.src = base + "theme-packs.js";
      loader.onload = function() {
        Promise.resolve(w.ThemePacks.ready).then(apply);
      };
      document.head.appendChild(loader);
    };
    document.head.appendChild(script);
  }
  var shared = document.createElement("script");
  shared.src = base + "ui/media-theme.js";
  document.head.appendChild(shared);
})(window);
